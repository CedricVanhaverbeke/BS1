# Naam student: 
#
# Status implementatie:
#   extractie naam klasse ? 
#   extractie type klasse ? 
#   extractie ouderklasse ? 
#   extractie en bijhouden verzameling verplichte attributen ? 
#   extractie en bijhouden verzameling hulpklassen ? 
#   stap 1: op naam gesorteerde lijst van alle klassen met verplichte attributen ? 
#   stap 1: op naam gesorteerde lijst, per klasse, van alle verplichte attributen ? 
#   stap 1: correct aantal lijnen (97) ? 
#   stap 2: uitbreiding verplichte attributen met verplichte attributen van hulpklassen ? 
#   stap 2: correct aantal lijnen (99) ? 
#   stap 3: opsporen hierarchie van opeenvolgende ouderklassen ? 
#   stap 3: uitbreiding verplichte attributen met verplichte attributen van hierarchische ouderklassen ? 
#   stap 3: komt een attribuut maximaal ��nmaal voor in de verplichte attributen van een klasse ? 
#   stap 3: correct aantal lijnen (alle klassen) ? 
#   stap 4: eliminatie klassen waarvoor objectClassCategory niet 1 ? 
#   stap 4: eliminatie klassen die ouderklasse zijn van een andere klasse ? 
#   stap 4: eliminatie klassen met top als ouderklasse ? 
#   stap 4: correct aantal lijnen (74) ? 
#
# Eventuele tekortkomingen: 
#

while (<DATA>) {
} 

__DATA__
dn: CN=DMD,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: DMD
distinguishedName: CN=DMD,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4900
subClassOf: top
governsID: 1.2.840.113556.1.3.9
rDNAttID: cn
uSNChanged: 4900
showInAdvancedViewOnly: TRUE
adminDisplayName: DMD
adminDescription: DMD
objectClassCategory: 1
lDAPDisplayName: dMD
name: DMD
objectGUID:: OhU9uk1u4k27UPRPeBulLA==
schemaIDGUID:: j3qWv+YN0BGihQCqADBJ4g==
systemOnly: TRUE
systemPossSuperiors: configuration
systemMayContain: schemaUpdate
systemMayContain: schemaInfo
systemMayContain: prefixMap
systemMayContain: msDs-Schema-Extensions
systemMayContain: msDS-IntId
systemMayContain: dmdName
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=DMD,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=SubSchema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: SubSchema
distinguishedName: 
 CN=SubSchema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5163
subClassOf: top
governsID: 2.5.20.1
rDNAttID: cn
uSNChanged: 5163
showInAdvancedViewOnly: TRUE
adminDisplayName: SubSchema
adminDescription: SubSchema
objectClassCategory: 1
lDAPDisplayName: subSchema
name: SubSchema
objectGUID:: Tk7DkOaqRUa6higlq76d4Q==
schemaIDGUID:: YTKLWo3D0RG7yQCAx2ZwwA==
systemOnly: TRUE
systemPossSuperiors: dMD
systemMayContain: objectClasses
systemMayContain: modifyTimeStamp
systemMayContain: extendedClassInfo
systemMayContain: extendedAttributeInfo
systemMayContain: dITContentRules
systemMayContain: attributeTypes
defaultSecurityDescriptor: D:S:
systemFlags: 134217744
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=SubSchema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Attribute-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Attribute-Schema
distinguishedName: 
 CN=Attribute-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4864
subClassOf: top
governsID: 1.2.840.113556.1.3.14
rDNAttID: cn
uSNChanged: 4864
showInAdvancedViewOnly: TRUE
adminDisplayName: Attribute-Schema
adminDescription: Attribute-Schema
objectClassCategory: 1
lDAPDisplayName: attributeSchema
name: Attribute-Schema
objectGUID:: cY9VFnT3N0a32yRlEgeYOA==
schemaIDGUID:: gHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: dMD
systemMayContain: systemOnly
systemMayContain: searchFlags
systemMayContain: schemaFlagsEx
systemMayContain: rangeUpper
systemMayContain: rangeLower
systemMayContain: oMObjectClass
systemMayContain: msDs-Schema-Extensions
systemMayContain: msDS-IntId
systemMayContain: mAPIID
systemMayContain: linkID
systemMayContain: isMemberOfPartialAttributeSet
systemMayContain: isEphemeral
systemMayContain: isDefunct
systemMayContain: extendedCharsAllowed
systemMayContain: classDisplayName
systemMayContain: attributeSecurityGUID
systemMustContain: schemaIDGUID
systemMustContain: oMSyntax
systemMustContain: lDAPDisplayName
systemMustContain: isSingleValued
systemMustContain: cn
systemMustContain: attributeSyntax
systemMustContain: attributeID
defaultSecurityDescriptor: D:S:
systemFlags: 134217744
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Attribute-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: account
distinguishedName: 
 CN=account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
possSuperiors: organizationalUnit
possSuperiors: container
uSNCreated: 4843
subClassOf: top
governsID: 0.9.2342.19200300.100.4.5
mayContain: uid
mayContain: host
mayContain: ou
mayContain: o
mayContain: l
mayContain: seeAlso
mayContain: description
rDNAttID: cn
uSNChanged: 4843
showInAdvancedViewOnly: TRUE
adminDisplayName: account
adminDescription: 
 The account object class is used to define entries representing computer accou
 nts.
objectClassCategory: 1
lDAPDisplayName: account
name: account
objectGUID:: fu9SddBKWk6BU8k+/YKs/w==
schemaIDGUID:: aqQoJq2m4Eq4VCsS2f5vng==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Class-Schema
distinguishedName: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4873
subClassOf: top
governsID: 1.2.840.113556.1.3.13
rDNAttID: cn
uSNChanged: 4873
showInAdvancedViewOnly: TRUE
adminDisplayName: Class-Schema
adminDescription: Class-Schema
objectClassCategory: 1
lDAPDisplayName: classSchema
name: Class-Schema
objectGUID:: P8fUuRzjgE+uZaAR/A5y8g==
schemaIDGUID:: g3qWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: dMD
systemMayContain: systemPossSuperiors
systemMayContain: systemOnly
systemMayContain: systemMustContain
systemMayContain: systemMayContain
systemMayContain: systemAuxiliaryClass
systemMayContain: schemaFlagsEx
systemMayContain: rDNAttID
systemMayContain: possSuperiors
systemMayContain: mustContain
systemMayContain: msDs-Schema-Extensions
systemMayContain: msDS-IntId
systemMayContain: mayContain
systemMayContain: lDAPDisplayName
systemMayContain: isDefunct
systemMayContain: defaultSecurityDescriptor
systemMayContain: defaultHidingValue
systemMayContain: classDisplayName
systemMayContain: auxiliaryClass
systemMustContain: subClassOf
systemMustContain: schemaIDGUID
systemMustContain: objectClassCategory
systemMustContain: governsID
systemMustContain: defaultObjectCategory
systemMustContain: cn
defaultSecurityDescriptor: D:S:
systemFlags: 134217744
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ACS-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ACS-Policy
distinguishedName: 
 CN=ACS-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4845
subClassOf: top
governsID: 1.2.840.113556.1.5.137
rDNAttID: cn
uSNChanged: 4845
showInAdvancedViewOnly: TRUE
adminDisplayName: ACS-Policy
adminDescription: ACS-Policy
objectClassCategory: 1
lDAPDisplayName: aCSPolicy
name: ACS-Policy
objectGUID:: YQGblkJD5EyniIGazGIpJw==
schemaIDGUID:: iBJWfwFT0RGpxQAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: aCSTotalNoOfFlows
systemMayContain: aCSTimeOfDay
systemMayContain: aCSServiceType
systemMayContain: aCSPriority
systemMayContain: aCSPermissionBits
systemMayContain: aCSMinimumDelayVariation
systemMayContain: aCSMinimumLatency
systemMayContain: aCSMaximumSDUSize
systemMayContain: aCSMinimumPolicedSize
systemMayContain: aCSMaxTokenRatePerFlow
systemMayContain: aCSMaxTokenBucketPerFlow
systemMayContain: aCSMaxPeakBandwidthPerFlow
systemMayContain: aCSMaxDurationPerFlow
systemMayContain: aCSMaxAggregatePeakRatePerUser
systemMayContain: aCSIdentityName
systemMayContain: aCSDirection
systemMayContain: aCSAggregateTokenRatePerUser
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ACS-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ACS-Resource-Limits,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ACS-Resource-Limits
distinguishedName: 
 CN=ACS-Resource-Limits,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4847
subClassOf: top
governsID: 1.2.840.113556.1.5.191
rDNAttID: cn
uSNChanged: 4847
showInAdvancedViewOnly: TRUE
adminDisplayName: ACS-Resource-Limits
adminDescription: ACS-Resource-Limits
objectClassCategory: 1
lDAPDisplayName: aCSResourceLimits
name: ACS-Resource-Limits
objectGUID:: Aema8QnFZ0ybiXrK30IiDw==
schemaIDGUID:: BJuJLjQo0xGR1AAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: aCSMaxTokenRatePerFlow
systemMayContain: aCSServiceType
systemMayContain: aCSMaxPeakBandwidthPerFlow
systemMayContain: aCSMaxPeakBandwidth
systemMayContain: aCSAllocableRSVPBandwidth
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ACS-Resource-Limits,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ACS-Subnet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ACS-Subnet
distinguishedName: 
 CN=ACS-Subnet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4849
subClassOf: top
governsID: 1.2.840.113556.1.5.138
rDNAttID: cn
uSNChanged: 4849
showInAdvancedViewOnly: TRUE
adminDisplayName: ACS-Subnet
adminDescription: ACS-Subnet
objectClassCategory: 1
lDAPDisplayName: aCSSubnet
name: ACS-Subnet
objectGUID:: c7EbKJainU66HKFl7dERoA==
schemaIDGUID:: iRJWfwFT0RGpxQAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: aCSServerList
systemMayContain: aCSRSVPLogFilesLocation
systemMayContain: aCSRSVPAccountFilesLocation
systemMayContain: aCSNonReservedTxSize
systemMayContain: aCSNonReservedTxLimit
systemMayContain: aCSNonReservedTokenSize
systemMayContain: aCSNonReservedPeakRate
systemMayContain: aCSNonReservedMinPolicedSize
systemMayContain: aCSNonReservedMaxSDUSize
systemMayContain: aCSMaxTokenRatePerFlow
systemMayContain: aCSMaxSizeOfRSVPLogFile
systemMayContain: aCSMaxSizeOfRSVPAccountFile
systemMayContain: aCSMaxPeakBandwidthPerFlow
systemMayContain: aCSMaxPeakBandwidth
systemMayContain: aCSMaxNoOfLogFiles
systemMayContain: aCSMaxNoOfAccountFiles
systemMayContain: aCSMaxDurationPerFlow
systemMayContain: aCSEventLogLevel
systemMayContain: aCSEnableRSVPMessageLogging
systemMayContain: aCSEnableRSVPAccounting
systemMayContain: aCSEnableACSService
systemMayContain: aCSDSBMRefresh
systemMayContain: aCSDSBMPriority
systemMayContain: aCSDSBMDeadTime
systemMayContain: aCSCacheTimeout
systemMayContain: aCSAllocableRSVPBandwidth
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ACS-Subnet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Address-Book-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Address-Book-Container
distinguishedName: 
 CN=Address-Book-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4851
subClassOf: top
governsID: 1.2.840.113556.1.5.125
rDNAttID: cn
uSNChanged: 4851
showInAdvancedViewOnly: TRUE
adminDisplayName: Address-Book-Container
adminDescription: Address-Book-Container
objectClassCategory: 1
lDAPDisplayName: addressBookContainer
name: Address-Book-Container
objectGUID:: 4NrYTI6UT0aY74JYwCKgOw==
schemaIDGUID:: D/Z0PnM+0RGpwAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: addressBookContainer
systemPossSuperiors: configuration
systemMayContain: purportedSearch
systemMustContain: displayName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(OA;;CR;a1990816-4298-11d1-ade2-00c04fd8d5cd;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Address-Book-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Address-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Address-Template
distinguishedName: 
 CN=Address-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4853
subClassOf: displayTemplate
governsID: 1.2.840.113556.1.3.58
rDNAttID: cn
uSNChanged: 4853
showInAdvancedViewOnly: TRUE
adminDisplayName: Address-Template
adminDescription: Address-Template
objectClassCategory: 1
lDAPDisplayName: addressTemplate
name: Address-Template
objectGUID:: qmqv1qQj4kWf1J2vGS7QQg==
schemaIDGUID:: CiXUX2IS0BGgYACqAGwz7Q==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: proxyGenerationEnabled
systemMayContain: perRecipDialogDisplayTable
systemMayContain: perMsgDialogDisplayTable
systemMayContain: addressType
systemMayContain: addressSyntax
systemMustContain: displayName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Address-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Application-Entity,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Application-Entity
distinguishedName: 
 CN=Application-Entity,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4855
subClassOf: top
governsID: 2.5.6.12
rDNAttID: cn
uSNChanged: 4855
showInAdvancedViewOnly: TRUE
adminDisplayName: Application-Entity
adminDescription: Application-Entity
objectClassCategory: 1
lDAPDisplayName: applicationEntity
name: Application-Entity
objectGUID:: 713ne2H1nUm44GhguWX1Jw==
schemaIDGUID:: T+7fP/RH0RGpwwAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: applicationProcess
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
systemMayContain: supportedApplicationContext
systemMayContain: seeAlso
systemMayContain: ou
systemMayContain: o
systemMayContain: l
systemMustContain: presentationAddress
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Application-Entity,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Application-Process,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Application-Process
distinguishedName: 
 CN=Application-Process,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4857
subClassOf: top
governsID: 2.5.6.11
rDNAttID: cn
uSNChanged: 4857
showInAdvancedViewOnly: TRUE
adminDisplayName: Application-Process
adminDescription: Application-Process
objectClassCategory: 1
lDAPDisplayName: applicationProcess
name: Application-Process
objectGUID:: qhrUW09nLUGxCdhWWraPWg==
schemaIDGUID:: CyXUX2IS0BGgYACqAGwz7Q==
systemOnly: TRUE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: organization
systemPossSuperiors: container
systemPossSuperiors: computer
systemMayContain: seeAlso
systemMayContain: ou
systemMayContain: l
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Application-Process,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Application-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Application-Settings
distinguishedName: 
 CN=Application-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4859
subClassOf: top
governsID: 1.2.840.113556.1.5.7000.49
rDNAttID: cn
uSNChanged: 4859
showInAdvancedViewOnly: TRUE
adminDisplayName: Application-Settings
adminDescription: Application-Settings
objectClassCategory: 2
lDAPDisplayName: applicationSettings
name: Application-Settings
objectGUID:: zQhQp7SGnE2ShfQhpmq4Tg==
schemaIDGUID:: wayA9/BW0RGpxgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: server
systemMayContain: notificationList
systemMayContain: msDS-Settings
systemMayContain: applicationName
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Application-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Application-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Application-Site-Settings
distinguishedName: 
 CN=Application-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4861
subClassOf: top
governsID: 1.2.840.113556.1.5.68
rDNAttID: cn
uSNChanged: 4861
showInAdvancedViewOnly: TRUE
adminDisplayName: Application-Site-Settings
adminDescription: Application-Site-Settings
objectClassCategory: 2
lDAPDisplayName: applicationSiteSettings
name: Application-Site-Settings
objectGUID:: fAI6ShxozUeo9ApDcjN3jg==
schemaIDGUID:: XFoZGaBt0BGv0wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: site
systemMayContain: notificationList
systemMayContain: applicationName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Application-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Application-Version,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Application-Version
distinguishedName: 
 CN=Application-Version,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
possSuperiors: organizationalUnit
possSuperiors: computer
possSuperiors: container
uSNCreated: 4863
subClassOf: applicationSettings
governsID: 1.2.840.113556.1.5.216
mayContain: owner
mayContain: managedBy
mayContain: keywords
mayContain: versionNumberLo
mayContain: versionNumberHi
mayContain: versionNumber
mayContain: vendor
mayContain: appSchemaVersion
rDNAttID: cn
uSNChanged: 4863
showInAdvancedViewOnly: TRUE
adminDisplayName: Application-Version
adminDescription: 
 Stores versioning information for an application and its schema.
objectClassCategory: 1
lDAPDisplayName: applicationVersion
name: Application-Version
objectGUID:: XsTWT2vN3UC+UGs/6B4KBg==
schemaIDGUID:: rJDH3U2vKkSPD6HUyqfdkg==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 0
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Application-Version,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Builtin-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Builtin-Domain
distinguishedName: 
 CN=Builtin-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4866
subClassOf: top
governsID: 1.2.840.113556.1.5.4
rDNAttID: cn
uSNChanged: 4866
showInAdvancedViewOnly: TRUE
adminDisplayName: Builtin-Domain
adminDescription: Builtin-Domain
objectClassCategory: 1
lDAPDisplayName: builtinDomain
name: Builtin-Domain
objectGUID:: oXL4yE5TcE+PDfyEuFzxTA==
schemaIDGUID:: gXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemAuxiliaryClass: samDomainBase
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Builtin-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Category-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Category-Registration
distinguishedName: 
 CN=Category-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4868
subClassOf: leaf
governsID: 1.2.840.113556.1.5.74
rDNAttID: cn
uSNChanged: 4868
showInAdvancedViewOnly: TRUE
adminDisplayName: Category-Registration
adminDescription: Category-Registration
objectClassCategory: 1
lDAPDisplayName: categoryRegistration
name: Category-Registration
objectGUID:: iLYz3Tcjm0OGUvsq7RSjnA==
schemaIDGUID:: nQ5sfSB+0BGv1gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: classStore
systemMayContain: managedBy
systemMayContain: localizedDescription
systemMayContain: localeID
systemMayContain: categoryId
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Category-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Certification-Authority,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Certification-Authority
distinguishedName: 
 CN=Certification-Authority,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4870
subClassOf: top
governsID: 2.5.6.16
rDNAttID: cn
uSNChanged: 4870
showInAdvancedViewOnly: TRUE
adminDisplayName: Certification-Authority
adminDescription: Certification-Authority
objectClassCategory: 0
lDAPDisplayName: certificationAuthority
name: Certification-Authority
objectGUID:: 7n1R/yRaNkiDA6HI/vP8/g==
schemaIDGUID:: UO7fP/RH0RGpwwAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: teletexTerminalIdentifier
systemMayContain: supportedApplicationContext
systemMayContain: signatureAlgorithms
systemMayContain: searchGuide
systemMayContain: previousParentCA
systemMayContain: previousCACertificates
systemMayContain: pendingParentCA
systemMayContain: pendingCACertificates
systemMayContain: parentCACertificateChain
systemMayContain: parentCA
systemMayContain: enrollmentProviders
systemMayContain: domainPolicyObject
systemMayContain: domainID
systemMayContain: dNSHostName
systemMayContain: deltaRevocationList
systemMayContain: currentParentCA
systemMayContain: crossCertificatePair
systemMayContain: cRLObject
systemMayContain: certificateTemplates
systemMayContain: cAWEBURL
systemMayContain: cAUsages
systemMayContain: cAConnect
systemMayContain: cACertificateDN
systemMustContain: cn
systemMustContain: certificateRevocationList
systemMustContain: cACertificate
systemMustContain: authorityRevocationList
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Certification-Authority,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Class-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Class-Registration
distinguishedName: 
 CN=Class-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4872
subClassOf: leaf
governsID: 1.2.840.113556.1.5.10
rDNAttID: cn
uSNChanged: 4872
showInAdvancedViewOnly: TRUE
adminDisplayName: Class-Registration
adminDescription: Class-Registration
objectClassCategory: 1
lDAPDisplayName: classRegistration
name: Class-Registration
objectGUID:: g8vdZEwj3kCZy2WNq6Anmg==
schemaIDGUID:: gnqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: classStore
systemMayContain: requiredCategories
systemMayContain: managedBy
systemMayContain: implementedCategories
systemMayContain: cOMTreatAsClassId
systemMayContain: cOMProgID
systemMayContain: cOMOtherProgId
systemMayContain: cOMInterfaceID
systemMayContain: cOMCLSID
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Class-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Class-Store,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Class-Store
distinguishedName: 
 CN=Class-Store,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4875
subClassOf: top
governsID: 1.2.840.113556.1.5.44
rDNAttID: cn
uSNChanged: 4875
showInAdvancedViewOnly: TRUE
adminDisplayName: Class-Store
adminDescription: Class-Store
objectClassCategory: 1
lDAPDisplayName: classStore
name: Class-Store
objectGUID:: LV+7CjCOYk+2eF33ZndC8g==
schemaIDGUID:: hHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: domainPolicy
systemPossSuperiors: computer
systemPossSuperiors: group
systemPossSuperiors: user
systemPossSuperiors: classStore
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemPossSuperiors: container
systemMayContain: versionNumber
systemMayContain: nextLevelStore
systemMayContain: lastUpdateSequence
systemMayContain: appSchemaVersion
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Class-Store,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Com-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Com-Connection-Point
distinguishedName: 
 CN=Com-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4877
subClassOf: connectionPoint
governsID: 1.2.840.113556.1.5.11
rDNAttID: cn
uSNChanged: 4877
showInAdvancedViewOnly: TRUE
adminDisplayName: Com-Connection-Point
adminDescription: Com-Connection-Point
objectClassCategory: 1
lDAPDisplayName: comConnectionPoint
name: Com-Connection-Point
objectGUID:: FcZicaNkrU+yS2Z7wIs7JA==
schemaIDGUID:: hXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: monikerDisplayName
systemMayContain: moniker
systemMayContain: marshalledInterface
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Com-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Configuration
distinguishedName: 
 CN=Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4879
subClassOf: top
governsID: 1.2.840.113556.1.5.12
rDNAttID: cn
uSNChanged: 4879
showInAdvancedViewOnly: TRUE
adminDisplayName: Configuration
adminDescription: Configuration
objectClassCategory: 1
lDAPDisplayName: configuration
name: Configuration
objectGUID:: Eyzb0hgaoEe30f3VlZHivQ==
schemaIDGUID:: h3qWv+YN0BGihQCqADBJ4g==
systemOnly: TRUE
systemPossSuperiors: domainDNS
systemMayContain: gPOptions
systemMayContain: gPLink
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPLC
 LORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Connection-Point
distinguishedName: 
 CN=Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4881
subClassOf: leaf
governsID: 1.2.840.113556.1.5.14
rDNAttID: cn
uSNChanged: 4881
showInAdvancedViewOnly: TRUE
adminDisplayName: Connection-Point
adminDescription: Connection-Point
objectClassCategory: 2
lDAPDisplayName: connectionPoint
name: Connection-Point
objectGUID:: PPao4jSY0Uipvd7mtHRMyw==
schemaIDGUID:: zx60XEwO0BGihgCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemPossSuperiors: computer
systemMayContain: msDS-Settings
systemMayContain: managedBy
systemMayContain: keywords
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Container
distinguishedName: 
 CN=Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4883
subClassOf: top
governsID: 1.2.840.113556.1.3.23
mayContain: msDS-ObjectReference
rDNAttID: cn
uSNChanged: 4883
showInAdvancedViewOnly: TRUE
adminDisplayName: Container
adminDescription: Container
objectClassCategory: 1
lDAPDisplayName: container
name: Container
objectGUID:: erOthmHlCEGlwDFr5UIs1A==
schemaIDGUID:: i3qWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: msDS-AzScope
systemPossSuperiors: msDS-AzApplication
systemPossSuperiors: msDS-AzAdminManager
systemPossSuperiors: subnet
systemPossSuperiors: server
systemPossSuperiors: nTDSService
systemPossSuperiors: domainDNS
systemPossSuperiors: organization
systemPossSuperiors: configuration
systemPossSuperiors: container
systemPossSuperiors: organizationalUnit
systemMayContain: schemaVersion
systemMayContain: defaultClassStore
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Control-Access-Right,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Control-Access-Right
distinguishedName: 
 CN=Control-Access-Right,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4885
subClassOf: top
governsID: 1.2.840.113556.1.5.77
rDNAttID: cn
uSNChanged: 4885
showInAdvancedViewOnly: TRUE
adminDisplayName: Control-Access-Right
adminDescription: Control-Access-Right
objectClassCategory: 1
lDAPDisplayName: controlAccessRight
name: Control-Access-Right
objectGUID:: 0/PW25HwBU26X5ILe+drIg==
schemaIDGUID:: HpOXgtOG0BGv2gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: validAccesses
systemMayContain: rightsGuid
systemMayContain: localizationDisplayId
systemMayContain: appliesTo
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Control-Access-Right,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Country,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Country
distinguishedName: 
 CN=Country,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4887
subClassOf: top
governsID: 2.5.6.2
rDNAttID: c
uSNChanged: 4887
showInAdvancedViewOnly: TRUE
adminDisplayName: Country
adminDescription: Country
objectClassCategory: 0
lDAPDisplayName: country
name: Country
objectGUID:: 7JPAksDt80a1YaVwa0uO5Q==
schemaIDGUID:: jHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemPossSuperiors: organization
systemMayContain: co
systemMayContain: searchGuide
systemMustContain: c
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Country,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=CRL-Distribution-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: CRL-Distribution-Point
distinguishedName: 
 CN=CRL-Distribution-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4889
subClassOf: top
governsID: 2.5.6.19
rDNAttID: cn
uSNChanged: 4889
showInAdvancedViewOnly: TRUE
adminDisplayName: CRL-Distribution-Point
adminDescription: CRL-Distribution-Point
objectClassCategory: 1
lDAPDisplayName: cRLDistributionPoint
name: CRL-Distribution-Point
objectGUID:: sqZcYUF0cE+LNqq1xXZZlQ==
schemaIDGUID:: ylh3FvNH0RGpwwAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: deltaRevocationList
systemMayContain: cRLPartitionedRevocationList
systemMayContain: certificateRevocationList
systemMayContain: certificateAuthorityObject
systemMayContain: authorityRevocationList
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=CRL-Distribution-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Cross-Ref-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Cross-Ref-Container
distinguishedName: 
 CN=Cross-Ref-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4891
subClassOf: top
governsID: 1.2.840.113556.1.5.7000.53
rDNAttID: cn
uSNChanged: 4891
showInAdvancedViewOnly: TRUE
adminDisplayName: Cross-Ref-Container
adminDescription: Cross-Ref-Container
objectClassCategory: 1
lDAPDisplayName: crossRefContainer
name: Cross-Ref-Container
objectGUID:: 8/dvvfkL9UeW+iYbo+oQbg==
schemaIDGUID:: 4GCe7/dW0RGpxgAA+ANnwQ==
systemOnly: TRUE
systemPossSuperiors: configuration
systemMayContain: msDS-SPNSuffixes
systemMayContain: uPNSuffixes
systemMayContain: msDS-UpdateScript
systemMayContain: msDS-ExecuteScriptPassword
systemMayContain: msDS-Behavior-Version
defaultSecurityDescriptor: D:(A;;GA;;;SY)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Cross-Ref-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Dfs-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Dfs-Configuration
distinguishedName: 
 CN=Dfs-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4893
subClassOf: top
governsID: 1.2.840.113556.1.5.42
rDNAttID: cn
uSNChanged: 4893
showInAdvancedViewOnly: TRUE
adminDisplayName: Dfs-Configuration
adminDescription: Dfs-Configuration
objectClassCategory: 1
lDAPDisplayName: dfsConfiguration
name: Dfs-Configuration
objectGUID:: jh5qj3SJykKBDpah69QJlw==
schemaIDGUID:: 8vlHhCcQ0BGgXwCqAGwz7Q==
systemOnly: FALSE
systemPossSuperiors: container
systemPossSuperiors: domainDNS
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Dfs-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=DHCP-Class,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: DHCP-Class
distinguishedName: 
 CN=DHCP-Class,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4895
subClassOf: top
governsID: 1.2.840.113556.1.5.132
rDNAttID: cn
uSNChanged: 4895
showInAdvancedViewOnly: TRUE
adminDisplayName: DHCP-Class
adminDescription: DHCP-Class
objectClassCategory: 1
lDAPDisplayName: dHCPClass
name: DHCP-Class
objectGUID:: qBTaRFSwakaf9zjPEkqNlw==
schemaIDGUID:: Vic9lr5I0RGpwwAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: superScopes
systemMayContain: superScopeDescription
systemMayContain: optionsLocation
systemMayContain: optionDescription
systemMayContain: networkAddress
systemMayContain: mscopeId
systemMayContain: dhcpUpdateTime
systemMayContain: dhcpSubnets
systemMayContain: dhcpState
systemMayContain: dhcpSites
systemMayContain: dhcpServers
systemMayContain: dhcpReservations
systemMayContain: dhcpRanges
systemMayContain: dhcpProperties
systemMayContain: dhcpOptions
systemMayContain: dhcpObjName
systemMayContain: dhcpObjDescription
systemMayContain: dhcpMaxKey
systemMayContain: dhcpMask
systemMayContain: dhcpClasses
systemMustContain: dhcpUniqueKey
systemMustContain: dhcpType
systemMustContain: dhcpIdentification
systemMustContain: dhcpFlags
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=DHCP-Class,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Display-Specifier,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Display-Specifier
distinguishedName: 
 CN=Display-Specifier,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4897
subClassOf: top
governsID: 1.2.840.113556.1.5.84
rDNAttID: cn
uSNChanged: 4897
showInAdvancedViewOnly: TRUE
adminDisplayName: Display-Specifier
adminDescription: Display-Specifier
objectClassCategory: 1
lDAPDisplayName: displaySpecifier
name: Display-Specifier
objectGUID:: Bv7P5VS3OU2OSJ+Qk7FRzA==
schemaIDGUID:: ih764EWb0BGv3QDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: treatAsLeaf
systemMayContain: shellPropertyPages
systemMayContain: shellContextMenu
systemMayContain: scopeFlags
systemMayContain: queryFilter
systemMayContain: iconPath
systemMayContain: extraColumns
systemMayContain: creationWizard
systemMayContain: createWizardExt
systemMayContain: createDialog
systemMayContain: contextMenu
systemMayContain: classDisplayName
systemMayContain: attributeDisplayNames
systemMayContain: adminPropertyPages
systemMayContain: adminMultiselectPropertyPages
systemMayContain: adminContextMenu
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Display-Specifier,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Display-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Display-Template
distinguishedName: 
 CN=Display-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4899
subClassOf: top
governsID: 1.2.840.113556.1.3.59
rDNAttID: cn
uSNChanged: 4899
showInAdvancedViewOnly: TRUE
adminDisplayName: Display-Template
adminDescription: Display-Template
objectClassCategory: 1
lDAPDisplayName: displayTemplate
name: Display-Template
objectGUID:: XylrC+nWGESqMd/dGAPK1A==
schemaIDGUID:: DCXUX2IS0BGgYACqAGwz7Q==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: originalDisplayTableMSDOS
systemMayContain: originalDisplayTable
systemMayContain: helpFileName
systemMayContain: helpData32
systemMayContain: helpData16
systemMayContain: addressEntryDisplayTableMSDOS
systemMayContain: addressEntryDisplayTable
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Display-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Dns-Node,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Dns-Node
distinguishedName: 
 CN=Dns-Node,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4902
subClassOf: top
governsID: 1.2.840.113556.1.5.86
rDNAttID: dc
uSNChanged: 4902
showInAdvancedViewOnly: TRUE
adminDisplayName: Dns-Node
adminDescription: Dns-Node
objectClassCategory: 1
lDAPDisplayName: dnsNode
name: Dns-Node
objectGUID:: yfDvaDPa4kOaCABYhNxUog==
schemaIDGUID:: jB764EWb0BGv3QDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: dnsZone
systemMayContain: dNSTombstoned
systemMayContain: dnsRecord
systemMayContain: dNSProperty
systemMustContain: dc
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;ED)(A;;
 RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)(A;;RPLCLO
 RC;;;WD)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Dns-Node,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Dns-Zone,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Dns-Zone
distinguishedName: 
 CN=Dns-Zone,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4904
subClassOf: top
governsID: 1.2.840.113556.1.5.85
rDNAttID: dc
uSNChanged: 4904
showInAdvancedViewOnly: TRUE
adminDisplayName: Dns-Zone
adminDescription: Dns-Zone
objectClassCategory: 1
lDAPDisplayName: dnsZone
name: Dns-Zone
objectGUID:: AJSjvBHOdEaaCvWR6Kliuw==
schemaIDGUID:: ix764EWb0BGv3QDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: managedBy
systemMayContain: dnsSecureSecondaries
systemMayContain: dNSProperty
systemMayContain: dnsNotifySecondaries
systemMayContain: dnsAllowXFR
systemMayContain: dnsAllowDynamic
systemMustContain: dc
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;ED)(A;;
 RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;CC;;;AU)(A;;RPLCLORC;;;WD)(A;;RPWPCRCCDCLC
 LORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Dns-Zone,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=document,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: document
distinguishedName: 
 CN=document,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
possSuperiors: organizationalUnit
possSuperiors: container
uSNCreated: 4906
subClassOf: top
governsID: 0.9.2342.19200300.100.4.6
mayContain: documentIdentifier
mayContain: documentPublisher
mayContain: documentLocation
mayContain: documentAuthor
mayContain: documentVersion
mayContain: documentTitle
mayContain: ou
mayContain: o
mayContain: l
mayContain: seeAlso
mayContain: description
mayContain: cn
rDNAttID: cn
uSNChanged: 4906
showInAdvancedViewOnly: TRUE
adminDisplayName: document
adminDescription: 
 The document object class is used to define entries which represent documents.
objectClassCategory: 1
lDAPDisplayName: document
name: document
objectGUID:: MuGwDQsopUagYQgdLsKCIA==
schemaIDGUID:: bdm6OdbCr0uIq35CB2ABFw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=document,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=documentSeries,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: documentSeries
distinguishedName: 
 CN=documentSeries,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
possSuperiors: organizationalUnit
possSuperiors: container
uSNCreated: 4908
subClassOf: top
governsID: 0.9.2342.19200300.100.4.9
mustContain: cn
mayContain: telephoneNumber
mayContain: ou
mayContain: o
mayContain: l
mayContain: seeAlso
mayContain: description
rDNAttID: cn
uSNChanged: 4908
showInAdvancedViewOnly: TRUE
adminDisplayName: documentSeries
adminDescription: 
 The documentSeries object class is used to define an entry which represents a 
 series of documents.
objectClassCategory: 1
lDAPDisplayName: documentSeries
name: documentSeries
objectGUID:: oYAbqQ1WrUSCjXptWUBLVg==
schemaIDGUID:: fOArei8wlku8kAeV1miF+A==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=documentSeries,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Domain
distinguishedName: CN=Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4910
subClassOf: top
governsID: 1.2.840.113556.1.5.66
rDNAttID: dc
uSNChanged: 4910
showInAdvancedViewOnly: TRUE
adminDisplayName: Domain
adminDescription: Domain
objectClassCategory: 2
lDAPDisplayName: domain
name: Domain
objectGUID:: AAv3QfuDa0OGKYl4eIQZcQ==
schemaIDGUID:: WloZGaBt0BGv0wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: domain
systemPossSuperiors: organization
systemMustContain: dc
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Domain-DNS,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Domain-DNS,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Domain-DNS
distinguishedName: 
 CN=Domain-DNS,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5890
subClassOf: domain
governsID: 1.2.840.113556.1.5.67
rDNAttID: dc
uSNChanged: 5890
showInAdvancedViewOnly: TRUE
adminDisplayName: Domain-DNS
adminDescription: Domain-DNS
objectClassCategory: 1
lDAPDisplayName: domainDNS
name: Domain-DNS
objectGUID:: IfNU5XeXVUacryphbZQwAg==
schemaIDGUID:: W1oZGaBt0BGv0wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemMayContain: msDS-Behavior-Version
systemMayContain: msDS-AllowedDNSSuffixes
systemMayContain: managedBy
systemAuxiliaryClass: samDomain
defaultSecurityDescriptor: 
 D:(A;;RP;;;WD)(OA;;CR;1131f6aa-9c07-11d1-f79f-00c04fc2dcd2;;ED)(OA;;CR;1131f6a
 b-9c07-11d1-f79f-00c04fc2dcd2;;ED)(OA;;CR;1131f6ac-9c07-11d1-f79f-00c04fc2dcd2
 ;;ED)(OA;;CR;1131f6aa-9c07-11d1-f79f-00c04fc2dcd2;;BA)(OA;;CR;1131f6ab-9c07-11
 d1-f79f-00c04fc2dcd2;;BA)(OA;;CR;1131f6ac-9c07-11d1-f79f-00c04fc2dcd2;;BA)(A;;
 LCRPLORC;;;AU)(A;;CCLCSWRPWPLOCRRCWDWO;;;DA)(A;CI;CCLCSWRPWPLOCRSDRCWDWO;;;BA)
 (A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;CI;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;EA)(A;C
 I;LC;;;RU)(OA;CIIO;RP;037088f8-0ae1-11d2-b422-00a0c968f939;bf967aba-0de6-11d0-
 a285-00aa003049e2;RU)(OA;CIIO;RP;59ba2f42-79a2-11d0-9020-00c04fc2d3cf;bf967aba
 -0de6-11d0-a285-00aa003049e2;RU)(OA;CIIO;RP;bc0ac240-79a9-11d0-9020-00c04fc2d4
 cf;bf967aba-0de6-11d0-a285-00aa003049e2;RU)(OA;CIIO;RP;4c164200-20c0-11d0-a768
 -00aa006e0529;bf967aba-0de6-11d0-a285-00aa003049e2;RU)(OA;CIIO;RP;5f202010-79a
 5-11d0-9020-00c04fc2d4cf;bf967aba-0de6-11d0-a285-00aa003049e2;RU)(OA;;RP;c7407
 360-20bf-11d0-a768-00aa006e0529;;RU)(OA;CIIO;LCRPLORC;;bf967a9c-0de6-11d0-a285
 -00aa003049e2;RU)(A;;RPRC;;;RU)(OA;CIIO;LCRPLORC;;bf967aba-0de6-11d0-a285-00aa
 003049e2;RU)(A;;LCRPLORC;;;ED)(OA;CIIO;RP;037088f8-0ae1-11d2-b422-00a0c968f939
 ;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;CIIO;RP;59ba2f42-79a2-11d0-9020-0
 0c04fc2d3cf;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;CIIO;RP;bc0ac240-79a9-
 11d0-9020-00c04fc2d4cf;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;CIIO;RP;4c1
 64200-20c0-11d0-a768-00aa006e0529;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;
 CIIO;RP;5f202010-79a5-11d0-9020-00c04fc2d4cf;4828cc14-1437-45bc-9b07-ad6f015e5
 f28;RU)(OA;CIIO;LCRPLORC;;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;;RP;b811
 9fd0-04f6-4762-ab7a-4986c76b3f9a;;RU)(OA;;RP;b8119fd0-04f6-4762-ab7a-4986c76b3
 f9a;;AU)(OA;CIIO;RP;b7c69e6d-2cc7-11d2-854e-00a0c983f608;bf967aba-0de6-11d0-a2
 85-00aa003049e2;ED)(OA;CIIO;RP;b7c69e6d-2cc7-11d2-854e-00a0c983f608;bf967a9c-0
 de6-11d0-a285-00aa003049e2;ED)(OA;CIIO;RP;b7c69e6d-2cc7-11d2-854e-00a0c983f608
 ;bf967a86-0de6-11d0-a285-00aa003049e2;ED)(OA;;CR;1131f6ad-9c07-11d1-f79f-00c04
 fc2dcd2;;DD)(OA;;CR;1131f6ad-9c07-11d1-f79f-00c04fc2dcd2;;BA)(OA;;CR;e2a36dc9-
 ae17-47c3-b58b-be34c55ba633;;S-1-5-32-557)(OA;;CR;280f369c-67c7-438e-ae98-1d46
 f3c6f541;;AU)(OA;;CR;ccc2dc7d-a6ad-4a7a-8846-c04e3cc53501;;AU)(OA;;CR;05c74c5e
 -4deb-43b4-bd9f-86664c2a7fd5;;AU)(OA;CIIO;RPWPCR;91e647de-d96f-4b70-9557-d63ff
 4f3ccd8;;PS)(OA;;CR;1131f6ae-9c07-11d1-f79f-00c04fc2dcd2;;BA)(OA;;CR;1131f6ae-
 9c07-11d1-f79f-00c04fc2dcd2;;ED)(OA;;CR;1131f6aa-9c07-11d1-f79f-00c04fc2dcd2;;
 S-1-5-21-2980567832-1982779670-3596228598-498)(OA;;CR;89e95b76-444d-4c62-991a-
 0facbeda640c;;ED)(OA;;CR;89e95b76-444d-4c62-991a-0facbeda640c;;BA)S:(AU;SA;WPW
 DWO;;;WD)(AU;SA;CR;;;BA)(AU;SA;CR;;;DU)(OU;CISA;WP;f30e3bbe-9ff0-11d1-b603-000
 0f80367c1;bf967aa5-0de6-11d0-a285-00aa003049e2;WD)(OU;CISA;WP;f30e3bbf-9ff0-11
 d1-b603-0000f80367c1;bf967aa5-0de6-11d0-a285-00aa003049e2;WD)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Domain-DNS,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Domain-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Domain-Policy
distinguishedName: 
 CN=Domain-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4912
subClassOf: leaf
governsID: 1.2.840.113556.1.5.18
rDNAttID: cn
uSNChanged: 4912
showInAdvancedViewOnly: TRUE
adminDisplayName: Domain-Policy
adminDescription: Domain-Policy
objectClassCategory: 1
lDAPDisplayName: domainPolicy
name: Domain-Policy
objectGUID:: qpSHCLkCnEmcnlqusrYmug==
schemaIDGUID:: mXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemPossSuperiors: container
systemMayContain: qualityOfService
systemMayContain: pwdProperties
systemMayContain: pwdHistoryLength
systemMayContain: publicKeyPolicy
systemMayContain: proxyLifetime
systemMayContain: minTicketAge
systemMayContain: minPwdLength
systemMayContain: minPwdAge
systemMayContain: maxTicketAge
systemMayContain: maxRenewAge
systemMayContain: maxPwdAge
systemMayContain: managedBy
systemMayContain: lockoutThreshold
systemMayContain: lockoutDuration
systemMayContain: lockOutObservationWindow
systemMayContain: ipsecPolicyReference
systemMayContain: forceLogoff
systemMayContain: eFSPolicy
systemMayContain: domainWidePolicy
systemMayContain: domainPolicyReference
systemMayContain: domainCAs
systemMayContain: defaultLocalPolicyObject
systemMayContain: authenticationOptions
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Domain-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=domainRelatedObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: domainRelatedObject
distinguishedName: 
 CN=domainRelatedObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4914
subClassOf: top
governsID: 0.9.2342.19200300.100.4.17
mayContain: associatedDomain
rDNAttID: cn
uSNChanged: 4914
showInAdvancedViewOnly: TRUE
adminDisplayName: domainRelatedObject
adminDescription: 
 The domainRelatedObject object class is used to define an entry which represen
 ts a series of documents.
objectClassCategory: 3
lDAPDisplayName: domainRelatedObject
name: domainRelatedObject
objectGUID:: XnIQlxW9oEGbgPy63XdOgg==
schemaIDGUID:: PS39i9rvSUWFLPheE3rtxg==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=domainRelatedObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=DS-UI-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: DS-UI-Settings
distinguishedName: 
 CN=DS-UI-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4916
subClassOf: top
governsID: 1.2.840.113556.1.5.183
rDNAttID: cn
uSNChanged: 4916
showInAdvancedViewOnly: TRUE
adminDisplayName: DS-UI-Settings
adminDescription: DS-UI-Settings
objectClassCategory: 1
lDAPDisplayName: dSUISettings
name: DS-UI-Settings
objectGUID:: OwxaBvCYZUyIUQaUR5d8Vg==
schemaIDGUID:: FA+xCZNv0hGZBQAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: msDS-Non-Security-Group-Extra-Classes
systemMayContain: msDS-Security-Group-Extra-Classes
systemMayContain: msDS-FilterContainers
systemMayContain: dSUIShellMaximum
systemMayContain: dSUIAdminNotification
systemMayContain: dSUIAdminMaximum
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=DS-UI-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=DSA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: DSA
distinguishedName: CN=DSA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4918
subClassOf: applicationEntity
governsID: 2.5.6.13
rDNAttID: cn
uSNChanged: 4918
showInAdvancedViewOnly: TRUE
adminDisplayName: DSA
adminDescription: DSA
objectClassCategory: 1
lDAPDisplayName: dSA
name: DSA
objectGUID:: soF5gISZA0enzE6o6WIb2w==
schemaIDGUID:: Uu7fP/RH0RGpwwAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: server
systemPossSuperiors: computer
systemMayContain: knowledgeInformation
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=DSA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Dynamic-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Dynamic-Object
description: 
 This class, if present in an entry, indicates that this entry has a limited li
 fetime and may disappear automatically when its time-to-live has reached 0. If
  the client has not supplied a value for the entryTtl attribute, the server wi
 ll provide one.
distinguishedName: 
 CN=Dynamic-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4920
subClassOf: top
governsID: 1.3.6.1.4.1.1466.101.119.2
rDNAttID: cn
uSNChanged: 4920
showInAdvancedViewOnly: TRUE
adminDisplayName: Dynamic-Object
adminDescription: Dynamic-Object
objectClassCategory: 3
lDAPDisplayName: dynamicObject
name: Dynamic-Object
objectGUID:: aRxAT1GyWkSJtgwTihVWQg==
schemaIDGUID:: SRLVZlUzH0yyToHyUqyiOw==
systemOnly: FALSE
systemMayContain: msDS-Entry-Time-To-Die
systemMayContain: entryTTL
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Dynamic-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=File-Link-Tracking,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: File-Link-Tracking
distinguishedName: 
 CN=File-Link-Tracking,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4922
subClassOf: top
governsID: 1.2.840.113556.1.5.52
rDNAttID: cn
uSNChanged: 4922
showInAdvancedViewOnly: TRUE
adminDisplayName: File-Link-Tracking
adminDescription: File-Link-Tracking
objectClassCategory: 1
lDAPDisplayName: fileLinkTracking
name: File-Link-Tracking
objectGUID:: IqneiQFwlk+q3kJ1zak0EA==
schemaIDGUID:: KSJx3eQQ0BGgXwCqAGwz7Q==
systemOnly: FALSE
systemPossSuperiors: container
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=File-Link-Tracking,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=File-Link-Tracking-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: File-Link-Tracking-Entry
distinguishedName: 
 CN=File-Link-Tracking-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4924
subClassOf: top
governsID: 1.2.840.113556.1.5.59
rDNAttID: cn
uSNChanged: 4924
showInAdvancedViewOnly: TRUE
adminDisplayName: File-Link-Tracking-Entry
adminDescription: File-Link-Tracking-Entry
objectClassCategory: 1
lDAPDisplayName: fileLinkTrackingEntry
name: File-Link-Tracking-Entry
objectGUID:: v2rhLGZ70EqkSp+Nq8J25w==
schemaIDGUID:: 7bJOjhJH0BGhoADAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: fileLinkTracking
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=File-Link-Tracking-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Foreign-Security-Principal,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Foreign-Security-Principal
distinguishedName: 
 CN=Foreign-Security-Principal,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=b
 e
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4926
subClassOf: top
governsID: 1.2.840.113556.1.5.76
rDNAttID: cn
uSNChanged: 4926
showInAdvancedViewOnly: TRUE
adminDisplayName: Foreign-Security-Principal
adminDescription: Foreign-Security-Principal
objectClassCategory: 1
lDAPDisplayName: foreignSecurityPrincipal
name: Foreign-Security-Principal
objectGUID:: Ki+4BBmeH0+P6xKuzg8bSw==
schemaIDGUID:: EhzjiTCF0BGv2gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: foreignIdentifier
systemMustContain: objectSid
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPWPCRCCDCLCLORCWOWDSDDTSW;;;AO)(A;;RPLCLORC;;;PS)(OA;;CR;ab721a53-1e2f-11d0-9
 819-00aa0040529b;;PS)(OA;;CR;ab721a54-1e2f-11d0-9819-00aa0040529b;;PS)(OA;;CR;
 ab721a56-1e2f-11d0-9819-00aa0040529b;;PS)(OA;;RPWP;77B5B886-944A-11d1-AEBD-000
 0F80367C1;;PS)(OA;;RPWP;E45795B2-9455-11d1-AEBD-0000F80367C1;;PS)(OA;;RPWP;E45
 795B3-9455-11d1-AEBD-0000F80367C1;;PS)(A;;RC;;;AU)(OA;;RP;59ba2f42-79a2-11d0-9
 020-00c04fc2d3cf;;AU)(OA;;RP;77B5B886-944A-11d1-AEBD-0000F80367C1;;AU)(OA;;RP;
 E45795B3-9455-11d1-AEBD-0000F80367C1;;AU)(OA;;RP;e48d0154-bcf8-11d1-8702-00c04
 fb96050;;AU)(OA;;CR;ab721a53-1e2f-11d0-9819-00aa0040529b;;WD)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Foreign-Security-Principal,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=b
 e
dSCorePropagationData: 16010101000000.0Z

dn: CN=friendlyCountry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: friendlyCountry
distinguishedName: 
 CN=friendlyCountry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4928
subClassOf: country
governsID: 0.9.2342.19200300.100.4.18
mustContain: co
rDNAttID: cn
uSNChanged: 4928
showInAdvancedViewOnly: TRUE
adminDisplayName: friendlyCountry
adminDescription: 
 The friendlyCountry object class is used to define country entries in the DIT.
objectClassCategory: 1
lDAPDisplayName: friendlyCountry
name: friendlyCountry
objectGUID:: Mi6t51YEsEy/SXG/B92/Wg==
schemaIDGUID:: UvGYxGvcSkefUnzbo9fTUQ==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=friendlyCountry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=FT-Dfs,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: FT-Dfs
distinguishedName: CN=FT-Dfs,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4930
subClassOf: top
governsID: 1.2.840.113556.1.5.43
rDNAttID: cn
uSNChanged: 4930
showInAdvancedViewOnly: TRUE
adminDisplayName: FT-Dfs
adminDescription: FT-Dfs
objectClassCategory: 1
lDAPDisplayName: fTDfs
name: FT-Dfs
objectGUID:: 9ufv7l7QvkiFJjrgVOe5Lg==
schemaIDGUID:: 8/lHhCcQ0BGgXwCqAGwz7Q==
systemOnly: FALSE
systemPossSuperiors: dfsConfiguration
systemMayContain: uNCName
systemMayContain: managedBy
systemMayContain: keywords
systemMustContain: remoteServerName
systemMustContain: pKTGuid
systemMustContain: pKT
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)(A;;RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=FT-Dfs,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Group-Of-Names,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Group-Of-Names
distinguishedName: 
 CN=Group-Of-Names,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4932
subClassOf: top
governsID: 2.5.6.9
rDNAttID: cn
uSNChanged: 4932
showInAdvancedViewOnly: TRUE
adminDisplayName: Group-Of-Names
adminDescription: Group-Of-Names
objectClassCategory: 0
lDAPDisplayName: groupOfNames
name: Group-Of-Names
objectGUID:: RQzwO3idV0KOovFcNRrMXA==
schemaIDGUID:: nXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: locality
systemPossSuperiors: organization
systemPossSuperiors: container
systemMayContain: seeAlso
systemMayContain: owner
systemMayContain: ou
systemMayContain: o
systemMayContain: businessCategory
systemMustContain: member
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Group-Of-Names,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=groupOfUniqueNames,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: groupOfUniqueNames
distinguishedName: 
 CN=groupOfUniqueNames,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
possSuperiors: domainDNS
possSuperiors: organizationalUnit
possSuperiors: container
uSNCreated: 4934
subClassOf: top
governsID: 2.5.6.17
mustContain: uniqueMember
mustContain: cn
mayContain: seeAlso
mayContain: owner
mayContain: ou
mayContain: o
mayContain: description
mayContain: businessCategory
rDNAttID: cn
uSNChanged: 4934
showInAdvancedViewOnly: FALSE
adminDisplayName: groupOfUniqueNames
adminDescription: Defines the entries for a group of unique names.
objectClassCategory: 1
lDAPDisplayName: groupOfUniqueNames
name: groupOfUniqueNames
objectGUID:: AF9gHD6k6Uq0ONknYkkdOw==
schemaIDGUID:: EakQA6OTIU6no1XYWrLEiw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;AO)(A;;RPLCLORC;;;PS)
systemFlags: 0
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=groupOfUniqueNames,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Group-Policy-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Group-Policy-Container
distinguishedName: 
 CN=Group-Policy-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4936
subClassOf: container
governsID: 1.2.840.113556.1.5.157
rDNAttID: cn
uSNChanged: 4936
showInAdvancedViewOnly: TRUE
adminDisplayName: Group-Policy-Container
adminDescription: Group-Policy-Container
objectClassCategory: 1
lDAPDisplayName: groupPolicyContainer
name: Group-Policy-Container
objectGUID:: bPP1u7/Pu0+40N/wmup0Yg==
schemaIDGUID:: wjsO8/Cf0RG2AwAA+ANnwQ==
systemOnly: FALSE
systemMayContain: versionNumber
systemMayContain: gPCWQLFilter
systemMayContain: gPCUserExtensionNames
systemMayContain: gPCMachineExtensionNames
systemMayContain: gPCFunctionalityVersion
systemMayContain: gPCFileSysPath
systemMayContain: flags
defaultSecurityDescriptor: 
 D:P(A;CI;RPWPCCDCLCLOLORCWOWDSDDTSW;;;DA)(A;CI;RPWPCCDCLCLOLORCWOWDSDDTSW;;;EA
 )(A;CI;RPWPCCDCLCLOLORCWOWDSDDTSW;;;CO)(A;CI;RPWPCCDCLCLORCWOWDSDDTSW;;;SY)(A;
 CI;RPLCLORC;;;AU)(OA;CI;CR;edacfd8f-ffb3-11d1-b41d-00a0c968f939;;AU)(A;CI;LCRP
 LORC;;;ED)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Group-Policy-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Index-Server-Catalog,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Index-Server-Catalog
distinguishedName: 
 CN=Index-Server-Catalog,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4938
subClassOf: connectionPoint
governsID: 1.2.840.113556.1.5.130
rDNAttID: cn
uSNChanged: 4938
showInAdvancedViewOnly: TRUE
adminDisplayName: Index-Server-Catalog
adminDescription: Index-Server-Catalog
objectClassCategory: 1
lDAPDisplayName: indexServerCatalog
name: Index-Server-Catalog
objectGUID:: 7wBl+VslSEe4yGZCLFkz+g==
schemaIDGUID:: isv9ewdI0RGpwwAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
systemMayContain: uNCName
systemMayContain: queryPoint
systemMayContain: indexedScopes
systemMayContain: friendlyNames
systemMustContain: creator
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Index-Server-Catalog,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Infrastructure-Update,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Infrastructure-Update
distinguishedName: 
 CN=Infrastructure-Update,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4940
subClassOf: top
governsID: 1.2.840.113556.1.5.175
rDNAttID: cn
uSNChanged: 4940
showInAdvancedViewOnly: TRUE
adminDisplayName: Infrastructure-Update
adminDescription: Infrastructure-Update
objectClassCategory: 1
lDAPDisplayName: infrastructureUpdate
name: Infrastructure-Update
objectGUID:: GYeCu+bVp0Ov5ZnH+ihbdw==
schemaIDGUID:: iQ35LZ8A0hGqTADAT9fYOg==
systemOnly: TRUE
systemPossSuperiors: infrastructureUpdate
systemPossSuperiors: domain
systemMayContain: dNReferenceUpdate
defaultSecurityDescriptor: D:(A;;GA;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Infrastructure-Update,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Intellimirror-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Intellimirror-Group
distinguishedName: 
 CN=Intellimirror-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4942
subClassOf: top
governsID: 1.2.840.113556.1.5.152
rDNAttID: cn
uSNChanged: 4942
showInAdvancedViewOnly: TRUE
adminDisplayName: Intellimirror-Group
adminDescription: Intellimirror-Group
objectClassCategory: 1
lDAPDisplayName: intellimirrorGroup
name: Intellimirror-Group
objectGUID:: KSRvHCy9+kSWfcoJWRfYBQ==
schemaIDGUID:: hjA4B9+R0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;
 CCDC;;;CO)(A;;RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Intellimirror-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Intellimirror-SCP,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Intellimirror-SCP
distinguishedName: 
 CN=Intellimirror-SCP,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4944
subClassOf: serviceAdministrationPoint
governsID: 1.2.840.113556.1.5.151
rDNAttID: cn
uSNChanged: 4944
showInAdvancedViewOnly: TRUE
adminDisplayName: Intellimirror-SCP
adminDescription: Intellimirror-SCP
objectClassCategory: 1
lDAPDisplayName: intellimirrorSCP
name: Intellimirror-SCP
objectGUID:: 6ksFeDWBC02rAfaaHsbVuA==
schemaIDGUID:: hTA4B9+R0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: computer
systemPossSuperiors: intellimirrorGroup
systemMayContain: netbootTools
systemMayContain: netbootServer
systemMayContain: netbootNewMachineOU
systemMayContain: netbootNewMachineNamingPolicy
systemMayContain: netbootMaxClients
systemMayContain: netbootMachineFilePath
systemMayContain: netbootLocallyInstalledOSes
systemMayContain: netbootLimitClients
systemMayContain: netbootIntelliMirrorOSes
systemMayContain: netbootCurrentClientCount
systemMayContain: netbootAnswerRequests
systemMayContain: netbootAnswerOnlyValidClients
systemMayContain: netbootAllowNewClients
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Intellimirror-SCP,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Inter-Site-Transport,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Inter-Site-Transport
distinguishedName: 
 CN=Inter-Site-Transport,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4946
subClassOf: top
governsID: 1.2.840.113556.1.5.141
rDNAttID: cn
uSNChanged: 4946
showInAdvancedViewOnly: TRUE
adminDisplayName: Inter-Site-Transport
adminDescription: Inter-Site-Transport
objectClassCategory: 1
lDAPDisplayName: interSiteTransport
name: Inter-Site-Transport
objectGUID:: s23/byaZkkm7N9Lb2n26Cg==
schemaIDGUID:: dnPZJnBg0RGpxgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: interSiteTransportContainer
systemMayContain: replInterval
systemMayContain: options
systemMustContain: transportDLLName
systemMustContain: transportAddressAttribute
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Inter-Site-Transport,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Inter-Site-Transport-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Inter-Site-Transport-Container
distinguishedName: 
 CN=Inter-Site-Transport-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,
 DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4948
subClassOf: top
governsID: 1.2.840.113556.1.5.140
rDNAttID: cn
uSNChanged: 4948
showInAdvancedViewOnly: TRUE
adminDisplayName: Inter-Site-Transport-Container
adminDescription: Inter-Site-Transport-Container
objectClassCategory: 1
lDAPDisplayName: interSiteTransportContainer
name: Inter-Site-Transport-Container
objectGUID:: Lm577/CdGUuKe9DOVkR99Q==
schemaIDGUID:: dXPZJnBg0RGpxgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: sitesContainer
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Inter-Site-Transport-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,
 DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Ipsec-Base,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Ipsec-Base
distinguishedName: 
 CN=Ipsec-Base,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4950
subClassOf: top
governsID: 1.2.840.113556.1.5.7000.56
rDNAttID: cn
uSNChanged: 4950
showInAdvancedViewOnly: TRUE
adminDisplayName: Ipsec-Base
adminDescription: Ipsec-Base
objectClassCategory: 2
lDAPDisplayName: ipsecBase
name: Ipsec-Base
objectGUID:: 6/DsI5CkWUO+A0tnQIUNIQ==
schemaIDGUID:: JfgPtHpC0RGpwgAA+ANnwQ==
systemOnly: FALSE
systemMayContain: ipsecOwnersReference
systemMayContain: ipsecName
systemMayContain: ipsecID
systemMayContain: ipsecDataType
systemMayContain: ipsecData
defaultSecurityDescriptor: D:
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Ipsec-Base,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Ipsec-Filter,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Ipsec-Filter
distinguishedName: 
 CN=Ipsec-Filter,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4952
subClassOf: ipsecBase
governsID: 1.2.840.113556.1.5.118
rDNAttID: cn
uSNChanged: 4952
showInAdvancedViewOnly: TRUE
adminDisplayName: Ipsec-Filter
adminDescription: Ipsec-Filter
objectClassCategory: 1
lDAPDisplayName: ipsecFilter
name: Ipsec-Filter
objectGUID:: Oj7VYGie6Ei6tFBLeGypzA==
schemaIDGUID:: JvgPtHpC0RGpwgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: computer
systemPossSuperiors: container
defaultSecurityDescriptor: D:
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Ipsec-Filter,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Ipsec-ISAKMP-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Ipsec-ISAKMP-Policy
distinguishedName: 
 CN=Ipsec-ISAKMP-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4954
subClassOf: ipsecBase
governsID: 1.2.840.113556.1.5.120
rDNAttID: cn
uSNChanged: 4954
showInAdvancedViewOnly: TRUE
adminDisplayName: Ipsec-ISAKMP-Policy
adminDescription: Ipsec-ISAKMP-Policy
objectClassCategory: 1
lDAPDisplayName: ipsecISAKMPPolicy
name: Ipsec-ISAKMP-Policy
objectGUID:: vvNiqZ3hkk2cyF2Wd4VKNQ==
schemaIDGUID:: KPgPtHpC0RGpwgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemPossSuperiors: computer
systemPossSuperiors: organizationalUnit
defaultSecurityDescriptor: D:
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Ipsec-ISAKMP-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Ipsec-Negotiation-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Ipsec-Negotiation-Policy
distinguishedName: 
 CN=Ipsec-Negotiation-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4956
subClassOf: ipsecBase
governsID: 1.2.840.113556.1.5.119
rDNAttID: cn
uSNChanged: 4956
showInAdvancedViewOnly: TRUE
adminDisplayName: Ipsec-Negotiation-Policy
adminDescription: Ipsec-Negotiation-Policy
objectClassCategory: 1
lDAPDisplayName: ipsecNegotiationPolicy
name: Ipsec-Negotiation-Policy
objectGUID:: oCtVif1WZUeMJ7G9phz+rg==
schemaIDGUID:: J/gPtHpC0RGpwgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: computer
systemPossSuperiors: container
systemMayContain: iPSECNegotiationPolicyType
systemMayContain: iPSECNegotiationPolicyAction
defaultSecurityDescriptor: D:
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Ipsec-Negotiation-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Ipsec-NFA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Ipsec-NFA
distinguishedName: 
 CN=Ipsec-NFA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4958
subClassOf: ipsecBase
governsID: 1.2.840.113556.1.5.121
rDNAttID: cn
uSNChanged: 4958
showInAdvancedViewOnly: TRUE
adminDisplayName: Ipsec-NFA
adminDescription: Ipsec-NFA
objectClassCategory: 1
lDAPDisplayName: ipsecNFA
name: Ipsec-NFA
objectGUID:: E96cMQy9A0aqOeUHwW47Ow==
schemaIDGUID:: KfgPtHpC0RGpwgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemPossSuperiors: computer
systemPossSuperiors: organizationalUnit
systemMayContain: ipsecNegotiationPolicyReference
systemMayContain: ipsecFilterReference
defaultSecurityDescriptor: D:
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Ipsec-NFA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Ipsec-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Ipsec-Policy
distinguishedName: 
 CN=Ipsec-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4960
subClassOf: ipsecBase
governsID: 1.2.840.113556.1.5.98
rDNAttID: cn
uSNChanged: 4960
showInAdvancedViewOnly: TRUE
adminDisplayName: Ipsec-Policy
adminDescription: Ipsec-Policy
objectClassCategory: 1
lDAPDisplayName: ipsecPolicy
name: Ipsec-Policy
objectGUID:: jfBdWanNp0+G/R+MYTSIIw==
schemaIDGUID:: ITGxty640BGv7gAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: computer
systemPossSuperiors: container
systemMayContain: ipsecNFAReference
systemMayContain: ipsecISAKMPReference
defaultSecurityDescriptor: D:
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Ipsec-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Leaf,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Leaf
distinguishedName: CN=Leaf,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4962
subClassOf: top
governsID: 1.2.840.113556.1.5.20
rDNAttID: cn
uSNChanged: 4962
showInAdvancedViewOnly: TRUE
adminDisplayName: Leaf
adminDescription: Leaf
objectClassCategory: 2
lDAPDisplayName: leaf
name: Leaf
objectGUID:: Cg1tfkvDfUe4mSoga/lAzA==
schemaIDGUID:: nnqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Leaf,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Licensing-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Licensing-Site-Settings
distinguishedName: 
 CN=Licensing-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4964
subClassOf: applicationSiteSettings
governsID: 1.2.840.113556.1.5.78
rDNAttID: cn
uSNChanged: 4964
showInAdvancedViewOnly: TRUE
adminDisplayName: Licensing-Site-Settings
adminDescription: Licensing-Site-Settings
objectClassCategory: 1
lDAPDisplayName: licensingSiteSettings
name: Licensing-Site-Settings
objectGUID:: eztCLC3rFkqYSew/4o63UA==
schemaIDGUID:: ffHoG/+p0BGv4gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: site
systemMayContain: siteServer
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Licensing-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Link-Track-Object-Move-Table,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Link-Track-Object-Move-Table
distinguishedName: 
 CN=Link-Track-Object-Move-Table,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC
 =be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4966
subClassOf: fileLinkTracking
governsID: 1.2.840.113556.1.5.91
rDNAttID: cn
uSNChanged: 4966
showInAdvancedViewOnly: TRUE
adminDisplayName: Link-Track-Object-Move-Table
adminDescription: Link-Track-Object-Move-Table
objectClassCategory: 1
lDAPDisplayName: linkTrackObjectMoveTable
name: Link-Track-Object-Move-Table
objectGUID:: RMDxbT64qUSab2F9XM2dVA==
schemaIDGUID:: 9Qys3Y+v0BGv6wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: fileLinkTracking
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Link-Track-Object-Move-Table,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC
 =be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Link-Track-OMT-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Link-Track-OMT-Entry
distinguishedName: 
 CN=Link-Track-OMT-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4968
subClassOf: leaf
governsID: 1.2.840.113556.1.5.93
rDNAttID: cn
uSNChanged: 4968
showInAdvancedViewOnly: TRUE
adminDisplayName: Link-Track-OMT-Entry
adminDescription: Link-Track-OMT-Entry
objectClassCategory: 1
lDAPDisplayName: linkTrackOMTEntry
name: Link-Track-OMT-Entry
objectGUID:: Vu3N6w49VE6BT5gDz9DWNA==
schemaIDGUID:: 9wys3Y+v0BGv6wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: linkTrackObjectMoveTable
systemMayContain: timeRefresh
systemMayContain: oMTIndxGuid
systemMayContain: oMTGuid
systemMayContain: currentLocation
systemMayContain: birthLocation
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Link-Track-OMT-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Link-Track-Vol-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Link-Track-Vol-Entry
distinguishedName: 
 CN=Link-Track-Vol-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4970
subClassOf: leaf
governsID: 1.2.840.113556.1.5.92
rDNAttID: cn
uSNChanged: 4970
showInAdvancedViewOnly: TRUE
adminDisplayName: Link-Track-Vol-Entry
adminDescription: Link-Track-Vol-Entry
objectClassCategory: 1
lDAPDisplayName: linkTrackVolEntry
name: Link-Track-Vol-Entry
objectGUID:: 8E756e6t30q/8l6tvmaCuQ==
schemaIDGUID:: 9gys3Y+v0BGv6wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: linkTrackVolumeTable
systemMayContain: volTableIdxGUID
systemMayContain: volTableGUID
systemMayContain: timeVolChange
systemMayContain: timeRefresh
systemMayContain: seqNotification
systemMayContain: objectCount
systemMayContain: linkTrackSecret
systemMayContain: currMachineId
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Link-Track-Vol-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Link-Track-Volume-Table,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Link-Track-Volume-Table
distinguishedName: 
 CN=Link-Track-Volume-Table,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4972
subClassOf: fileLinkTracking
governsID: 1.2.840.113556.1.5.90
rDNAttID: cn
uSNChanged: 4972
showInAdvancedViewOnly: TRUE
adminDisplayName: Link-Track-Volume-Table
adminDescription: Link-Track-Volume-Table
objectClassCategory: 1
lDAPDisplayName: linkTrackVolumeTable
name: Link-Track-Volume-Table
objectGUID:: YWgZY6Jt90uxkkvpqi5YUA==
schemaIDGUID:: 9Ays3Y+v0BGv6wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: fileLinkTracking
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Link-Track-Volume-Table,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Locality,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Locality
distinguishedName: 
 CN=Locality,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4974
subClassOf: top
governsID: 2.5.6.3
rDNAttID: l
uSNChanged: 4974
showInAdvancedViewOnly: TRUE
adminDisplayName: Locality
adminDescription: Locality
objectClassCategory: 1
lDAPDisplayName: locality
name: Locality
objectGUID:: N11p8INwC0uQ5U/n6bqFyg==
schemaIDGUID:: oHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemPossSuperiors: country
systemPossSuperiors: organizationalUnit
systemPossSuperiors: organization
systemPossSuperiors: locality
systemMayContain: street
systemMayContain: st
systemMayContain: seeAlso
systemMayContain: searchGuide
systemMustContain: l
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Locality,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Lost-And-Found,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Lost-And-Found
distinguishedName: 
 CN=Lost-And-Found,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4976
subClassOf: top
governsID: 1.2.840.113556.1.5.139
rDNAttID: cn
uSNChanged: 4976
showInAdvancedViewOnly: TRUE
adminDisplayName: Lost-And-Found
adminDescription: Lost-And-Found
objectClassCategory: 1
lDAPDisplayName: lostAndFound
name: Lost-And-Found
objectGUID:: flHEOkNpQ0OsWMEb2t1ftg==
schemaIDGUID:: cYarUglX0RGpxgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: configuration
systemPossSuperiors: domainDNS
systemPossSuperiors: dMD
systemMayContain: moveTreeState
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Lost-And-Found,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Meeting,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Meeting
distinguishedName: 
 CN=Meeting,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4978
subClassOf: top
governsID: 1.2.840.113556.1.5.104
rDNAttID: cn
uSNChanged: 4978
showInAdvancedViewOnly: TRUE
adminDisplayName: Meeting
adminDescription: Meeting
objectClassCategory: 1
lDAPDisplayName: meeting
name: Meeting
objectGUID:: blAe3dEVAESW7S2Eldooww==
schemaIDGUID:: lMy2EcRI0RGpwwAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: meetingURL
systemMayContain: meetingType
systemMayContain: meetingStartTime
systemMayContain: meetingScope
systemMayContain: meetingRecurrence
systemMayContain: meetingRating
systemMayContain: meetingProtocol
systemMayContain: meetingOwner
systemMayContain: meetingOriginator
systemMayContain: meetingMaxParticipants
systemMayContain: meetingLocation
systemMayContain: meetingLanguage
systemMayContain: meetingKeyword
systemMayContain: meetingIsEncrypted
systemMayContain: meetingIP
systemMayContain: meetingID
systemMayContain: meetingEndTime
systemMayContain: meetingDescription
systemMayContain: meetingContactInfo
systemMayContain: meetingBlob
systemMayContain: meetingBandwidth
systemMayContain: meetingApplication
systemMayContain: meetingAdvertiseScope
systemMustContain: meetingName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Meeting,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-COM-Partition,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-COM-Partition
distinguishedName: 
 CN=ms-COM-Partition,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4980
subClassOf: top
governsID: 1.2.840.113556.1.5.193
rDNAttID: cn
uSNChanged: 4980
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-COM-Partition
adminDescription: Partition class. Default = adminDisplayName
objectClassCategory: 1
lDAPDisplayName: msCOM-Partition
name: ms-COM-Partition
objectGUID:: 4VvsdAKNmE6Hv+FBvux+Ig==
schemaIDGUID:: dA4ByVhO90mKiV4+I0D8+A==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
systemMayContain: msCOM-ObjectId
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-COM-Partition,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-COM-PartitionSet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-COM-PartitionSet
distinguishedName: 
 CN=ms-COM-PartitionSet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4982
subClassOf: top
governsID: 1.2.840.113556.1.5.194
rDNAttID: cn
uSNChanged: 4982
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-COM-PartitionSet
adminDescription: PartitionSet class. Default = adminDisplayName
objectClassCategory: 1
lDAPDisplayName: msCOM-PartitionSet
name: ms-COM-PartitionSet
objectGUID:: 27Vm4GQWs0+kiDoqJxXHcw==
schemaIDGUID:: q2QEJRfEekmXWp4NRZp8oQ==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
systemMayContain: msCOM-PartitionLink
systemMayContain: msCOM-DefaultPartitionLink
systemMayContain: msCOM-ObjectId
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-COM-PartitionSet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-App-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-App-Configuration
distinguishedName: 
 CN=ms-DS-App-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
possSuperiors: organizationalUnit
possSuperiors: computer
possSuperiors: container
uSNCreated: 4984
subClassOf: applicationSettings
governsID: 1.2.840.113556.1.5.220
mayContain: owner
mayContain: msDS-ObjectReference
mayContain: msDS-Integer
mayContain: msDS-DateTime
mayContain: msDS-ByteArray
mayContain: managedBy
mayContain: keywords
rDNAttID: cn
uSNChanged: 4984
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DS-App-Configuration
adminDescription: Stores configuration parameters for an application.
objectClassCategory: 1
lDAPDisplayName: msDS-App-Configuration
name: ms-DS-App-Configuration
objectGUID:: jei95Artq0uzLcMHcyNALw==
schemaIDGUID:: PjzfkFQYVUSl18rUDVZleg==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 0
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-App-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-App-Data,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-App-Data
distinguishedName: 
 CN=ms-DS-App-Data,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
possSuperiors: organizationalUnit
possSuperiors: computer
possSuperiors: container
uSNCreated: 4986
subClassOf: applicationSettings
governsID: 1.2.840.113556.1.5.241
mayContain: owner
mayContain: msDS-ObjectReference
mayContain: msDS-Integer
mayContain: msDS-DateTime
mayContain: msDS-ByteArray
mayContain: managedBy
mayContain: keywords
rDNAttID: cn
uSNChanged: 4986
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DS-App-Data
adminDescription: 
 Stores data that is to be used by an object. For example, profile information 
 for a user object.
objectClassCategory: 1
lDAPDisplayName: msDS-AppData
name: ms-DS-App-Data
objectGUID:: bbbdHuMXlEufOC//9jgdzQ==
schemaIDGUID:: YddnnifjVU28lWgvh14vjg==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 0
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-App-Data,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Quota-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Quota-Container
distinguishedName: 
 CN=ms-DS-Quota-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4988
subClassOf: top
governsID: 1.2.840.113556.1.5.242
rDNAttID: cn
uSNChanged: 4988
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DS-Quota-Container
adminDescription: 
 A special container that holds all quota specifications for the directory data
 base.
objectClassCategory: 1
lDAPDisplayName: msDS-QuotaContainer
name: ms-DS-Quota-Container
objectGUID:: CHFuHGJ0H0KG5PEBHr8bRA==
schemaIDGUID:: T/yD2m8H6kq03I9Nq5tZkw==
systemOnly: FALSE
systemPossSuperiors: configuration
systemPossSuperiors: domainDNS
systemMayContain: msDS-TopQuotaUsage
systemMayContain: msDS-QuotaUsed
systemMayContain: msDS-QuotaEffective
systemMayContain: msDS-TombstoneQuotaFactor
systemMayContain: msDS-DefaultQuota
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPLCLORC;;;BA)(OA;;CR;4ecc03fe-ffc0-
 4947-b630-eb672a8a9dbc;;WD)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Quota-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Quota-Control,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Quota-Control
distinguishedName: 
 CN=ms-DS-Quota-Control,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4990
subClassOf: top
governsID: 1.2.840.113556.1.5.243
rDNAttID: cn
uSNChanged: 4990
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DS-Quota-Control
adminDescription: 
 A class used to represent quota specifications for the directory database.
objectClassCategory: 1
lDAPDisplayName: msDS-QuotaControl
name: ms-DS-Quota-Control
objectGUID:: +AC2zkN7akGoKXAi8D/rKA==
schemaIDGUID:: JvyR3gK9UkuuJnlZmelvxw==
systemOnly: FALSE
systemPossSuperiors: msDS-QuotaContainer
systemMustContain: msDS-QuotaAmount
systemMustContain: msDS-QuotaTrustee
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPLCLORC;;;BA)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Quota-Control,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-ieee-80211-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-ieee-80211-Policy
distinguishedName: 
 CN=ms-ieee-80211-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4992
subClassOf: top
governsID: 1.2.840.113556.1.5.240
rDNAttID: cn
uSNChanged: 4992
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-ieee-80211-Policy
adminDescription: class to store Wireless Network Policy Object
objectClassCategory: 1
lDAPDisplayName: msieee80211-Policy
name: ms-ieee-80211-Policy
objectGUID:: UkWzTcgN5kOraPOlPPOang==
schemaIDGUID:: ki2ae+u3gkOXcsPg+bqvlA==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
systemPossSuperiors: computer
systemMayContain: msieee80211-ID
systemMayContain: msieee80211-DataType
systemMayContain: msieee80211-Data
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-ieee-80211-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-PKI-Enterprise-Oid,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-PKI-Enterprise-Oid
distinguishedName: 
 CN=ms-PKI-Enterprise-Oid,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4994
subClassOf: top
governsID: 1.2.840.113556.1.5.196
rDNAttID: cn
uSNChanged: 4994
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-PKI-Enterprise-Oid
adminDescription: ms-PKI-Enterprise-Oid
objectClassCategory: 1
lDAPDisplayName: msPKI-Enterprise-Oid
name: ms-PKI-Enterprise-Oid
objectGUID:: ZTyW5RV6xUO6f8TDTkIcZQ==
schemaIDGUID:: XNjPNxln2EqPnoZ4umJ1Yw==
systemOnly: FALSE
systemPossSuperiors: msPKI-Enterprise-Oid
systemPossSuperiors: container
systemMayContain: msPKI-OID-User-Notice
systemMayContain: msPKI-OIDLocalizedName
systemMayContain: msPKI-OID-CPS
systemMayContain: msPKI-OID-Attribute
systemMayContain: msPKI-Cert-Template-OID
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-PKI-Enterprise-Oid,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-PKI-Key-Recovery-Agent,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-PKI-Key-Recovery-Agent
distinguishedName: 
 CN=ms-PKI-Key-Recovery-Agent,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4996
subClassOf: user
governsID: 1.2.840.113556.1.5.195
rDNAttID: cn
uSNChanged: 4996
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-PKI-Key-Recovery-Agent
adminDescription: ms-PKI-Key-Recovery-Agent
objectClassCategory: 1
lDAPDisplayName: msPKI-Key-Recovery-Agent
name: ms-PKI-Key-Recovery-Agent
objectGUID:: HyrgiNKfBUmytzfV+gZJNg==
schemaIDGUID:: OPLMJo6ghkuagqjJrH7lyw==
systemOnly: FALSE
systemPossSuperiors: container
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-PKI-Key-Recovery-Agent,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MS-SQL-SQLServer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MS-SQL-SQLServer
distinguishedName: 
 CN=MS-SQL-SQLServer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 4998
subClassOf: serviceConnectionPoint
governsID: 1.2.840.113556.1.5.184
rDNAttID: cn
uSNChanged: 4998
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-SQL-SQLServer
adminDescription: MS-SQL-SQLServer
objectClassCategory: 1
lDAPDisplayName: mS-SQL-SQLServer
name: MS-SQL-SQLServer
objectGUID:: Dv0PiBYJ10mvxnI1axXFhA==
schemaIDGUID:: eMj2Be/M0hGZkwAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: serviceConnectionPoint
systemMayContain: mS-SQL-Keywords
systemMayContain: mS-SQL-GPSHeight
systemMayContain: mS-SQL-GPSLongitude
systemMayContain: mS-SQL-GPSLatitude
systemMayContain: mS-SQL-InformationURL
systemMayContain: mS-SQL-LastUpdatedDate
systemMayContain: mS-SQL-Status
systemMayContain: mS-SQL-Vines
systemMayContain: mS-SQL-AppleTalk
systemMayContain: mS-SQL-TCPIP
systemMayContain: mS-SQL-SPX
systemMayContain: mS-SQL-MultiProtocol
systemMayContain: mS-SQL-NamedPipe
systemMayContain: mS-SQL-Clustered
systemMayContain: mS-SQL-UnicodeSortOrder
systemMayContain: mS-SQL-SortOrder
systemMayContain: mS-SQL-CharacterSet
systemMayContain: mS-SQL-ServiceAccount
systemMayContain: mS-SQL-Build
systemMayContain: mS-SQL-Memory
systemMayContain: mS-SQL-Location
systemMayContain: mS-SQL-Contact
systemMayContain: mS-SQL-RegisteredOwner
systemMayContain: mS-SQL-Name
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MS-SQL-SQLServer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MS-SQL-OLAPServer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MS-SQL-OLAPServer
distinguishedName: 
 CN=MS-SQL-OLAPServer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5000
subClassOf: serviceConnectionPoint
governsID: 1.2.840.113556.1.5.185
rDNAttID: cn
uSNChanged: 5000
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-SQL-OLAPServer
adminDescription: MS-SQL-OLAPServer
objectClassCategory: 1
lDAPDisplayName: mS-SQL-OLAPServer
name: MS-SQL-OLAPServer
objectGUID:: i1MlUXTzFEWcw0ed0ifANg==
schemaIDGUID:: 6hh+DO/M0hGZkwAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: serviceConnectionPoint
systemMayContain: mS-SQL-Keywords
systemMayContain: mS-SQL-PublicationURL
systemMayContain: mS-SQL-InformationURL
systemMayContain: mS-SQL-Status
systemMayContain: mS-SQL-Language
systemMayContain: mS-SQL-ServiceAccount
systemMayContain: mS-SQL-Contact
systemMayContain: mS-SQL-RegisteredOwner
systemMayContain: mS-SQL-Build
systemMayContain: mS-SQL-Version
systemMayContain: mS-SQL-Name
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MS-SQL-OLAPServer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MS-SQL-SQLRepository,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MS-SQL-SQLRepository
distinguishedName: 
 CN=MS-SQL-SQLRepository,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5002
subClassOf: top
governsID: 1.2.840.113556.1.5.186
rDNAttID: cn
uSNChanged: 5002
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-SQL-SQLRepository
adminDescription: MS-SQL-SQLRepository
objectClassCategory: 1
lDAPDisplayName: mS-SQL-SQLRepository
name: MS-SQL-SQLRepository
objectGUID:: inR+BpX5aEOihBmQ935GPw==
schemaIDGUID:: XDzUEe/M0hGZkwAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: mS-SQL-SQLServer
systemMayContain: mS-SQL-InformationDirectory
systemMayContain: mS-SQL-Version
systemMayContain: mS-SQL-Description
systemMayContain: mS-SQL-Status
systemMayContain: mS-SQL-Build
systemMayContain: mS-SQL-Contact
systemMayContain: mS-SQL-Name
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MS-SQL-SQLRepository,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MS-SQL-SQLPublication,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MS-SQL-SQLPublication
distinguishedName: 
 CN=MS-SQL-SQLPublication,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5004
subClassOf: top
governsID: 1.2.840.113556.1.5.187
rDNAttID: cn
uSNChanged: 5004
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-SQL-SQLPublication
adminDescription: MS-SQL-SQLPublication
objectClassCategory: 1
lDAPDisplayName: mS-SQL-SQLPublication
name: MS-SQL-SQLPublication
objectGUID:: hnEIeC86o0WMty8D6RCBTw==
schemaIDGUID:: TvbCF+/M0hGZkwAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: mS-SQL-SQLServer
systemMayContain: mS-SQL-ThirdParty
systemMayContain: mS-SQL-AllowSnapshotFilesFTPDownloading
systemMayContain: mS-SQL-AllowQueuedUpdatingSubscription
systemMayContain: mS-SQL-AllowImmediateUpdatingSubscription
systemMayContain: mS-SQL-AllowKnownPullSubscription
systemMayContain: mS-SQL-Publisher
systemMayContain: mS-SQL-AllowAnonymousSubscription
systemMayContain: mS-SQL-Database
systemMayContain: mS-SQL-Type
systemMayContain: mS-SQL-Status
systemMayContain: mS-SQL-Description
systemMayContain: mS-SQL-Name
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MS-SQL-SQLPublication,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MS-SQL-SQLDatabase,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MS-SQL-SQLDatabase
distinguishedName: 
 CN=MS-SQL-SQLDatabase,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5006
subClassOf: top
governsID: 1.2.840.113556.1.5.188
rDNAttID: cn
uSNChanged: 5006
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-SQL-SQLDatabase
adminDescription: MS-SQL-SQLDatabase
objectClassCategory: 1
lDAPDisplayName: mS-SQL-SQLDatabase
name: MS-SQL-SQLDatabase
objectGUID:: NmBpsqM6VkOf5SQUTuyO5Q==
schemaIDGUID:: SmkIHe/M0hGZkwAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: mS-SQL-SQLServer
systemMayContain: mS-SQL-Keywords
systemMayContain: mS-SQL-InformationURL
systemMayContain: mS-SQL-Status
systemMayContain: mS-SQL-Applications
systemMayContain: mS-SQL-LastDiagnosticDate
systemMayContain: mS-SQL-LastBackupDate
systemMayContain: mS-SQL-CreationDate
systemMayContain: mS-SQL-Size
systemMayContain: mS-SQL-Contact
systemMayContain: mS-SQL-Alias
systemMayContain: mS-SQL-Description
systemMayContain: mS-SQL-Name
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MS-SQL-SQLDatabase,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MS-SQL-OLAPDatabase,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MS-SQL-OLAPDatabase
distinguishedName: 
 CN=MS-SQL-OLAPDatabase,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5008
subClassOf: top
governsID: 1.2.840.113556.1.5.189
rDNAttID: cn
uSNChanged: 5008
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-SQL-OLAPDatabase
adminDescription: MS-SQL-OLAPDatabase
objectClassCategory: 1
lDAPDisplayName: mS-SQL-OLAPDatabase
name: MS-SQL-OLAPDatabase
objectGUID:: 4GXGaZQ2H0mQVqHQjN1ryQ==
schemaIDGUID:: GgOvIO/M0hGZkwAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: mS-SQL-OLAPServer
systemMayContain: mS-SQL-Keywords
systemMayContain: mS-SQL-PublicationURL
systemMayContain: mS-SQL-ConnectionURL
systemMayContain: mS-SQL-InformationURL
systemMayContain: mS-SQL-Status
systemMayContain: mS-SQL-Applications
systemMayContain: mS-SQL-LastBackupDate
systemMayContain: mS-SQL-LastUpdatedDate
systemMayContain: mS-SQL-Size
systemMayContain: mS-SQL-Type
systemMayContain: mS-SQL-Description
systemMayContain: mS-SQL-Contact
systemMayContain: mS-SQL-Name
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MS-SQL-OLAPDatabase,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MS-SQL-OLAPCube,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MS-SQL-OLAPCube
distinguishedName: 
 CN=MS-SQL-OLAPCube,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5010
subClassOf: top
governsID: 1.2.840.113556.1.5.190
rDNAttID: cn
uSNChanged: 5010
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-SQL-OLAPCube
adminDescription: MS-SQL-OLAPCube
objectClassCategory: 1
lDAPDisplayName: mS-SQL-OLAPCube
name: MS-SQL-OLAPCube
objectGUID:: qLBaH3L4VkCX2tTx5BXJRw==
schemaIDGUID:: alDwCSjN0hGZkwAA+HpX1A==
systemOnly: FALSE
systemPossSuperiors: mS-SQL-OLAPDatabase
systemMayContain: mS-SQL-Keywords
systemMayContain: mS-SQL-PublicationURL
systemMayContain: mS-SQL-InformationURL
systemMayContain: mS-SQL-Status
systemMayContain: mS-SQL-LastUpdatedDate
systemMayContain: mS-SQL-Size
systemMayContain: mS-SQL-Description
systemMayContain: mS-SQL-Contact
systemMayContain: mS-SQL-Name
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MS-SQL-OLAPCube,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-TAPI-Rt-Conference,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-TAPI-Rt-Conference
distinguishedName: 
 CN=ms-TAPI-Rt-Conference,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5012
subClassOf: top
governsID: 1.2.840.113556.1.5.221
rDNAttID: msTAPI-uid
uSNChanged: 5012
showInAdvancedViewOnly: TRUE
adminDisplayName: msTAPI-RtConference
adminDescription: msTAPI-RtConference
objectClassCategory: 1
lDAPDisplayName: msTAPI-RtConference
name: ms-TAPI-Rt-Conference
objectGUID:: NqX4OPf+VEyziQJpyO0dgg==
schemaIDGUID:: NZd7yipLSU6Jw5kCUzTclA==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemMayContain: msTAPI-ConferenceBlob
systemMayContain: msTAPI-ProtocolId
systemMustContain: msTAPI-uid
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-TAPI-Rt-Conference,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-TAPI-Rt-Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-TAPI-Rt-Person
distinguishedName: 
 CN=ms-TAPI-Rt-Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5014
subClassOf: top
governsID: 1.2.840.113556.1.5.222
rDNAttID: cn
uSNChanged: 5014
showInAdvancedViewOnly: TRUE
adminDisplayName: msTAPI-RtPerson
adminDescription: msTAPI-RtPerson
objectClassCategory: 1
lDAPDisplayName: msTAPI-RtPerson
name: ms-TAPI-Rt-Person
objectGUID:: npiJsIPbuk+wKREYjrUejA==
schemaIDGUID:: tRzqUwS3+U2Bj1y07IbKwQ==
systemOnly: FALSE
systemPossSuperiors: organization
systemPossSuperiors: organizationalUnit
systemMayContain: msTAPI-uid
systemMayContain: msTAPI-IpAddress
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-TAPI-Rt-Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-IntRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-IntRangeParam
distinguishedName: 
 CN=ms-WMI-IntRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5016
subClassOf: msWMI-RangeParam
governsID: 1.2.840.113556.1.5.205
rDNAttID: cn
uSNChanged: 5016
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-IntRangeParam
adminDescription: ms-WMI-IntRangeParam
objectClassCategory: 1
lDAPDisplayName: msWMI-IntRangeParam
name: ms-WMI-IntRangeParam
objectGUID:: lZ9KJm6ZS0Okhpj0LVSORA==
schemaIDGUID:: fV3KUItc806531tm1JHlJg==
systemOnly: FALSE
systemPossSuperiors: msWMI-MergeablePolicyTemplate
systemMayContain: msWMI-IntMax
systemMayContain: msWMI-IntMin
systemMustContain: msWMI-IntDefault
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-IntRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-IntSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-IntSetParam
distinguishedName: 
 CN=ms-WMI-IntSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5018
subClassOf: msWMI-RangeParam
governsID: 1.2.840.113556.1.5.206
rDNAttID: cn
uSNChanged: 5018
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-IntSetParam
adminDescription: ms-WMI-IntSetParam
objectClassCategory: 1
lDAPDisplayName: msWMI-IntSetParam
name: ms-WMI-IntSetParam
objectGUID:: ACLeQkbe9EKSMAbDSPbFMg==
schemaIDGUID:: mg0vKXbPsEKEH7ZQ8zHfYg==
systemOnly: FALSE
systemPossSuperiors: msWMI-MergeablePolicyTemplate
systemMayContain: msWMI-IntValidValues
systemMustContain: msWMI-IntDefault
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPCCDCLCLODTRC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-IntSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-MergeablePolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-MergeablePolicyTemplate
distinguishedName: 
 CN=ms-WMI-MergeablePolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,
 DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5020
subClassOf: msWMI-PolicyTemplate
governsID: 1.2.840.113556.1.5.202
rDNAttID: cn
uSNChanged: 5020
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-MergeablePolicyTemplate
adminDescription: ms-WMI-MergeablePolicyTemplate
objectClassCategory: 1
lDAPDisplayName: msWMI-MergeablePolicyTemplate
name: ms-WMI-MergeablePolicyTemplate
objectGUID:: q7SCdICiE02vM5fQGk0HzQ==
schemaIDGUID:: FCRQB8r9UUiwShNkWxHSJg==
systemOnly: FALSE
systemPossSuperiors: container
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPCCDCLCLODTRC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-MergeablePolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,
 DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-ObjectEncoding,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-ObjectEncoding
distinguishedName: 
 CN=ms-WMI-ObjectEncoding,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5022
subClassOf: top
governsID: 1.2.840.113556.1.5.217
rDNAttID: cn
uSNChanged: 5022
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-ObjectEncoding
adminDescription: ms-WMI-ObjectEncoding
objectClassCategory: 1
lDAPDisplayName: msWMI-ObjectEncoding
name: ms-WMI-ObjectEncoding
objectGUID:: i1wbcroGMU2zbkfnttEfqg==
schemaIDGUID:: yYHdVRLD+UGoTcatvfHo4Q==
systemOnly: FALSE
systemPossSuperiors: container
systemMustContain: msWMI-Class
systemMustContain: msWMI-ScopeGuid
systemMustContain: msWMI-Parm1
systemMustContain: msWMI-Parm2
systemMustContain: msWMI-Parm3
systemMustContain: msWMI-Parm4
systemMustContain: msWMI-Genus
systemMustContain: msWMI-intFlags1
systemMustContain: msWMI-intFlags2
systemMustContain: msWMI-intFlags3
systemMustContain: msWMI-intFlags4
systemMustContain: msWMI-ID
systemMustContain: msWMI-TargetObject
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-ObjectEncoding,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-PolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-PolicyTemplate
distinguishedName: 
 CN=ms-WMI-PolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5024
subClassOf: top
governsID: 1.2.840.113556.1.5.200
rDNAttID: cn
uSNChanged: 5024
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-PolicyTemplate
adminDescription: ms-WMI-PolicyTemplate
objectClassCategory: 1
lDAPDisplayName: msWMI-PolicyTemplate
name: ms-WMI-PolicyTemplate
objectGUID:: jaaNVKnxr0Wwt/KO62Vk0w==
schemaIDGUID:: 8YC84kokWU2sxspcT4Lm4Q==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: msWMI-TargetType
systemMayContain: msWMI-SourceOrganization
systemMayContain: msWMI-Parm4
systemMayContain: msWMI-Parm3
systemMayContain: msWMI-Parm2
systemMayContain: msWMI-Parm1
systemMayContain: msWMI-intFlags4
systemMayContain: msWMI-intFlags3
systemMayContain: msWMI-intFlags2
systemMayContain: msWMI-intFlags1
systemMayContain: msWMI-CreationDate
systemMayContain: msWMI-ChangeDate
systemMayContain: msWMI-Author
systemMustContain: msWMI-NormalizedClass
systemMustContain: msWMI-TargetPath
systemMustContain: msWMI-TargetClass
systemMustContain: msWMI-TargetNameSpace
systemMustContain: msWMI-Name
systemMustContain: msWMI-ID
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSW;;;DA)(A;;CC;;;PA)(A;;RPWPCRLCLO
 CCDCRCWDWOSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-PolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-PolicyType,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-PolicyType
distinguishedName: 
 CN=ms-WMI-PolicyType,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5026
subClassOf: top
governsID: 1.2.840.113556.1.5.211
rDNAttID: cn
uSNChanged: 5026
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-PolicyType
adminDescription: ms-WMI-PolicyType
objectClassCategory: 1
lDAPDisplayName: msWMI-PolicyType
name: ms-WMI-PolicyType
objectGUID:: mRCYx8cK0UmEq/M0rAg8HQ==
schemaIDGUID:: EyZbWQlBd06QE6O7TvJ3xw==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: msWMI-SourceOrganization
systemMayContain: msWMI-Parm4
systemMayContain: msWMI-Parm3
systemMayContain: msWMI-Parm2
systemMayContain: msWMI-Parm1
systemMayContain: msWMI-intFlags4
systemMayContain: msWMI-intFlags3
systemMayContain: msWMI-intFlags2
systemMayContain: msWMI-intFlags1
systemMayContain: msWMI-CreationDate
systemMayContain: msWMI-ChangeDate
systemMayContain: msWMI-Author
systemMustContain: msWMI-TargetObject
systemMustContain: msWMI-ID
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSW;;;DA)(A;;CC;;;PA)(A;;RPWPCRLCLO
 CCDCRCWDWOSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-PolicyType,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-RangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-RangeParam
distinguishedName: 
 CN=ms-WMI-RangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5028
subClassOf: top
governsID: 1.2.840.113556.1.5.203
rDNAttID: cn
uSNChanged: 5028
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-RangeParam
adminDescription: ms-WMI-RangeParam
objectClassCategory: 1
lDAPDisplayName: msWMI-RangeParam
name: ms-WMI-RangeParam
objectGUID:: R8orT55N8EG/FbPE1Cxyzw==
schemaIDGUID:: V1r7RRhQD02QVpl8jJEi2Q==
systemOnly: FALSE
systemPossSuperiors: msWMI-MergeablePolicyTemplate
systemMustContain: msWMI-TargetType
systemMustContain: msWMI-TargetClass
systemMustContain: msWMI-PropertyName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPCCDCLCLODTRC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-RangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-RealRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-RealRangeParam
distinguishedName: 
 CN=ms-WMI-RealRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5030
subClassOf: msWMI-RangeParam
governsID: 1.2.840.113556.1.5.209
rDNAttID: cn
uSNChanged: 5030
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-RealRangeParam
adminDescription: ms-WMI-RealRangeParam
objectClassCategory: 1
lDAPDisplayName: msWMI-RealRangeParam
name: ms-WMI-RealRangeParam
objectGUID:: NnLCch7iYEyrG6y2RYY7RA==
schemaIDGUID:: 4o/+arxwzkyxZqlvc1nFFA==
systemOnly: FALSE
systemPossSuperiors: msWMI-MergeablePolicyTemplate
systemMayContain: msWMI-Int8Max
systemMayContain: msWMI-Int8Min
systemMustContain: msWMI-Int8Default
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-RealRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-Rule,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-Rule
distinguishedName: 
 CN=ms-WMI-Rule,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5032
subClassOf: top
governsID: 1.2.840.113556.1.5.214
rDNAttID: cn
uSNChanged: 5032
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-Rule
adminDescription: ms-WMI-Rule
objectClassCategory: 1
lDAPDisplayName: msWMI-Rule
name: ms-WMI-Rule
objectGUID:: VhqddkoxZkahVsnXkH6Mjw==
schemaIDGUID:: g29+PA7dG0igwnTNlu8qZg==
systemOnly: FALSE
systemPossSuperiors: msWMI-Som
systemPossSuperiors: container
systemMustContain: msWMI-QueryLanguage
systemMustContain: msWMI-TargetNameSpace
systemMustContain: msWMI-Query
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-Rule,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-ShadowObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-ShadowObject
distinguishedName: 
 CN=ms-WMI-ShadowObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5034
subClassOf: top
governsID: 1.2.840.113556.1.5.212
rDNAttID: cn
uSNChanged: 5034
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-ShadowObject
adminDescription: ms-WMI-ShadowObject
objectClassCategory: 1
lDAPDisplayName: msWMI-ShadowObject
name: ms-WMI-ShadowObject
objectGUID:: WFUgn1nu6UiB9yteYWQj/A==
schemaIDGUID:: 30vk8dONNUKchvkfMfW1aQ==
systemOnly: FALSE
systemPossSuperiors: msWMI-PolicyType
systemMustContain: msWMI-TargetObject
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-ShadowObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-SimplePolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-SimplePolicyTemplate
distinguishedName: 
 CN=ms-WMI-SimplePolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=
 be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5036
subClassOf: msWMI-PolicyTemplate
governsID: 1.2.840.113556.1.5.201
rDNAttID: cn
uSNChanged: 5036
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-SimplePolicyTemplate
adminDescription: ms-WMI-SimplePolicyTemplate
objectClassCategory: 1
lDAPDisplayName: msWMI-SimplePolicyTemplate
name: ms-WMI-SimplePolicyTemplate
objectGUID:: NjMszsgHKUWddqhX9c7S7g==
schemaIDGUID:: tbLIbN8S9kSDB+dPXN7jaQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMustContain: msWMI-TargetObject
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPCCDCLCLODTRC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-SimplePolicyTemplate,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=
 be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-Som,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-Som
distinguishedName: 
 CN=ms-WMI-Som,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5038
subClassOf: top
governsID: 1.2.840.113556.1.5.213
rDNAttID: cn
uSNChanged: 5038
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-Som
adminDescription: ms-WMI-Som
objectClassCategory: 1
lDAPDisplayName: msWMI-Som
name: ms-WMI-Som
objectGUID:: 9LdVlbrBrUyM4ykcfXYYuA==
schemaIDGUID:: eHCFq0IBBkSUWzTJtrEzcg==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: msWMI-SourceOrganization
systemMayContain: msWMI-Parm4
systemMayContain: msWMI-Parm3
systemMayContain: msWMI-Parm2
systemMayContain: msWMI-Parm1
systemMayContain: msWMI-intFlags4
systemMayContain: msWMI-intFlags3
systemMayContain: msWMI-intFlags2
systemMayContain: msWMI-intFlags1
systemMayContain: msWMI-CreationDate
systemMayContain: msWMI-ChangeDate
systemMayContain: msWMI-Author
systemMustContain: msWMI-Name
systemMustContain: msWMI-ID
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSW;;;DA)(A;;CC;;;PA)(A;;RPWPCRLCLO
 CCDCRCWDWOSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-Som,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-StringSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-StringSetParam
distinguishedName: 
 CN=ms-WMI-StringSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5040
subClassOf: msWMI-RangeParam
governsID: 1.2.840.113556.1.5.210
rDNAttID: cn
uSNChanged: 5040
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-StringSetParam
adminDescription: ms-WMI-StringSetParam
objectClassCategory: 1
lDAPDisplayName: msWMI-StringSetParam
name: ms-WMI-StringSetParam
objectGUID:: 8rIZizHd+0+Gnny6oZ0LYA==
schemaIDGUID:: onnFC6cd6ky2mYB/O51jpA==
systemOnly: FALSE
systemPossSuperiors: msWMI-MergeablePolicyTemplate
systemMayContain: msWMI-StringValidValues
systemMustContain: msWMI-StringDefault
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPCCDCLCLODTRC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-StringSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-UintRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-UintRangeParam
distinguishedName: 
 CN=ms-WMI-UintRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5042
subClassOf: msWMI-RangeParam
governsID: 1.2.840.113556.1.5.207
rDNAttID: cn
uSNChanged: 5042
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-UintRangeParam
adminDescription: ms-WMI-UintRangeParam
objectClassCategory: 1
lDAPDisplayName: msWMI-UintRangeParam
name: ms-WMI-UintRangeParam
objectGUID:: RLAF+l17f0yVa6b4Swvgsw==
schemaIDGUID:: spmn2fPOs0i1rfuF+N0yFA==
systemOnly: FALSE
systemPossSuperiors: msWMI-MergeablePolicyTemplate
systemMayContain: msWMI-IntMax
systemMayContain: msWMI-IntMin
systemMustContain: msWMI-IntDefault
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-UintRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-UintSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-UintSetParam
distinguishedName: 
 CN=ms-WMI-UintSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5044
subClassOf: msWMI-RangeParam
governsID: 1.2.840.113556.1.5.208
rDNAttID: cn
uSNChanged: 5044
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-UintSetParam
adminDescription: ms-WMI-UintSetParam
objectClassCategory: 1
lDAPDisplayName: msWMI-UintSetParam
name: ms-WMI-UintSetParam
objectGUID:: 5zKJ2wdAQkWGXefllripeg==
schemaIDGUID:: MetLjxlO9UaTLl+gPDObHQ==
systemOnly: FALSE
systemPossSuperiors: msWMI-MergeablePolicyTemplate
systemMayContain: msWMI-IntValidValues
systemMustContain: msWMI-IntDefault
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPCCDCLCLODTRC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-UintSetParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-UnknownRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-UnknownRangeParam
distinguishedName: 
 CN=ms-WMI-UnknownRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093702.0Z
uSNCreated: 5046
subClassOf: msWMI-RangeParam
governsID: 1.2.840.113556.1.5.204
rDNAttID: cn
uSNChanged: 5046
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-UnknownRangeParam
adminDescription: ms-WMI-UnknownRangeParam
objectClassCategory: 1
lDAPDisplayName: msWMI-UnknownRangeParam
name: ms-WMI-UnknownRangeParam
objectGUID:: bVTNPkf2C0eA1v9wlQibEw==
schemaIDGUID:: a8IquNvGmECSxknBijM24Q==
systemOnly: FALSE
systemPossSuperiors: msWMI-MergeablePolicyTemplate
systemMustContain: msWMI-TargetObject
systemMustContain: msWMI-NormalizedClass
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-UnknownRangeParam,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-WMI-WMIGPO,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-WMI-WMIGPO
distinguishedName: 
 CN=ms-WMI-WMIGPO,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5048
subClassOf: top
governsID: 1.2.840.113556.1.5.215
rDNAttID: cn
uSNChanged: 5048
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-WMI-WMIGPO
adminDescription: ms-WMI-WMIGPO
objectClassCategory: 1
lDAPDisplayName: msWMI-WMIGPO
name: ms-WMI-WMIGPO
objectGUID:: tEraWLmDsUCRph9PPFgLDw==
schemaIDGUID:: AABjBSc53k6/J8qR8nXCbw==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: msWMI-Parm4
systemMayContain: msWMI-Parm3
systemMayContain: msWMI-Parm2
systemMayContain: msWMI-Parm1
systemMayContain: msWMI-intFlags4
systemMayContain: msWMI-intFlags3
systemMayContain: msWMI-intFlags2
systemMayContain: msWMI-intFlags1
systemMustContain: msWMI-TargetClass
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSW;;;DA)(A;;CC;;;PA)(A;;RPWPCRLCLO
 CCDCRCWDWOSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-WMI-WMIGPO,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MSMQ-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MSMQ-Configuration
distinguishedName: 
 CN=MSMQ-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5050
subClassOf: top
governsID: 1.2.840.113556.1.5.162
rDNAttID: cn
uSNChanged: 5050
showInAdvancedViewOnly: TRUE
adminDisplayName: MSMQ-Configuration
adminDescription: MSMQ-Configuration
objectClassCategory: 1
lDAPDisplayName: mSMQConfiguration
name: MSMQ-Configuration
objectGUID:: th+Cv/L6d0mPTG9C3lM7sw==
schemaIDGUID:: RMMNmgDB0RG7xQCAx2ZwwA==
systemOnly: FALSE
systemPossSuperiors: computer
systemMayContain: mSMQSites
systemMayContain: mSMQSignKey
systemMayContain: mSMQServiceType
systemMayContain: mSMQRoutingServices
systemMayContain: mSMQQuota
systemMayContain: mSMQOwnerID
systemMayContain: mSMQOutRoutingServers
systemMayContain: mSMQOSType
systemMayContain: mSMQJournalQuota
systemMayContain: mSMQInRoutingServers
systemMayContain: mSMQForeign
systemMayContain: mSMQEncryptKey
systemMayContain: mSMQDsServices
systemMayContain: mSMQDependentClientServices
systemMayContain: mSMQComputerTypeEx
systemMayContain: mSMQComputerType
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MSMQ-Configuration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MSMQ-Custom-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MSMQ-Custom-Recipient
distinguishedName: 
 CN=MSMQ-Custom-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5052
subClassOf: top
governsID: 1.2.840.113556.1.5.218
rDNAttID: cn
uSNChanged: 5052
showInAdvancedViewOnly: TRUE
adminDisplayName: MSMQ-Custom-Recipient
adminDescription: MSMQ-Custom-Recipient
objectClassCategory: 1
lDAPDisplayName: msMQ-Custom-Recipient
name: MSMQ-Custom-Recipient
objectGUID:: 8+S+VmvN4EKv2h5NgVansA==
schemaIDGUID:: F2hth8w1bEOs6l73F03Zvg==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemPossSuperiors: container
systemMayContain: msMQ-Recipient-FormatName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MSMQ-Custom-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MSMQ-Enterprise-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MSMQ-Enterprise-Settings
distinguishedName: 
 CN=MSMQ-Enterprise-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5054
subClassOf: top
governsID: 1.2.840.113556.1.5.163
rDNAttID: cn
uSNChanged: 5054
showInAdvancedViewOnly: TRUE
adminDisplayName: MSMQ-Enterprise-Settings
adminDescription: MSMQ-Enterprise-Settings
objectClassCategory: 1
lDAPDisplayName: mSMQEnterpriseSettings
name: MSMQ-Enterprise-Settings
objectGUID:: pB6yvCOQkEuLIusE1lJX8w==
schemaIDGUID:: RcMNmgDB0RG7xQCAx2ZwwA==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: mSMQVersion
systemMayContain: mSMQNameStyle
systemMayContain: mSMQLongLived
systemMayContain: mSMQInterval2
systemMayContain: mSMQInterval1
systemMayContain: mSMQCSPName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MSMQ-Enterprise-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MSMQ-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MSMQ-Group
distinguishedName: 
 CN=MSMQ-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5056
subClassOf: top
governsID: 1.2.840.113556.1.5.219
rDNAttID: cn
uSNChanged: 5056
showInAdvancedViewOnly: TRUE
adminDisplayName: MSMQ-Group
adminDescription: MSMQ-Group
objectClassCategory: 1
lDAPDisplayName: msMQ-Group
name: MSMQ-Group
objectGUID:: F/h+AY8gs02r2GspbGKieA==
schemaIDGUID:: rHqyRvqq+0+3c+W/Yh7oew==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemMustContain: member
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MSMQ-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MSMQ-Migrated-User,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MSMQ-Migrated-User
distinguishedName: 
 CN=MSMQ-Migrated-User,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5058
subClassOf: top
governsID: 1.2.840.113556.1.5.179
rDNAttID: cn
uSNChanged: 5058
showInAdvancedViewOnly: TRUE
adminDisplayName: MSMQ-Migrated-User
adminDescription: MSMQ-Migrated-User
objectClassCategory: 1
lDAPDisplayName: mSMQMigratedUser
name: MSMQ-Migrated-User
objectGUID:: 5xVqeUaYrkKYkpaMrom6KA==
schemaIDGUID:: l2l3UD080hGQzADAT9kasQ==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemPossSuperiors: builtinDomain
systemMayContain: mSMQUserSid
systemMayContain: mSMQSignCertificatesMig
systemMayContain: mSMQSignCertificates
systemMayContain: mSMQDigestsMig
systemMayContain: mSMQDigests
systemMayContain: objectSid
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MSMQ-Migrated-User,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MSMQ-Queue,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MSMQ-Queue
distinguishedName: 
 CN=MSMQ-Queue,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5060
subClassOf: top
governsID: 1.2.840.113556.1.5.161
rDNAttID: cn
uSNChanged: 5060
showInAdvancedViewOnly: TRUE
adminDisplayName: MSMQ-Queue
adminDescription: MSMQ-Queue
objectClassCategory: 1
lDAPDisplayName: mSMQQueue
name: MSMQ-Queue
objectGUID:: uM3JH1Mvp0GdH7th6SS1FA==
schemaIDGUID:: Q8MNmgDB0RG7xQCAx2ZwwA==
systemOnly: FALSE
systemPossSuperiors: mSMQConfiguration
systemMayContain: mSMQTransactional
systemMayContain: MSMQ-SecuredSource
systemMayContain: mSMQQueueType
systemMayContain: mSMQQueueQuota
systemMayContain: mSMQQueueNameExt
systemMayContain: mSMQQueueJournalQuota
systemMayContain: mSMQPrivacyLevel
systemMayContain: mSMQOwnerID
systemMayContain: MSMQ-MulticastAddress
systemMayContain: mSMQLabelEx
systemMayContain: mSMQLabel
systemMayContain: mSMQJournal
systemMayContain: mSMQBasePriority
systemMayContain: mSMQAuthenticate
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MSMQ-Queue,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MSMQ-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MSMQ-Settings
distinguishedName: 
 CN=MSMQ-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5062
subClassOf: top
governsID: 1.2.840.113556.1.5.165
rDNAttID: cn
uSNChanged: 5062
showInAdvancedViewOnly: TRUE
adminDisplayName: MSMQ-Settings
adminDescription: MSMQ-Settings
objectClassCategory: 1
lDAPDisplayName: mSMQSettings
name: MSMQ-Settings
objectGUID:: AEPifvCl2kGqyPPB3Ua4gg==
schemaIDGUID:: R8MNmgDB0RG7xQCAx2ZwwA==
systemOnly: FALSE
systemPossSuperiors: server
systemMayContain: mSMQSiteNameEx
systemMayContain: mSMQSiteName
systemMayContain: mSMQServices
systemMayContain: mSMQRoutingService
systemMayContain: mSMQQMID
systemMayContain: mSMQOwnerID
systemMayContain: mSMQNt4Flags
systemMayContain: mSMQMigrated
systemMayContain: mSMQDsService
systemMayContain: mSMQDependentClientService
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MSMQ-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=MSMQ-Site-Link,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: MSMQ-Site-Link
distinguishedName: 
 CN=MSMQ-Site-Link,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5064
subClassOf: top
governsID: 1.2.840.113556.1.5.164
rDNAttID: cn
uSNChanged: 5064
showInAdvancedViewOnly: TRUE
adminDisplayName: MSMQ-Site-Link
adminDescription: MSMQ-Site-Link
objectClassCategory: 1
lDAPDisplayName: mSMQSiteLink
name: MSMQ-Site-Link
objectGUID:: pd8g4LnkvUWoYNyIxHX/Aw==
schemaIDGUID:: RsMNmgDB0RG7xQCAx2ZwwA==
systemOnly: FALSE
systemPossSuperiors: mSMQEnterpriseSettings
systemMayContain: mSMQSiteGatesMig
systemMayContain: mSMQSiteGates
systemMustContain: mSMQSite2
systemMustContain: mSMQSite1
systemMustContain: mSMQCost
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=MSMQ-Site-Link,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTDS-Connection,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTDS-Connection
distinguishedName: 
 CN=NTDS-Connection,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5066
subClassOf: leaf
governsID: 1.2.840.113556.1.5.71
rDNAttID: cn
uSNChanged: 5066
showInAdvancedViewOnly: TRUE
adminDisplayName: NTDS-Connection
adminDescription: NTDS-Connection
objectClassCategory: 1
lDAPDisplayName: nTDSConnection
name: NTDS-Connection
objectGUID:: Fl1CUTopgk2jG0YMNdgT/g==
schemaIDGUID:: YFoZGaBt0BGv0wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: nTFRSMember
systemPossSuperiors: nTFRSReplicaSet
systemPossSuperiors: nTDSDSA
systemMayContain: transportType
systemMayContain: schedule
systemMayContain: mS-DS-ReplicatesNCReason
systemMayContain: generatedConnection
systemMustContain: options
systemMustContain: fromServer
systemMustContain: enabledConnection
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTDS-Connection,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTDS-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTDS-Service
distinguishedName: 
 CN=NTDS-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5068
subClassOf: top
governsID: 1.2.840.113556.1.5.72
rDNAttID: cn
uSNChanged: 5068
showInAdvancedViewOnly: TRUE
adminDisplayName: NTDS-Service
adminDescription: NTDS-Service
objectClassCategory: 1
lDAPDisplayName: nTDSService
name: NTDS-Service
objectGUID:: DjyU1Gn64Eu/YsNrmGZbDA==
schemaIDGUID:: X1oZGaBt0BGv0wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: tombstoneLifetime
systemMayContain: sPNMappings
systemMayContain: replTopologyStayOfExecution
systemMayContain: msDS-Other-Settings
systemMayContain: garbageCollPeriod
systemMayContain: dSHeuristics
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTDS-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTDS-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTDS-Site-Settings
distinguishedName: 
 CN=NTDS-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5070
subClassOf: applicationSiteSettings
governsID: 1.2.840.113556.1.5.69
rDNAttID: cn
uSNChanged: 5070
showInAdvancedViewOnly: TRUE
adminDisplayName: NTDS-Site-Settings
adminDescription: NTDS-Site-Settings
objectClassCategory: 1
lDAPDisplayName: nTDSSiteSettings
name: NTDS-Site-Settings
objectGUID:: aFlmbpvsuUylImwssG13Jg==
schemaIDGUID:: XVoZGaBt0BGv0wDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: site
systemMayContain: schedule
systemMayContain: queryPolicyObject
systemMayContain: options
systemMayContain: msDS-Preferred-GC-Site
systemMayContain: managedBy
systemMayContain: interSiteTopologyRenew
systemMayContain: interSiteTopologyGenerator
systemMayContain: interSiteTopologyFailover
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTDS-Site-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTFRS-Member,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTFRS-Member
distinguishedName: 
 CN=NTFRS-Member,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5072
subClassOf: top
governsID: 1.2.840.113556.1.5.153
rDNAttID: cn
uSNChanged: 5072
showInAdvancedViewOnly: TRUE
adminDisplayName: NTFRS-Member
adminDescription: NTFRS-Member
objectClassCategory: 1
lDAPDisplayName: nTFRSMember
name: NTFRS-Member
objectGUID:: 48ZHp9TSdkaQ2NllCb0+cQ==
schemaIDGUID:: hiUTKnOT0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: nTFRSReplicaSet
systemMayContain: serverReference
systemMayContain: fRSUpdateTimeout
systemMayContain: fRSServiceCommand
systemMayContain: fRSRootSecurity
systemMayContain: fRSPartnerAuthLevel
systemMayContain: fRSFlags
systemMayContain: fRSExtensions
systemMayContain: fRSControlOutboundBacklog
systemMayContain: fRSControlInboundBacklog
systemMayContain: fRSControlDataCreation
systemMayContain: frsComputerReference
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTFRS-Member,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTFRS-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTFRS-Settings
distinguishedName: 
 CN=NTFRS-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5074
subClassOf: applicationSettings
governsID: 1.2.840.113556.1.5.89
rDNAttID: cn
uSNChanged: 5074
showInAdvancedViewOnly: TRUE
adminDisplayName: NTFRS-Settings
adminDescription: NTFRS-Settings
objectClassCategory: 1
lDAPDisplayName: nTFRSSettings
name: NTFRS-Settings
objectGUID:: 0WUreUdyxU25QiMWiy9EcA==
schemaIDGUID:: wqyA9/BW0RGpxgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: nTFRSSettings
systemPossSuperiors: container
systemPossSuperiors: organizationalUnit
systemPossSuperiors: organization
systemMayContain: managedBy
systemMayContain: fRSExtensions
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTFRS-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTFRS-Subscriber,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTFRS-Subscriber
distinguishedName: 
 CN=NTFRS-Subscriber,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5076
subClassOf: top
governsID: 1.2.840.113556.1.5.155
rDNAttID: cn
uSNChanged: 5076
showInAdvancedViewOnly: TRUE
adminDisplayName: NTFRS-Subscriber
adminDescription: NTFRS-Subscriber
objectClassCategory: 1
lDAPDisplayName: nTFRSSubscriber
name: NTFRS-Subscriber
objectGUID:: hxo23bOCVU+5G00t3P//oQ==
schemaIDGUID:: iCUTKnOT0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: nTFRSSubscriptions
systemMayContain: schedule
systemMayContain: fRSUpdateTimeout
systemMayContain: fRSTimeLastConfigChange
systemMayContain: fRSTimeLastCommand
systemMayContain: fRSServiceCommandStatus
systemMayContain: fRSServiceCommand
systemMayContain: fRSMemberReference
systemMayContain: fRSFlags
systemMayContain: fRSFaultCondition
systemMayContain: fRSExtensions
systemMustContain: fRSStagingPath
systemMustContain: fRSRootPath
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWO
 WDSDDTSW;;;SY)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTFRS-Subscriber,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTFRS-Subscriptions,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTFRS-Subscriptions
distinguishedName: 
 CN=NTFRS-Subscriptions,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5078
subClassOf: top
governsID: 1.2.840.113556.1.5.154
rDNAttID: cn
uSNChanged: 5078
showInAdvancedViewOnly: TRUE
adminDisplayName: NTFRS-Subscriptions
adminDescription: NTFRS-Subscriptions
objectClassCategory: 1
lDAPDisplayName: nTFRSSubscriptions
name: NTFRS-Subscriptions
objectGUID:: 1eKy2TZ5vECaVGxUaJmtDA==
schemaIDGUID:: hyUTKnOT0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: user
systemPossSuperiors: computer
systemPossSuperiors: nTFRSSubscriptions
systemMayContain: fRSWorkingPath
systemMayContain: fRSVersion
systemMayContain: fRSExtensions
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWO
 WDSDDTSW;;;SY)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTFRS-Subscriptions,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Organization,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Organization
distinguishedName: 
 CN=Organization,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5080
subClassOf: top
governsID: 2.5.6.4
rDNAttID: o
uSNChanged: 5080
showInAdvancedViewOnly: TRUE
adminDisplayName: Organization
adminDescription: Organization
objectClassCategory: 1
lDAPDisplayName: organization
name: Organization
objectGUID:: Rl2kcsmBxkuuRZfy0C9UHw==
schemaIDGUID:: o3qWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: locality
systemPossSuperiors: country
systemPossSuperiors: domainDNS
systemMayContain: x121Address
systemMayContain: userPassword
systemMayContain: telexNumber
systemMayContain: teletexTerminalIdentifier
systemMayContain: telephoneNumber
systemMayContain: street
systemMayContain: st
systemMayContain: seeAlso
systemMayContain: searchGuide
systemMayContain: registeredAddress
systemMayContain: preferredDeliveryMethod
systemMayContain: postalCode
systemMayContain: postalAddress
systemMayContain: postOfficeBox
systemMayContain: physicalDeliveryOfficeName
systemMayContain: l
systemMayContain: internationalISDNNumber
systemMayContain: facsimileTelephoneNumber
systemMayContain: destinationIndicator
systemMayContain: businessCategory
systemMustContain: o
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Organization,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Organizational-Role,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Organizational-Role
distinguishedName: 
 CN=Organizational-Role,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5082
subClassOf: top
governsID: 2.5.6.8
rDNAttID: cn
uSNChanged: 5082
showInAdvancedViewOnly: TRUE
adminDisplayName: Organizational-Role
adminDescription: Organizational-Role
objectClassCategory: 1
lDAPDisplayName: organizationalRole
name: Organizational-Role
objectGUID:: rjWSpqVrJkKmWh+CvzYkag==
schemaIDGUID:: v3TfqOrF0RG7ywCAx2ZwwA==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: organization
systemPossSuperiors: container
systemMayContain: x121Address
systemMayContain: telexNumber
systemMayContain: teletexTerminalIdentifier
systemMayContain: telephoneNumber
systemMayContain: street
systemMayContain: st
systemMayContain: seeAlso
systemMayContain: roleOccupant
systemMayContain: registeredAddress
systemMayContain: preferredDeliveryMethod
systemMayContain: postalCode
systemMayContain: postalAddress
systemMayContain: postOfficeBox
systemMayContain: physicalDeliveryOfficeName
systemMayContain: ou
systemMayContain: l
systemMayContain: internationalISDNNumber
systemMayContain: facsimileTelephoneNumber
systemMayContain: destinationIndicator
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Organizational-Role,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Organizational-Unit
distinguishedName: 
 CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5084
subClassOf: top
governsID: 2.5.6.5
rDNAttID: ou
uSNChanged: 5084
showInAdvancedViewOnly: TRUE
adminDisplayName: Organizational-Unit
adminDescription: Organizational-Unit
objectClassCategory: 1
lDAPDisplayName: organizationalUnit
name: Organizational-Unit
objectGUID:: ckrZPXMddECFojf9ucUAOg==
schemaIDGUID:: pXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: country
systemPossSuperiors: organization
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemMayContain: x121Address
systemMayContain: userPassword
systemMayContain: uPNSuffixes
systemMayContain: co
systemMayContain: telexNumber
systemMayContain: teletexTerminalIdentifier
systemMayContain: telephoneNumber
systemMayContain: street
systemMayContain: st
systemMayContain: seeAlso
systemMayContain: searchGuide
systemMayContain: registeredAddress
systemMayContain: preferredDeliveryMethod
systemMayContain: postalCode
systemMayContain: postalAddress
systemMayContain: postOfficeBox
systemMayContain: physicalDeliveryOfficeName
systemMayContain: msCOM-UserPartitionSetLink
systemMayContain: managedBy
systemMayContain: thumbnailLogo
systemMayContain: l
systemMayContain: internationalISDNNumber
systemMayContain: gPOptions
systemMayContain: gPLink
systemMayContain: facsimileTelephoneNumber
systemMayContain: destinationIndicator
systemMayContain: desktopProfile
systemMayContain: defaultGroup
systemMayContain: countryCode
systemMayContain: c
systemMayContain: businessCategory
systemMustContain: ou
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(OA;
 ;CCDC;bf967a86-0de6-11d0-a285-00aa003049e2;;AO)(OA;;CCDC;bf967aba-0de6-11d0-a2
 85-00aa003049e2;;AO)(OA;;CCDC;bf967a9c-0de6-11d0-a285-00aa003049e2;;AO)(OA;;CC
 DC;bf967aa8-0de6-11d0-a285-00aa003049e2;;PO)(A;;RPLCLORC;;;AU)(A;;LCRPLORC;;;E
 D)(OA;;CCDC;4828CC14-1437-45bc-9B07-AD6F015E5F28;;AO)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Organizational-Unit,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Package-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Package-Registration
distinguishedName: 
 CN=Package-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5086
subClassOf: top
governsID: 1.2.840.113556.1.5.49
rDNAttID: cn
uSNChanged: 5086
showInAdvancedViewOnly: TRUE
adminDisplayName: Package-Registration
adminDescription: Package-Registration
objectClassCategory: 1
lDAPDisplayName: packageRegistration
name: Package-Registration
objectGUID:: LpmbQlKcoUio4IDmGNbMFQ==
schemaIDGUID:: pnqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: classStore
systemMayContain: versionNumberLo
systemMayContain: versionNumberHi
systemMayContain: vendor
systemMayContain: upgradeProductCode
systemMayContain: setupCommand
systemMayContain: productCode
systemMayContain: packageType
systemMayContain: packageName
systemMayContain: packageFlags
systemMayContain: msiScriptSize
systemMayContain: msiScriptPath
systemMayContain: msiScriptName
systemMayContain: msiScript
systemMayContain: msiFileList
systemMayContain: managedBy
systemMayContain: machineArchitecture
systemMayContain: localeID
systemMayContain: lastUpdateSequence
systemMayContain: installUiLevel
systemMayContain: iconPath
systemMayContain: fileExtPriority
systemMayContain: cOMTypelibId
systemMayContain: cOMProgID
systemMayContain: cOMInterfaceID
systemMayContain: cOMClassID
systemMayContain: categories
systemMayContain: canUpgradeScript
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Package-Registration,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Person
distinguishedName: CN=Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5088
subClassOf: top
governsID: 2.5.6.6
mayContain: attributeCertificateAttribute
rDNAttID: cn
uSNChanged: 5088
showInAdvancedViewOnly: TRUE
adminDisplayName: Person
adminDescription: Person
objectClassCategory: 0
lDAPDisplayName: person
name: Person
objectGUID:: bMFEp4iSu0SSkb/tnIpiUw==
schemaIDGUID:: p3qWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
systemMayContain: userPassword
systemMayContain: telephoneNumber
systemMayContain: sn
systemMayContain: serialNumber
systemMayContain: seeAlso
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Physical-Location,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Physical-Location
distinguishedName: 
 CN=Physical-Location,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5090
subClassOf: locality
governsID: 1.2.840.113556.1.5.97
rDNAttID: cn
uSNChanged: 5090
showInAdvancedViewOnly: TRUE
adminDisplayName: Physical-Location
adminDescription: Physical-Location
objectClassCategory: 1
lDAPDisplayName: physicalLocation
name: Physical-Location
objectGUID:: jxoavxKXfEKSouEFVhc2xQ==
schemaIDGUID:: IjGxty640BGv7gAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: physicalLocation
systemPossSuperiors: configuration
systemMayContain: managedBy
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Physical-Location,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=PKI-Certificate-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: PKI-Certificate-Template
distinguishedName: 
 CN=PKI-Certificate-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5092
subClassOf: top
governsID: 1.2.840.113556.1.5.177
rDNAttID: cn
uSNChanged: 5092
showInAdvancedViewOnly: TRUE
adminDisplayName: PKI-Certificate-Template
adminDescription: PKI-Certificate-Template
objectClassCategory: 1
lDAPDisplayName: pKICertificateTemplate
name: PKI-Certificate-Template
objectGUID:: gwbZku6ZSkWAen5DRFdsNA==
schemaIDGUID:: opwg5bo70hGQzADAT9kasQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: pKIOverlapPeriod
systemMayContain: pKIMaxIssuingDepth
systemMayContain: pKIKeyUsage
systemMayContain: pKIExtendedKeyUsage
systemMayContain: pKIExpirationPeriod
systemMayContain: pKIEnrollmentAccess
systemMayContain: pKIDefaultCSPs
systemMayContain: pKIDefaultKeySpec
systemMayContain: pKICriticalExtensions
systemMayContain: msPKI-RA-Signature
systemMayContain: msPKI-RA-Policies
systemMayContain: msPKI-RA-Application-Policies
systemMayContain: msPKI-Template-Schema-Version
systemMayContain: msPKI-Template-Minor-Revision
systemMayContain: msPKI-Supersede-Templates
systemMayContain: msPKI-Private-Key-Flag
systemMayContain: msPKI-Minimal-Key-Size
systemMayContain: msPKI-Enrollment-Flag
systemMayContain: msPKI-Certificate-Policy
systemMayContain: msPKI-Certificate-Name-Flag
systemMayContain: msPKI-Certificate-Application-Policy
systemMayContain: msPKI-Cert-Template-OID
systemMayContain: flags
systemMayContain: displayName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=PKI-Certificate-Template,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=PKI-Enrollment-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: PKI-Enrollment-Service
distinguishedName: 
 CN=PKI-Enrollment-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5094
subClassOf: top
governsID: 1.2.840.113556.1.5.178
rDNAttID: cn
uSNChanged: 5094
showInAdvancedViewOnly: TRUE
adminDisplayName: PKI-Enrollment-Service
adminDescription: PKI-Enrollment-Service
objectClassCategory: 1
lDAPDisplayName: pKIEnrollmentService
name: PKI-Enrollment-Service
objectGUID:: BY3zQCvIH0i1V5bavyytRA==
schemaIDGUID:: kqZK7ro70hGQzADAT9kasQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: signatureAlgorithms
systemMayContain: enrollmentProviders
systemMayContain: dNSHostName
systemMayContain: certificateTemplates
systemMayContain: cACertificateDN
systemMayContain: cACertificate
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=PKI-Enrollment-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-PKI-Private-Key-Recovery-Agent,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-PKI-Private-Key-Recovery-Agent
distinguishedName: 
 CN=ms-PKI-Private-Key-Recovery-Agent,CN=Schema,CN=Configuration,DC=iii,DC=hoge
 nt,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5096
subClassOf: top
governsID: 1.2.840.113556.1.5.223
rDNAttID: cn
uSNChanged: 5096
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-PKI-Private-Key-Recovery-Agent
adminDescription: ms-PKI-Private-Key-Recovery-Agent
objectClassCategory: 1
lDAPDisplayName: msPKI-PrivateKeyRecoveryAgent
name: ms-PKI-Private-Key-Recovery-Agent
objectGUID:: 28X+/TiNnEKcFKkY3QSq/w==
schemaIDGUID:: MqZiFblEfkqi0+QmyWo6zA==
systemOnly: FALSE
systemPossSuperiors: container
systemMustContain: userCertificate
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-PKI-Private-Key-Recovery-Agent,CN=Schema,CN=Configuration,DC=iii,DC=hoge
 nt,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Print-Queue,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Print-Queue
distinguishedName: 
 CN=Print-Queue,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5098
subClassOf: connectionPoint
governsID: 1.2.840.113556.1.5.23
rDNAttID: cn
uSNChanged: 5098
showInAdvancedViewOnly: TRUE
adminDisplayName: Print-Queue
adminDescription: Print-Queue
objectClassCategory: 1
lDAPDisplayName: printQueue
name: Print-Queue
objectGUID:: m1DXdlqps0eJ60q5RRLcKA==
schemaIDGUID:: qHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemPossSuperiors: container
systemPossSuperiors: computer
systemMayContain: priority
systemMayContain: printStatus
systemMayContain: printStartTime
systemMayContain: printStaplingSupported
systemMayContain: printSpooling
systemMayContain: printShareName
systemMayContain: printSeparatorFile
systemMayContain: printRateUnit
systemMayContain: printRate
systemMayContain: printPagesPerMinute
systemMayContain: printOwner
systemMayContain: printOrientationsSupported
systemMayContain: printNumberUp
systemMayContain: printNotify
systemMayContain: printNetworkAddress
systemMayContain: printMinYExtent
systemMayContain: printMinXExtent
systemMayContain: printMemory
systemMayContain: printMediaSupported
systemMayContain: printMediaReady
systemMayContain: printMaxYExtent
systemMayContain: printMaxXExtent
systemMayContain: printMaxResolutionSupported
systemMayContain: printMaxCopies
systemMayContain: printMACAddress
systemMayContain: printLanguage
systemMayContain: printKeepPrintedJobs
systemMayContain: printFormName
systemMayContain: printEndTime
systemMayContain: printDuplexSupported
systemMayContain: printColor
systemMayContain: printCollate
systemMayContain: printBinNames
systemMayContain: printAttributes
systemMayContain: portName
systemMayContain: physicalLocationObject
systemMayContain: operatingSystemVersion
systemMayContain: operatingSystemServicePack
systemMayContain: operatingSystemHotfix
systemMayContain: operatingSystem
systemMayContain: location
systemMayContain: driverVersion
systemMayContain: driverName
systemMayContain: defaultPriority
systemMayContain: bytesPerMinute
systemMayContain: assetNumber
systemMustContain: versionNumber
systemMustContain: uNCName
systemMustContain: shortServerName
systemMustContain: serverName
systemMustContain: printerName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPWPCRCCDCLCLORCWOWDSDDTSW;;;PO)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)(A;;RPLCLO
 RC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Print-Queue,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Query-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Query-Policy
distinguishedName: 
 CN=Query-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5100
subClassOf: top
governsID: 1.2.840.113556.1.5.106
rDNAttID: cn
uSNChanged: 5100
showInAdvancedViewOnly: TRUE
adminDisplayName: Query-Policy
adminDescription: Query-Policy
objectClassCategory: 1
lDAPDisplayName: queryPolicy
name: Query-Policy
objectGUID:: EfwzB8NUmE6u8S/mq/Zj6w==
schemaIDGUID:: dXDMg6fM0BGv/wAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: lDAPIPDenyList
systemMayContain: lDAPAdminLimits
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Query-Policy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Remote-Mail-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Remote-Mail-Recipient
distinguishedName: 
 CN=Remote-Mail-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5102
subClassOf: top
governsID: 1.2.840.113556.1.5.24
rDNAttID: cn
uSNChanged: 5102
showInAdvancedViewOnly: TRUE
adminDisplayName: Remote-Mail-Recipient
adminDescription: Remote-Mail-Recipient
objectClassCategory: 1
lDAPDisplayName: remoteMailRecipient
name: Remote-Mail-Recipient
objectGUID:: vme9d9gC1EChZiWYvCT4bA==
schemaIDGUID:: qXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemMayContain: remoteSourceType
systemMayContain: remoteSource
systemMayContain: managedBy
systemAuxiliaryClass: mailRecipient
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(OA;;CR;ab721a55-1e2f-11d0-9819-00aa0040529b;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Remote-Mail-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Remote-Storage-Service-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Remote-Storage-Service-Point
distinguishedName: 
 CN=Remote-Storage-Service-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC
 =be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5104
subClassOf: serviceAdministrationPoint
governsID: 1.2.840.113556.1.5.146
rDNAttID: cn
uSNChanged: 5104
showInAdvancedViewOnly: TRUE
adminDisplayName: Remote-Storage-Service-Point
adminDescription: Remote-Storage-Service-Point
objectClassCategory: 1
lDAPDisplayName: remoteStorageServicePoint
name: Remote-Storage-Service-Point
objectGUID:: AKpTQRCvAUi+xGHKHESjIg==
schemaIDGUID:: vcU5KmCJ0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: computer
systemMayContain: remoteStorageGUID
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Remote-Storage-Service-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC
 =be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Residential-Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Residential-Person
distinguishedName: 
 CN=Residential-Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5106
subClassOf: person
governsID: 2.5.6.10
rDNAttID: cn
uSNChanged: 5106
showInAdvancedViewOnly: TRUE
adminDisplayName: Residential-Person
adminDescription: Residential-Person
objectClassCategory: 1
lDAPDisplayName: residentialPerson
name: Residential-Person
objectGUID:: eq//CGauGEiG87FMXt/A6g==
schemaIDGUID:: 1nTfqOrF0RG7ywCAx2ZwwA==
systemOnly: FALSE
systemPossSuperiors: locality
systemPossSuperiors: container
systemMayContain: x121Address
systemMayContain: title
systemMayContain: telexNumber
systemMayContain: teletexTerminalIdentifier
systemMayContain: street
systemMayContain: st
systemMayContain: registeredAddress
systemMayContain: preferredDeliveryMethod
systemMayContain: postalCode
systemMayContain: postalAddress
systemMayContain: postOfficeBox
systemMayContain: physicalDeliveryOfficeName
systemMayContain: ou
systemMayContain: l
systemMayContain: internationalISDNNumber
systemMayContain: facsimileTelephoneNumber
systemMayContain: destinationIndicator
systemMayContain: businessCategory
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Residential-Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=rFC822LocalPart,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: rFC822LocalPart
distinguishedName: 
 CN=rFC822LocalPart,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
possSuperiors: organizationalUnit
possSuperiors: container
uSNCreated: 5108
subClassOf: domain
governsID: 0.9.2342.19200300.100.4.14
mayContain: x121Address
mayContain: telexNumber
mayContain: teletexTerminalIdentifier
mayContain: telephoneNumber
mayContain: street
mayContain: sn
mayContain: seeAlso
mayContain: registeredAddress
mayContain: preferredDeliveryMethod
mayContain: postOfficeBox
mayContain: postalCode
mayContain: postalAddress
mayContain: physicalDeliveryOfficeName
mayContain: internationalISDNNumber
mayContain: facsimileTelephoneNumber
mayContain: destinationIndicator
mayContain: description
mayContain: cn
rDNAttID: cn
uSNChanged: 5108
showInAdvancedViewOnly: TRUE
adminDisplayName: rFC822LocalPart
adminDescription: 
 The rFC822LocalPart object class is used to define entries which represent the
  local part of mail addresses.
objectClassCategory: 1
lDAPDisplayName: rFC822LocalPart
name: rFC822LocalPart
objectGUID:: Z9D1vslbZEac9PlkmByDIg==
schemaIDGUID:: eDo+ua7LXkige170rlBWhg==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=rFC822LocalPart,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=RID-Set,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: RID-Set
distinguishedName: 
 CN=RID-Set,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5110
subClassOf: top
governsID: 1.2.840.113556.1.5.129
rDNAttID: cn
uSNChanged: 5110
showInAdvancedViewOnly: TRUE
adminDisplayName: RID-Set
adminDescription: RID-Set
objectClassCategory: 1
lDAPDisplayName: rIDSet
name: RID-Set
objectGUID:: igr9H3+u+kmQd75pM8h9bg==
schemaIDGUID:: icv9ewdI0RGpwwAA+ANnwQ==
systemOnly: TRUE
systemPossSuperiors: user
systemPossSuperiors: container
systemPossSuperiors: computer
systemMustContain: rIDUsedPool
systemMustContain: rIDPreviousAllocationPool
systemMustContain: rIDNextRID
systemMustContain: rIDAllocationPool
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=RID-Set,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=room,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: room
distinguishedName: CN=room,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093703.0Z
possSuperiors: organizationalUnit
possSuperiors: container
uSNCreated: 5112
subClassOf: top
governsID: 0.9.2342.19200300.100.4.7
mustContain: cn
mayContain: location
mayContain: telephoneNumber
mayContain: seeAlso
mayContain: description
mayContain: roomNumber
rDNAttID: cn
uSNChanged: 5112
showInAdvancedViewOnly: TRUE
adminDisplayName: room
adminDescription: 
 The room object class is used to define entries representing rooms.
objectClassCategory: 1
lDAPDisplayName: room
name: room
objectGUID:: 0dUvaMqWO0Cmrfq0MYo+BA==
schemaIDGUID:: 0uVgeLDIu0y9RdlFW+uSBg==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=room,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Rpc-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Rpc-Container
distinguishedName: 
 CN=Rpc-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5114
subClassOf: container
governsID: 1.2.840.113556.1.5.136
rDNAttID: cn
uSNChanged: 5114
showInAdvancedViewOnly: TRUE
adminDisplayName: Rpc-Container
adminDescription: Rpc-Container
objectClassCategory: 1
lDAPDisplayName: rpcContainer
name: Rpc-Container
objectGUID:: HZVci/ScbUiLP1i2LEsW8w==
schemaIDGUID:: QighgNxL0RGpxAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: nameServiceFlags
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Rpc-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=rpc-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: rpc-Entry
distinguishedName: 
 CN=rpc-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5116
subClassOf: connectionPoint
governsID: 1.2.840.113556.1.5.27
rDNAttID: cn
uSNChanged: 5116
showInAdvancedViewOnly: TRUE
adminDisplayName: rpc-Entry
adminDescription: rpc-Entry
objectClassCategory: 2
lDAPDisplayName: rpcEntry
name: rpc-Entry
objectGUID:: 2Z4LqEQJO0Cy1bboXs8Vhg==
schemaIDGUID:: rHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=rpc-Entry,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=rpc-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: rpc-Group
distinguishedName: 
 CN=rpc-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5118
subClassOf: rpcEntry
governsID: 1.2.840.113556.1.5.80
rDNAttID: cn
uSNChanged: 5118
showInAdvancedViewOnly: TRUE
adminDisplayName: rpc-Group
adminDescription: rpc-Group
objectClassCategory: 1
lDAPDisplayName: rpcGroup
name: rpc-Group
objectGUID:: til7k+oz9kul0IHqplQobQ==
schemaIDGUID:: 3xthiPSM0BGv2gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: rpcNsObjectID
systemMayContain: rpcNsGroup
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=rpc-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=rpc-Profile,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: rpc-Profile
distinguishedName: 
 CN=rpc-Profile,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5120
subClassOf: rpcEntry
governsID: 1.2.840.113556.1.5.82
rDNAttID: cn
uSNChanged: 5120
showInAdvancedViewOnly: TRUE
adminDisplayName: rpc-Profile
adminDescription: rpc-Profile
objectClassCategory: 1
lDAPDisplayName: rpcProfile
name: rpc-Profile
objectGUID:: ru++IuLAIE2lt9ZwG6Y/mA==
schemaIDGUID:: 4RthiPSM0BGv2gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: container
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=rpc-Profile,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=rpc-Profile-Element,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: rpc-Profile-Element
distinguishedName: 
 CN=rpc-Profile-Element,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5122
subClassOf: rpcEntry
governsID: 1.2.840.113556.1.5.26
rDNAttID: cn
uSNChanged: 5122
showInAdvancedViewOnly: TRUE
adminDisplayName: rpc-Profile-Element
adminDescription: rpc-Profile-Element
objectClassCategory: 1
lDAPDisplayName: rpcProfileElement
name: rpc-Profile-Element
objectGUID:: zXTz2J4F70aYjhupzjdQKw==
schemaIDGUID:: z1OW8tB60BGv1gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: rpcProfile
systemMayContain: rpcNsProfileEntry
systemMayContain: rpcNsAnnotation
systemMustContain: rpcNsPriority
systemMustContain: rpcNsInterfaceID
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=rpc-Profile-Element,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=rpc-Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: rpc-Server
distinguishedName: 
 CN=rpc-Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5124
subClassOf: rpcEntry
governsID: 1.2.840.113556.1.5.81
rDNAttID: cn
uSNChanged: 5124
showInAdvancedViewOnly: TRUE
adminDisplayName: rpc-Server
adminDescription: rpc-Server
objectClassCategory: 1
lDAPDisplayName: rpcServer
name: rpc-Server
objectGUID:: yOqlm9lp/UWAiRMGYj7I5Q==
schemaIDGUID:: 4BthiPSM0BGv2gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: rpcNsObjectID
systemMayContain: rpcNsEntryFlags
systemMayContain: rpcNsCodeset
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=rpc-Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=rpc-Server-Element,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: rpc-Server-Element
distinguishedName: 
 CN=rpc-Server-Element,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5126
subClassOf: rpcEntry
governsID: 1.2.840.113556.1.5.73
rDNAttID: cn
uSNChanged: 5126
showInAdvancedViewOnly: TRUE
adminDisplayName: rpc-Server-Element
adminDescription: rpc-Server-Element
objectClassCategory: 1
lDAPDisplayName: rpcServerElement
name: rpc-Server-Element
objectGUID:: gBsUEgPhh0u3eEaCf9pNeA==
schemaIDGUID:: 0FOW8tB60BGv1gDAT9kwyQ==
systemOnly: FALSE
systemPossSuperiors: rpcServer
systemMustContain: rpcNsTransferSyntax
systemMustContain: rpcNsInterfaceID
systemMustContain: rpcNsBindings
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=rpc-Server-Element,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=RRAS-Administration-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: RRAS-Administration-Connection-Point
distinguishedName: 
 CN=RRAS-Administration-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=h
 ogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5128
subClassOf: serviceAdministrationPoint
governsID: 1.2.840.113556.1.5.150
rDNAttID: cn
uSNChanged: 5128
showInAdvancedViewOnly: TRUE
adminDisplayName: RRAS-Administration-Connection-Point
adminDescription: RRAS-Administration-Connection-Point
objectClassCategory: 1
lDAPDisplayName: rRASAdministrationConnectionPoint
name: RRAS-Administration-Connection-Point
objectGUID:: Z3XojdxZqki6MDwDA/fM1w==
schemaIDGUID:: vsU5KmCJ0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: computer
systemMayContain: msRRASAttribute
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=RRAS-Administration-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=h
 ogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=RRAS-Administration-Dictionary,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: RRAS-Administration-Dictionary
distinguishedName: 
 CN=RRAS-Administration-Dictionary,CN=Schema,CN=Configuration,DC=iii,DC=hogent,
 DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5130
subClassOf: top
governsID: 1.2.840.113556.1.5.156
rDNAttID: cn
uSNChanged: 5130
showInAdvancedViewOnly: TRUE
adminDisplayName: RRAS-Administration-Dictionary
adminDescription: RRAS-Administration-Dictionary
objectClassCategory: 1
lDAPDisplayName: rRASAdministrationDictionary
name: RRAS-Administration-Dictionary
objectGUID:: SfvpTmi/GEKw0rsaOhuyPQ==
schemaIDGUID:: rpib842T0RGuvQAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: msRRASVendorAttributeEntry
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWO
 WDSDDTSW;;;SY)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=RRAS-Administration-Dictionary,CN=Schema,CN=Configuration,DC=iii,DC=hogent,
 DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Sam-Domain-Base,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Sam-Domain-Base
distinguishedName: 
 CN=Sam-Domain-Base,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5132
subClassOf: top
governsID: 1.2.840.113556.1.5.2
rDNAttID: cn
uSNChanged: 5132
showInAdvancedViewOnly: TRUE
adminDisplayName: Sam-Domain-Base
adminDescription: Sam-Domain-Base
objectClassCategory: 3
lDAPDisplayName: samDomainBase
name: Sam-Domain-Base
objectGUID:: e2T34+H5vEK7DI1TFjMSpw==
schemaIDGUID:: kXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemMayContain: uASCompat
systemMayContain: serverState
systemMayContain: serverRole
systemMayContain: revision
systemMayContain: pwdProperties
systemMayContain: pwdHistoryLength
systemMayContain: oEMInformation
systemMayContain: objectSid
systemMayContain: nTSecurityDescriptor
systemMayContain: nextRid
systemMayContain: modifiedCountAtLastProm
systemMayContain: modifiedCount
systemMayContain: minPwdLength
systemMayContain: minPwdAge
systemMayContain: maxPwdAge
systemMayContain: lockoutThreshold
systemMayContain: lockoutDuration
systemMayContain: lockOutObservationWindow
systemMayContain: forceLogoff
systemMayContain: domainReplica
systemMayContain: creationTime
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Sam-Domain-Base,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Secret,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Secret
distinguishedName: CN=Secret,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5134
subClassOf: leaf
governsID: 1.2.840.113556.1.5.28
rDNAttID: cn
uSNChanged: 5134
showInAdvancedViewOnly: TRUE
adminDisplayName: Secret
adminDescription: Secret
objectClassCategory: 1
lDAPDisplayName: secret
name: Secret
objectGUID:: Xr00kaHHPEOZXQHnHil/gQ==
schemaIDGUID:: rnqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: priorValue
systemMayContain: priorSetTime
systemMayContain: lastSetTime
systemMayContain: currentValue
defaultSecurityDescriptor: D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Secret,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Security-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Security-Object
distinguishedName: 
 CN=Security-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5136
subClassOf: top
governsID: 1.2.840.113556.1.5.1
rDNAttID: cn
uSNChanged: 5136
showInAdvancedViewOnly: TRUE
adminDisplayName: Security-Object
adminDescription: Security-Object
objectClassCategory: 2
lDAPDisplayName: securityObject
name: Security-Object
objectGUID:: GVb9IJoGHU29WRXfwlQDWg==
schemaIDGUID:: r3qWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Security-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Security-Principal,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Security-Principal
distinguishedName: 
 CN=Security-Principal,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5138
subClassOf: top
governsID: 1.2.840.113556.1.5.6
rDNAttID: cn
uSNChanged: 5138
showInAdvancedViewOnly: TRUE
adminDisplayName: Security-Principal
adminDescription: Security-Principal
objectClassCategory: 3
lDAPDisplayName: securityPrincipal
name: Security-Principal
objectGUID:: OqPcVqbHeka+Hfg1Fk7gKg==
schemaIDGUID:: sHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemMayContain: supplementalCredentials
systemMayContain: sIDHistory
systemMayContain: securityIdentifier
systemMayContain: sAMAccountType
systemMayContain: rid
systemMayContain: tokenGroupsNoGCAcceptable
systemMayContain: tokenGroupsGlobalAndUniversal
systemMayContain: tokenGroups
systemMayContain: nTSecurityDescriptor
systemMayContain: msDS-KeyVersionNumber
systemMayContain: altSecurityIdentities
systemMayContain: accountNameHistory
systemMustContain: sAMAccountName
systemMustContain: objectSid
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Security-Principal,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Servers-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Servers-Container
distinguishedName: 
 CN=Servers-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5140
subClassOf: top
governsID: 1.2.840.113556.1.5.7000.48
rDNAttID: cn
uSNChanged: 5140
showInAdvancedViewOnly: TRUE
adminDisplayName: Servers-Container
adminDescription: Servers-Container
objectClassCategory: 1
lDAPDisplayName: serversContainer
name: Servers-Container
objectGUID:: pbgMJHOPG0KlAOPU7YV+Ag==
schemaIDGUID:: wKyA9/BW0RGpxgAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: site
defaultSecurityDescriptor: 
 D:(A;;CC;;;BA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Servers-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Service-Administration-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Service-Administration-Point
distinguishedName: 
 CN=Service-Administration-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC
 =be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5142
subClassOf: serviceConnectionPoint
governsID: 1.2.840.113556.1.5.94
rDNAttID: cn
uSNChanged: 5142
showInAdvancedViewOnly: TRUE
adminDisplayName: Service-Administration-Point
adminDescription: Service-Administration-Point
objectClassCategory: 1
lDAPDisplayName: serviceAdministrationPoint
name: Service-Administration-Point
objectGUID:: JvEyHhdVT0O4LNn/IklhDQ==
schemaIDGUID:: IzGxty640BGv7gAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: computer
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Service-Administration-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC
 =be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Service-Class,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Service-Class
distinguishedName: 
 CN=Service-Class,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5144
subClassOf: leaf
governsID: 1.2.840.113556.1.5.29
rDNAttID: cn
uSNChanged: 5144
showInAdvancedViewOnly: TRUE
adminDisplayName: Service-Class
adminDescription: Service-Class
objectClassCategory: 1
lDAPDisplayName: serviceClass
name: Service-Class
objectGUID:: fquyRHig/U+LepM60baw7g==
schemaIDGUID:: sXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: serviceClassInfo
systemMustContain: serviceClassID
systemMustContain: displayName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Service-Class,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Service-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Service-Connection-Point
distinguishedName: 
 CN=Service-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5146
subClassOf: connectionPoint
governsID: 1.2.840.113556.1.5.126
rDNAttID: cn
uSNChanged: 5146
showInAdvancedViewOnly: TRUE
adminDisplayName: Service-Connection-Point
adminDescription: Service-Connection-Point
objectClassCategory: 1
lDAPDisplayName: serviceConnectionPoint
name: Service-Connection-Point
objectGUID:: ALPYbkK/902coH0ffLS99Q==
schemaIDGUID:: wQ5jKNVB0RGpwQAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
systemPossSuperiors: computer
systemMayContain: versionNumberLo
systemMayContain: versionNumberHi
systemMayContain: versionNumber
systemMayContain: vendor
systemMayContain: serviceDNSNameType
systemMayContain: serviceDNSName
systemMayContain: serviceClassName
systemMayContain: serviceBindingInformation
systemMayContain: appSchemaVersion
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)(A;;
 RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Service-Connection-Point,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Service-Instance,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Service-Instance
distinguishedName: 
 CN=Service-Instance,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5148
subClassOf: connectionPoint
governsID: 1.2.840.113556.1.5.30
rDNAttID: cn
uSNChanged: 5148
showInAdvancedViewOnly: TRUE
adminDisplayName: Service-Instance
adminDescription: Service-Instance
objectClassCategory: 1
lDAPDisplayName: serviceInstance
name: Service-Instance
objectGUID:: PXIhGTDqXUiOYv8LjNlqiw==
schemaIDGUID:: snqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: winsockAddresses
systemMayContain: serviceInstanceVersion
systemMustContain: serviceClassID
systemMustContain: displayName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Service-Instance,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=simpleSecurityObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: simpleSecurityObject
distinguishedName: 
 CN=simpleSecurityObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5150
subClassOf: top
governsID: 0.9.2342.19200300.100.4.19
mayContain: userPassword
rDNAttID: cn
uSNChanged: 5150
showInAdvancedViewOnly: TRUE
adminDisplayName: simpleSecurityObject
adminDescription: 
 The simpleSecurityObject object class is used to allow an entry to have a user
 Password attribute when an entry's principal object classes do not allow userP
 assword as an attribute type.
objectClassCategory: 3
lDAPDisplayName: simpleSecurityObject
name: simpleSecurityObject
objectGUID:: GgRBVDCA+0mNXRjCWQol3g==
schemaIDGUID:: C5vmX0bhFU+wq8Hl1IjglA==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLOLORCWOWDSDDTDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
 (A;;RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=simpleSecurityObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Site-Link,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Site-Link
distinguishedName: 
 CN=Site-Link,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5152
subClassOf: top
governsID: 1.2.840.113556.1.5.147
rDNAttID: cn
uSNChanged: 5152
showInAdvancedViewOnly: TRUE
adminDisplayName: Site-Link
adminDescription: Site-Link
objectClassCategory: 1
lDAPDisplayName: siteLink
name: Site-Link
objectGUID:: ohugmt+kaUCWoCcWhPrDyQ==
schemaIDGUID:: 3iwM1VGJ0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: interSiteTransport
systemMayContain: schedule
systemMayContain: replInterval
systemMayContain: options
systemMayContain: cost
systemMustContain: siteList
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Site-Link,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Site-Link-Bridge,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Site-Link-Bridge
distinguishedName: 
 CN=Site-Link-Bridge,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5154
subClassOf: top
governsID: 1.2.840.113556.1.5.148
rDNAttID: cn
uSNChanged: 5154
showInAdvancedViewOnly: TRUE
adminDisplayName: Site-Link-Bridge
adminDescription: Site-Link-Bridge
objectClassCategory: 1
lDAPDisplayName: siteLinkBridge
name: Site-Link-Bridge
objectGUID:: 0zCUWidNzEejnRdUPIbakg==
schemaIDGUID:: 3ywM1VGJ0RGuvAAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: interSiteTransport
systemMustContain: siteLinkList
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Site-Link-Bridge,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Sites-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Sites-Container
distinguishedName: 
 CN=Sites-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5156
subClassOf: top
governsID: 1.2.840.113556.1.5.107
rDNAttID: cn
uSNChanged: 5156
showInAdvancedViewOnly: TRUE
adminDisplayName: Sites-Container
adminDescription: Sites-Container
objectClassCategory: 1
lDAPDisplayName: sitesContainer
name: Sites-Container
objectGUID:: cXbSrK4LtEOsvh6pGZnbHw==
schemaIDGUID:: 2hdBemfN0BGv/wAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: configuration
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Sites-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Storage,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Storage
distinguishedName: 
 CN=Storage,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5158
subClassOf: connectionPoint
governsID: 1.2.840.113556.1.5.33
rDNAttID: cn
uSNChanged: 5158
showInAdvancedViewOnly: TRUE
adminDisplayName: Storage
adminDescription: Storage
objectClassCategory: 1
lDAPDisplayName: storage
name: Storage
objectGUID:: lSDmIgNNbEuV9dy22TDyQg==
schemaIDGUID:: tXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: monikerDisplayName
systemMayContain: moniker
systemMayContain: iconPath
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Storage,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Subnet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Subnet
distinguishedName: CN=Subnet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5160
subClassOf: top
governsID: 1.2.840.113556.1.5.96
rDNAttID: cn
uSNChanged: 5160
showInAdvancedViewOnly: TRUE
adminDisplayName: Subnet
adminDescription: Subnet
objectClassCategory: 1
lDAPDisplayName: subnet
name: Subnet
objectGUID:: c0BlFG5RIkCXZN061l3F+Q==
schemaIDGUID:: JDGxty640BGv7gAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: subnetContainer
systemMayContain: siteObject
systemMayContain: physicalLocationObject
systemMayContain: location
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Subnet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Subnet-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Subnet-Container
distinguishedName: 
 CN=Subnet-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5162
subClassOf: top
governsID: 1.2.840.113556.1.5.95
rDNAttID: cn
uSNChanged: 5162
showInAdvancedViewOnly: TRUE
adminDisplayName: Subnet-Container
adminDescription: Subnet-Container
objectClassCategory: 1
lDAPDisplayName: subnetContainer
name: Subnet-Container
objectGUID:: h+9t8LUPtUy7RQ2+a+mXsQ==
schemaIDGUID:: JTGxty640BGv7gAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: sitesContainer
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPLC
 LORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Subnet-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Type-Library,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Type-Library
distinguishedName: 
 CN=Type-Library,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5165
subClassOf: top
governsID: 1.2.840.113556.1.5.53
rDNAttID: cn
uSNChanged: 5165
showInAdvancedViewOnly: TRUE
adminDisplayName: Type-Library
adminDescription: Type-Library
objectClassCategory: 1
lDAPDisplayName: typeLibrary
name: Type-Library
objectGUID:: whJk7Cd63kao+VRuWfhG4Q==
schemaIDGUID:: 4hYUKGgZ0BGijwCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: classStore
systemMayContain: cOMUniqueLIBID
systemMayContain: cOMInterfaceID
systemMayContain: cOMClassID
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Type-Library,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Volume,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Volume
distinguishedName: CN=Volume,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093703.0Z
uSNCreated: 5167
subClassOf: connectionPoint
governsID: 1.2.840.113556.1.5.36
rDNAttID: cn
uSNChanged: 5167
showInAdvancedViewOnly: TRUE
adminDisplayName: Volume
adminDescription: Volume
objectClassCategory: 1
lDAPDisplayName: volume
name: Volume
objectGUID:: Aaz8dbKC8kuaym8xsu0kWA==
schemaIDGUID:: u3qWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemMayContain: lastContentIndexed
systemMayContain: contentIndexingAllowed
systemMustContain: uNCName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Volume,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Top,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Top
distinguishedName: 
 CN=msSFU-30-Top,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115641.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5222
subClassOf: top
governsID: 1.2.840.113556.1.6.18.2.200
mayContain: msSFU30NisMapName
mayContain: msSFU30NisDomain
rDNAttID: cn
uSNChanged: 5222
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30Top
adminDescription: msSFU30Top
objectClassCategory: 1
lDAPDisplayName: msSFU30Top
name: msSFU-30-Top
objectGUID:: wH0yfEk970SJdNaSLBsYNg==
schemaIDGUID:: 9LPXoYVAj0WgsmwOTvxSGg==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Top,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Nis-Map,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Nis-Map
distinguishedName: 
 CN=msSFU-30-Nis-Map,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115641.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5224
subClassOf: top
governsID: 1.2.840.113556.1.6.18.2.218
mayContain: description
mayContain: msSFU30NisMapName
rDNAttID: cn
uSNChanged: 5224
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30NisMap
adminDescription: msSFU30NisMap
objectClassCategory: 1
lDAPDisplayName: msSFU30NisMap
name: msSFU-30-Nis-Map
objectGUID:: v0jzn+gmQkyCqyEcq46d1Q==
schemaIDGUID:: jTKbzrHqZUykaCpb8KQOxw==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Nis-Map,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Ip-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Ip-Service
distinguishedName: 
 CN=msSFU-30-Ip-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115642.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5226
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.206
mayContain: description
mayContain: msSFU30Aliases
mayContain: msSFU30IpServiceProtocol
mayContain: msSFU30IpServicePort
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5226
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30IpService
adminDescription: msSFU30IpService
objectClassCategory: 1
lDAPDisplayName: msSFU30IpService
name: msSFU-30-Ip-Service
objectGUID:: yzMf45Dse0OAfij2osDiCQ==
schemaIDGUID:: qcjeVStCCUO/jqGpu1numg==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Ip-Service,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-NIS-Map-Config,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-NIS-Map-Config
distinguishedName: 
 CN=msSFU-30-NIS-Map-Config,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115643.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5228
subClassOf: top
governsID: 1.2.840.113556.1.6.18.2.217
mayContain: msSFU30SearchAttributes
mayContain: msSFU30IntraFieldSeparator
mayContain: msSFU30NSMAPFieldPosition
mayContain: msSFU30FieldSeparator
mayContain: msSFU30KeyAttributes
mayContain: msSFU30MapFilter
mayContain: msSFU30ResultAttributes
rDNAttID: cn
uSNChanged: 5228
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30NISMapConfig
adminDescription: msSFU30NISMapConfig
objectClassCategory: 1
lDAPDisplayName: msSFU30NISMapConfig
name: msSFU-30-NIS-Map-Config
objectGUID:: 1iiSNwSpOEaLPkfWusnXeA==
schemaIDGUID:: 5Tf7MAAQI0mpD6SgX+Mrsg==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-NIS-Map-Config,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Ip-Protocol,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Ip-Protocol
distinguishedName: 
 CN=msSFU-30-Ip-Protocol,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115643.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5230
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.207
mayContain: description
mayContain: msSFU30Aliases
mayContain: msSFU30IpProtocolNumber
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5230
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30IpProtocol
adminDescription: msSFU30IpProtocol
objectClassCategory: 1
lDAPDisplayName: msSFU30IpProtocol
name: msSFU-30-Ip-Protocol
objectGUID:: s2x4N94fwEucrC7RhYmHzA==
schemaIDGUID:: 6RA4sZuXO0WpLeFskV8hgw==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Ip-Protocol,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Ieee-802-Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Ieee-802-Device
distinguishedName: 
 CN=msSFU-30-Ieee-802-Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115644.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5232
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.213
mayContain: msSFU30MacAddress
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5232
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30Ieee802Device
adminDescription: msSFU30Ieee802Device
objectClassCategory: 1
lDAPDisplayName: msSFU30Ieee802Device
name: msSFU-30-Ieee-802-Device
objectGUID:: huQkrjkkq0WUtmRVW8eQxg==
schemaIDGUID:: u5LLJLe+WUypWhYNzkXriQ==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Ieee-802-Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Shadow-Account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Shadow-Account
distinguishedName: 
 CN=msSFU-30-Shadow-Account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115644.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5234
subClassOf: top
governsID: 1.2.840.113556.1.6.18.2.201
mayContain: msSFU30ShadowWarning
mayContain: msSFU30ShadowMax
mayContain: msSFU30ShadowMin
mayContain: msSFU30ShadowLastChange
mayContain: msSFU30Name
mayContain: description
mayContain: msSFU30ShadowFlag
mayContain: msSFU30ShadowExpire
mayContain: msSFU30ShadowInactive
rDNAttID: cn
uSNChanged: 5234
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30ShadowAccount
adminDescription: msSFU30ShadowAccount
objectClassCategory: 3
lDAPDisplayName: msSFU30ShadowAccount
name: msSFU-30-Shadow-Account
objectGUID:: mDmZO1HBvkKd3ni05cvk/Q==
schemaIDGUID:: i4v9viMvsE2c2Rl3VQTxrg==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Shadow-Account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Ip-Host,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Ip-Host
distinguishedName: 
 CN=msSFU-30-Ip-Host,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115645.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5236
subClassOf: top
governsID: 1.2.840.113556.1.6.18.2.203
mayContain: description
mayContain: msSFU30Aliases
mayContain: msSFU30IpHostNumber
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
rDNAttID: cn
uSNChanged: 5236
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30IpHost
adminDescription: msSFU30IpHost
objectClassCategory: 3
lDAPDisplayName: msSFU30IpHost
name: msSFU-30-Ip-Host
objectGUID:: 6OS674/j30eWOn7o7EBsHg==
schemaIDGUID:: qlvnmFmnmUOFkPaLcGcS2Q==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Ip-Host,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Bootable-Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Bootable-Device
distinguishedName: 
 CN=msSFU-30-Bootable-Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115646.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5238
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.205
mayContain: msSFU30BootParameter
mayContain: msSFU30BootFile
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5238
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30BootableDevice
adminDescription: msSFU30BootableDevice
objectClassCategory: 1
lDAPDisplayName: msSFU30BootableDevice
name: msSFU-30-Bootable-Device
objectGUID:: Feh1mqyRF025/nNaB5uWkA==
schemaIDGUID:: xu+ZJGMhHESfkTQS+QWMFA==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Bootable-Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Nis-Netgroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Nis-Netgroup
distinguishedName: 
 CN=msSFU-30-Nis-Netgroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115646.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5240
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.210
mayContain: msSFU30NetgroupUserAtDomain
mayContain: msSFU30NetgroupHostAtDomain
mayContain: msSFU30MemberOfNisNetgroup
mayContain: msSFU30MemberNisNetgroup
mayContain: msSFU30Name
mayContain: description
mayContain: msSFU30NetgroupDetail
rDNAttID: cn
uSNChanged: 5240
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30NisNetgroup
adminDescription: msSFU30NisNetgroup
objectClassCategory: 1
lDAPDisplayName: msSFU30NisNetgroup
name: msSFU-30-Nis-Netgroup
objectGUID:: JAvttKanSEqwWgQ9cEx+IQ==
schemaIDGUID:: QBovmEdeq0Whv3oE4eabyg==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Nis-Netgroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Posix-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Posix-Group
distinguishedName: 
 CN=msSFU-30-Posix-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115647.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5242
subClassOf: top
governsID: 1.2.840.113556.1.6.18.2.204
mayContain: msSFU30MemberUid
mayContain: msSFU30Password
mayContain: msSFU30GidNumber
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: description
mayContain: msSFU30PosixMember
rDNAttID: cn
uSNChanged: 5242
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30PosixGroup
adminDescription: msSFU30PosixGroup
objectClassCategory: 3
lDAPDisplayName: msSFU30PosixGroup
name: msSFU-30-Posix-Group
objectGUID:: LVDz2yeuLkOKezegOdtq0g==
schemaIDGUID:: BIphmfNW90CssNELjzHm6A==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Posix-Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Posix-Account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Posix-Account
distinguishedName: 
 CN=msSFU-30-Posix-Account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115647.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5244
subClassOf: top
governsID: 1.2.840.113556.1.6.18.2.202
mayContain: msSFU30Password
mayContain: msSFU30GidNumber
mayContain: msSFU30UidNumber
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: msSFU30PosixMemberOf
mayContain: description
mayContain: msSFU30Gecos
mayContain: msSFU30LoginShell
mayContain: msSFU30HomeDirectory
rDNAttID: cn
uSNChanged: 5244
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30PosixAccount
adminDescription: msSFU30PosixAccount
objectClassCategory: 3
lDAPDisplayName: msSFU30PosixAccount
name: msSFU-30-Posix-Account
objectGUID:: Qd56wOq1HkSHgbhicbPhIA==
schemaIDGUID:: uqs14MFU50WL7nya7UGCBw==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Posix-Account,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Nis-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Nis-Object
distinguishedName: 
 CN=msSFU-30-Nis-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115648.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5246
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.214
mayContain: description
mayContain: msSFU30NisMapName
mayContain: msSFU30NisMapEntry
rDNAttID: cn
uSNChanged: 5246
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30NisObject
adminDescription: msSFU30NisObject
objectClassCategory: 1
lDAPDisplayName: msSFU30NisObject
name: msSFU-30-Nis-Object
objectGUID:: BqFadkU9+0mC94sdfiE6oA==
schemaIDGUID:: YQgkZnrHYUeC+eR1lWqvfg==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Nis-Object,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Ip-Network,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Ip-Network
distinguishedName: 
 CN=msSFU-30-Ip-Network,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115648.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5248
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.209
mayContain: description
mayContain: msSFU30Aliases
mayContain: msSFU30IpNetmaskNumber
mayContain: msSFU30IpNetworkNumber
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5248
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30IpNetwork
adminDescription: msSFU30IpNetwork
objectClassCategory: 1
lDAPDisplayName: msSFU30IpNetwork
name: msSFU-30-Ip-Network
objectGUID:: VvghUWnGCU26xdsnnbPTVQ==
schemaIDGUID:: hmTTrjCFiUKruN521V59zw==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Ip-Network,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Domain-Info,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Domain-Info
distinguishedName: 
 CN=msSFU-30-Domain-Info,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115648.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5250
subClassOf: top
governsID: 1.2.840.113556.1.6.18.2.215
mayContain: msSFU30MasterServerName
mayContain: msSFU30IsValidContainer
mayContain: msSFU30SearchContainer
mayContain: msSFU30YpServers
mayContain: msSFU30Domains
mayContain: msSFU30CryptMethod
mayContain: msSFU30MaxUidNumber
mayContain: msSFU30MaxGidNumber
mayContain: msSFU30OrderNumber
rDNAttID: cn
uSNChanged: 5250
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30DomainInfo
adminDescription: msSFU30DomainInfo
objectClassCategory: 1
lDAPDisplayName: msSFU30DomainInfo
name: msSFU-30-Domain-Info
objectGUID:: Zki1JP0xH0WQJ9t5dC2RPQ==
schemaIDGUID:: aYWkuuB4tUmSXbSSaBswpA==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Domain-Info,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Onc-Rpc,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Onc-Rpc
distinguishedName: 
 CN=msSFU-30-Onc-Rpc,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115649.0Z
whenChanged: 20080624093705.0Z
possSuperiors: container
uSNCreated: 5252
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.208
mayContain: description
mayContain: msSFU30Aliases
mayContain: msSFU30OncRpcNumber
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5252
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30OncRpc
adminDescription: msSFU30OncRpc
objectClassCategory: 1
lDAPDisplayName: msSFU30OncRpc
name: msSFU-30-Onc-Rpc
objectGUID:: V8RvgqC9P02o2MkbxCnWFg==
schemaIDGUID:: +e6izEGCHkWUoAypIwEo4w==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Onc-Rpc,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NisMap,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NisMap
distinguishedName: CN=NisMap,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100101.0Z
whenChanged: 20080624093706.0Z
possSuperiors: domainDNS
possSuperiors: container
possSuperiors: organizationalUnit
uSNCreated: 5309
subClassOf: top
governsID: 1.3.6.1.1.1.2.9
mustContain: cn
mustContain: nisMapName
mayContain: description
rDNAttID: cn
uSNChanged: 5309
showInAdvancedViewOnly: TRUE
adminDisplayName: nisMap
adminDescription: A generic abstraction of a nis map
objectClassCategory: 1
lDAPDisplayName: nisMap
name: NisMap
objectGUID:: d22om/85bkucNuxMOxUYXw==
schemaIDGUID:: bGZydsECM0+ez/ZJwd2bfA==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NisMap,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=IpProtocol,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: IpProtocol
distinguishedName: 
 CN=IpProtocol,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100101.0Z
whenChanged: 20080624093706.0Z
possSuperiors: domainDNS
possSuperiors: nisMap
possSuperiors: container
possSuperiors: organizationalUnit
uSNCreated: 5311
subClassOf: top
governsID: 1.3.6.1.1.1.2.4
mustContain: cn
mustContain: ipProtocolNumber
mayContain: description
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: nisMapName
mayContain: msSFU30Aliases
rDNAttID: cn
uSNChanged: 5311
showInAdvancedViewOnly: TRUE
adminDisplayName: ipProtocol
adminDescription: Abstraction of an IP protocol
objectClassCategory: 1
lDAPDisplayName: ipProtocol
name: IpProtocol
objectGUID:: Ohg6Mqvd5UmjbnDBqoAHuQ==
schemaIDGUID:: 0sstnPD7x02s4INW3NDwEw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=IpProtocol,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=PosixGroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: PosixGroup
distinguishedName: 
 CN=PosixGroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100102.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5313
subClassOf: top
governsID: 1.3.6.1.1.1.2.2
mayContain: cn
mayContain: userPassword
mayContain: unixUserPassword
mayContain: description
mayContain: gidNumber
mayContain: memberUid
rDNAttID: cn
uSNChanged: 5313
showInAdvancedViewOnly: TRUE
adminDisplayName: posixGroup
adminDescription: Abstraction of a group of acconts
objectClassCategory: 3
lDAPDisplayName: posixGroup
name: PosixGroup
objectGUID:: i9KACrGTK0+hNNSlJvZ8PA==
schemaIDGUID:: uFCTKiwG0E6ZA93hDQbeug==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=PosixGroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=IEEE802Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: IEEE802Device
distinguishedName: 
 CN=IEEE802Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100102.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5315
subClassOf: top
governsID: 1.3.6.1.1.1.2.11
mayContain: cn
mayContain: macAddress
rDNAttID: cn
uSNChanged: 5315
showInAdvancedViewOnly: TRUE
adminDisplayName: ieee802Device
adminDescription: A device with a MAC address
objectClassCategory: 3
lDAPDisplayName: ieee802Device
name: IEEE802Device
objectGUID:: oW3bFBA0p0GeBLPge+L70Q==
schemaIDGUID:: KeWZpjemfUug+13EZqC4pw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=IEEE802Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NisNetgroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NisNetgroup
distinguishedName: 
 CN=NisNetgroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100102.0Z
whenChanged: 20080624093706.0Z
possSuperiors: domainDNS
possSuperiors: nisMap
possSuperiors: container
possSuperiors: organizationalUnit
uSNCreated: 5317
subClassOf: top
governsID: 1.3.6.1.1.1.2.8
mustContain: cn
mayContain: description
mayContain: memberNisNetgroup
mayContain: nisNetgroupTriple
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: nisMapName
mayContain: msSFU30NetgroupHostAtDomain
mayContain: msSFU30NetgroupUserAtDomain
rDNAttID: cn
uSNChanged: 5317
showInAdvancedViewOnly: TRUE
adminDisplayName: nisNetgroup
adminDescription: Abstraction of a netgroup. May refer to other netgroups
objectClassCategory: 1
lDAPDisplayName: nisNetgroup
name: NisNetgroup
objectGUID:: IWcF2SJyU0ao3eK8Po0QYg==
schemaIDGUID:: hL/vcntuXEqo24p1p8rSVA==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NisNetgroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=PosixAccount,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: PosixAccount
distinguishedName: 
 CN=PosixAccount,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100103.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5319
subClassOf: top
governsID: 1.3.6.1.1.1.2.0
mayContain: uid
mayContain: cn
mayContain: uidNumber
mayContain: gidNumber
mayContain: unixHomeDirectory
mayContain: homeDirectory
mayContain: userPassword
mayContain: unixUserPassword
mayContain: loginShell
mayContain: gecos
mayContain: description
rDNAttID: uid
uSNChanged: 5319
showInAdvancedViewOnly: TRUE
adminDisplayName: posixAccount
adminDescription: Abstraction of an account with posix attributes
objectClassCategory: 3
lDAPDisplayName: posixAccount
name: PosixAccount
objectGUID:: rEJ4bvEz9U2U3R4GKUKKAA==
schemaIDGUID:: QbtErdVniE21dXsgZ0522A==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=PosixAccount,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ShadowAccount,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ShadowAccount
distinguishedName: 
 CN=ShadowAccount,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100104.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5321
subClassOf: top
governsID: 1.3.6.1.1.1.2.1
mayContain: uid
mayContain: userPassword
mayContain: description
mayContain: shadowLastChange
mayContain: shadowMin
mayContain: shadowMax
mayContain: shadowWarning
mayContain: shadowInactive
mayContain: shadowExpire
mayContain: shadowFlag
rDNAttID: uid
uSNChanged: 5321
showInAdvancedViewOnly: TRUE
adminDisplayName: shadowAccount
adminDescription: Additional attributes for shadow passwords
objectClassCategory: 3
lDAPDisplayName: shadowAccount
name: ShadowAccount
objectGUID:: UFk34HgZt027WNHHTdK+Uw==
schemaIDGUID:: Z4RtWxgadEGzUJzG57SsjQ==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ShadowAccount,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=BootableDevice,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: BootableDevice
distinguishedName: 
 CN=BootableDevice,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100104.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5323
subClassOf: top
governsID: 1.3.6.1.1.1.2.12
mayContain: cn
mayContain: bootParameter
mayContain: bootFile
rDNAttID: cn
uSNChanged: 5323
showInAdvancedViewOnly: TRUE
adminDisplayName: bootableDevice
adminDescription: A device with boot parameters
objectClassCategory: 3
lDAPDisplayName: bootableDevice
name: BootableDevice
objectGUID:: W6nGeRgf/UaloBH3f44Ptw==
schemaIDGUID:: dyTLS7NLRUWp/Ptm4Ta0NQ==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=BootableDevice,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-Print-ConnectionPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-Print-ConnectionPolicy
distinguishedName: 
 CN=ms-Print-ConnectionPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100104.0Z
whenChanged: 20080624093706.0Z
possSuperiors: container
uSNCreated: 5325
subClassOf: top
governsID: 1.2.840.113556.1.6.23.2
mustContain: cn
mayContain: printerName
mayContain: printAttributes
mayContain: serverName
mayContain: uNCName
rDNAttID: cn
uSNChanged: 5325
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-Print-ConnectionPolicy
adminDescription: Pushed Printer Connection Policy1
objectClassCategory: 1
lDAPDisplayName: msPrint-ConnectionPolicy
name: ms-Print-ConnectionPolicy
objectGUID:: lY0HTTGP6021+TZm0/OBSA==
schemaIDGUID:: xzNvodZ/KEiTZENROP2gjQ==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-Print-ConnectionPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=OncRpc,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: OncRpc
distinguishedName: CN=OncRpc,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100105.0Z
whenChanged: 20080624093706.0Z
possSuperiors: domainDNS
possSuperiors: nisMap
possSuperiors: container
possSuperiors: organizationalUnit
uSNCreated: 5327
subClassOf: top
governsID: 1.3.6.1.1.1.2.5
mustContain: cn
mustContain: oncRpcNumber
mayContain: description
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: nisMapName
mayContain: msSFU30Aliases
rDNAttID: cn
uSNChanged: 5327
showInAdvancedViewOnly: TRUE
adminDisplayName: oncRpc
adminDescription: 
 Abstraction of an Open Network Computing (ONC) [RFC1057] Remote Procedure Call
  (RPC) binding
objectClassCategory: 1
lDAPDisplayName: oncRpc
name: OncRpc
objectGUID:: jGTlgoy4O0iaz7dmGbh9bQ==
schemaIDGUID:: Xh7dyvz+P0+1qXDplCBDAw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=OncRpc,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=IpHost,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: IpHost
distinguishedName: CN=IpHost,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100105.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5329
subClassOf: top
governsID: 1.3.6.1.1.1.2.6
mayContain: manager
mayContain: cn
mayContain: description
mayContain: ipHostNumber
mayContain: uid
mayContain: l
rDNAttID: cn
uSNChanged: 5329
showInAdvancedViewOnly: TRUE
adminDisplayName: ipHost
adminDescription: Abstraction of a host, an IP device.
objectClassCategory: 3
lDAPDisplayName: ipHost
name: IpHost
objectGUID:: TH3gaM8R0Eyc//CCmeL98Q==
schemaIDGUID:: RhaRqyeIlU+HgFqPAI62jw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=IpHost,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NisObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NisObject
distinguishedName: 
 CN=NisObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100106.0Z
whenChanged: 20080624093706.0Z
possSuperiors: domainDNS
possSuperiors: nisMap
possSuperiors: container
possSuperiors: organizationalUnit
uSNCreated: 5331
subClassOf: top
governsID: 1.3.6.1.1.1.2.10
mustContain: cn
mustContain: nisMapName
mustContain: nisMapEntry
mayContain: description
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
rDNAttID: cn
uSNChanged: 5331
showInAdvancedViewOnly: TRUE
adminDisplayName: nisObject
adminDescription: An entry in a NIS map
objectClassCategory: 1
lDAPDisplayName: nisObject
name: NisObject
objectGUID:: DV0GzoDhS0G6ebbSdcJVGw==
schemaIDGUID:: k4pPkFRJX0yx4VPAl6MeEw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NisObject,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=IpService,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: IpService
distinguishedName: 
 CN=IpService,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100107.0Z
whenChanged: 20080624093706.0Z
possSuperiors: domainDNS
possSuperiors: nisMap
possSuperiors: container
possSuperiors: organizationalUnit
uSNCreated: 5333
subClassOf: top
governsID: 1.3.6.1.1.1.2.3
mustContain: ipServiceProtocol
mustContain: ipServicePort
mustContain: cn
mayContain: description
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: msSFU30Aliases
mayContain: nisMapName
rDNAttID: cn
uSNChanged: 5333
showInAdvancedViewOnly: TRUE
adminDisplayName: ipService
adminDescription: Abstraction of an Internet Protocol service.
objectClassCategory: 1
lDAPDisplayName: ipService
name: IpService
objectGUID:: vN6sMkf54EueMrfedNzvNQ==
schemaIDGUID:: 3/oXJZf6rUid5nmsVyH4ZA==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=IpService,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=IpNetwork,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: IpNetwork
distinguishedName: 
 CN=IpNetwork,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100107.0Z
whenChanged: 20080624093706.0Z
possSuperiors: domainDNS
possSuperiors: nisMap
possSuperiors: container
possSuperiors: organizationalUnit
uSNCreated: 5335
subClassOf: top
governsID: 1.3.6.1.1.1.2.7
mustContain: cn
mustContain: ipNetworkNumber
mayContain: manager
mayContain: description
mayContain: ipNetmaskNumber
mayContain: uid
mayContain: l
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: nisMapName
mayContain: msSFU30Aliases
rDNAttID: cn
uSNChanged: 5335
showInAdvancedViewOnly: TRUE
adminDisplayName: ipNetwork
adminDescription: 
 Abstraction of a network. The distinguished value of the cn attribute denotes 
 the network's cannonical name
objectClassCategory: 1
lDAPDisplayName: ipNetwork
name: IpNetwork
objectGUID:: 2as80NchB0+2Z+tfN32MaA==
schemaIDGUID:: wzZY2T4U+0OZKrBX8eyt+Q==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=IpNetwork,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Device
distinguishedName: CN=Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5337
subClassOf: top
governsID: 2.5.6.14
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: nisMapName
mayContain: msSFU30Aliases
rDNAttID: cn
uSNChanged: 5337
showInAdvancedViewOnly: TRUE
adminDisplayName: Device
adminDescription: Device
auxiliaryClass: ipHost
auxiliaryClass: ieee802Device
auxiliaryClass: bootableDevice
objectClassCategory: 0
lDAPDisplayName: device
name: Device
objectGUID:: k8QvmNbMREyc4zqMVJaz0w==
schemaIDGUID:: jnqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemPossSuperiors: organizationalUnit
systemPossSuperiors: organization
systemPossSuperiors: container
systemMayContain: serialNumber
systemMayContain: seeAlso
systemMayContain: owner
systemMayContain: ou
systemMayContain: o
systemMayContain: l
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Device,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Contact,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Contact
distinguishedName: 
 CN=Contact,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5338
subClassOf: organizationalPerson
governsID: 1.2.840.113556.1.5.15
mayContain: msDS-SourceObjectDN
rDNAttID: cn
uSNChanged: 5338
showInAdvancedViewOnly: TRUE
adminDisplayName: Contact
adminDescription: Contact
objectClassCategory: 1
lDAPDisplayName: contact
name: Contact
objectGUID:: 6s5YsiDHx0O0PIlxziqgrw==
schemaIDGUID:: 0B60XEwO0BGihgCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemMayContain: notes
systemMustContain: cn
systemAuxiliaryClass: mailRecipient
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Trusted-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Trusted-Domain
distinguishedName: 
 CN=Trusted-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5344
subClassOf: leaf
governsID: 1.2.840.113556.1.5.34
rDNAttID: cn
uSNChanged: 5344
showInAdvancedViewOnly: TRUE
adminDisplayName: Trusted-Domain
adminDescription: Trusted-Domain
objectClassCategory: 1
lDAPDisplayName: trustedDomain
name: Trusted-Domain
objectGUID:: GrVVuKaZhEuYZwSCuOYxFA==
schemaIDGUID:: uHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: msDS-SupportedEncryptionTypes
systemMayContain: trustType
systemMayContain: trustPosixOffset
systemMayContain: trustPartner
systemMayContain: trustDirection
systemMayContain: trustAuthOutgoing
systemMayContain: trustAuthIncoming
systemMayContain: trustAttributes
systemMayContain: securityIdentifier
systemMayContain: msDS-TrustForestTrustInfo
systemMayContain: mS-DS-CreatorSID
systemMayContain: initialAuthOutgoing
systemMayContain: initialAuthIncoming
systemMayContain: flatName
systemMayContain: domainIdentifier
systemMayContain: domainCrossRef
systemMayContain: additionalTrustedServiceNames
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(OA;;WP;736e4812-af31-11d2-b7df-00805f48caeb;bf967ab8-0de6-11d0-
 a285-00aa003049e2;CO)(A;;SD;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Trusted-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-net-ieee-8023-GroupPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-net-ieee-8023-GroupPolicy
distinguishedName: 
 CN=ms-net-ieee-8023-GroupPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC
 =be
instanceType: 4
whenCreated: 20080618100131.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5363
subClassOf: top
governsID: 1.2.840.113556.1.5.252
rDNAttID: cn
uSNChanged: 5363
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-net-ieee-8023-GroupPolicy
adminDescription: 
 This class represents an 802.3 wired network group policy object.  This class 
 contains identifiers and configuration data relevant to an 802.3 wired network
 .
objectClassCategory: 1
lDAPDisplayName: ms-net-ieee-8023-GroupPolicy
name: ms-net-ieee-8023-GroupPolicy
objectGUID:: LCmkzgqqFUCiTgpAkXHKzQ==
schemaIDGUID:: ajqgmRmrRkSTUAy4eO0tmw==
systemOnly: FALSE
systemPossSuperiors: person
systemPossSuperiors: container
systemPossSuperiors: computer
systemMayContain: ms-net-ieee-8023-GP-PolicyGUID
systemMayContain: ms-net-ieee-8023-GP-PolicyData
systemMayContain: ms-net-ieee-8023-GP-PolicyReserved
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-net-ieee-8023-GroupPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC
 =be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-net-ieee-80211-GroupPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-net-ieee-80211-GroupPolicy
distinguishedName: 
 CN=ms-net-ieee-80211-GroupPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,D
 C=be
instanceType: 4
whenCreated: 20080618100132.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5365
subClassOf: top
governsID: 1.2.840.113556.1.5.251
rDNAttID: cn
uSNChanged: 5365
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-net-ieee-80211-GroupPolicy
adminDescription: 
 This class represents an 802.11 wireless network group policy object.  This cl
 ass contains identifiers and configuration data relevant to an 802.11 wireless
  network.
objectClassCategory: 1
lDAPDisplayName: ms-net-ieee-80211-GroupPolicy
name: ms-net-ieee-80211-GroupPolicy
objectGUID:: MmK31mtGk0eTvgiy+p0ImA==
schemaIDGUID:: Yxi4HCK4eUOeol/3vcY4bQ==
systemOnly: FALSE
systemPossSuperiors: person
systemPossSuperiors: container
systemPossSuperiors: computer
systemMayContain: ms-net-ieee-80211-GP-PolicyGUID
systemMayContain: ms-net-ieee-80211-GP-PolicyData
systemMayContain: ms-net-ieee-80211-GP-PolicyReserved
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-net-ieee-80211-GroupPolicy,CN=Schema,CN=Configuration,DC=iii,DC=hogent,D
 C=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Group
distinguishedName: CN=Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5367
subClassOf: top
governsID: 1.2.840.113556.1.5.8
mayContain: msSFU30Name
mayContain: msSFU30NisDomain
mayContain: msSFU30PosixMember
rDNAttID: cn
uSNChanged: 5367
showInAdvancedViewOnly: TRUE
adminDisplayName: Group
adminDescription: Group
auxiliaryClass: posixGroup
auxiliaryClass: msSFU30PosixGroup
objectClassCategory: 1
lDAPDisplayName: group
name: Group
objectGUID:: ojLFLCP22Ui4h7ucG/X1VA==
schemaIDGUID:: nHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: msDS-AzScope
systemPossSuperiors: msDS-AzApplication
systemPossSuperiors: msDS-AzAdminManager
systemPossSuperiors: container
systemPossSuperiors: builtinDomain
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemMayContain: msDS-AzApplicationData
systemMayContain: msDS-AzLastImportedBizRulePath
systemMayContain: msDS-AzBizRuleLanguage
systemMayContain: msDS-AzBizRule
systemMayContain: msDS-AzGenericData
systemMayContain: msDS-AzObjectGuid
systemMayContain: primaryGroupToken
systemMayContain: operatorCount
systemMayContain: nTGroupMembers
systemMayContain: nonSecurityMember
systemMayContain: msDS-NonMembers
systemMayContain: msDS-AzLDAPQuery
systemMayContain: member
systemMayContain: managedBy
systemMayContain: groupMembershipSAM
systemMayContain: groupAttributes
systemMayContain: mail
systemMayContain: desktopProfile
systemMayContain: controlAccessRights
systemMayContain: adminCount
systemMustContain: groupType
systemAuxiliaryClass: mailRecipient
systemAuxiliaryClass: securityPrincipal
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;AO)(A;;RPLCLORC;;;PS)(OA;;CR;ab
 721a55-1e2f-11d0-9819-00aa0040529b;;AU)(OA;;RP;46a9b11d-60ae-405a-b7e8-ff8a58d
 456d2;;S-1-5-32-560)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Group,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Cross-Ref,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Cross-Ref
distinguishedName: 
 CN=Cross-Ref,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5369
subClassOf: top
governsID: 1.2.840.113556.1.3.11
rDNAttID: cn
uSNChanged: 5369
showInAdvancedViewOnly: TRUE
adminDisplayName: Cross-Ref
adminDescription: Cross-Ref
objectClassCategory: 1
lDAPDisplayName: crossRef
name: Cross-Ref
objectGUID:: EcyHfbZi7EGXFYAvXNKmOA==
schemaIDGUID:: jXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: crossRefContainer
systemMayContain: msDS-NC-RO-Replica-Locations
systemMayContain: trustParent
systemMayContain: superiorDNSRoot
systemMayContain: rootTrust
systemMayContain: nTMixedDomain
systemMayContain: nETBIOSName
systemMayContain: Enabled
systemMayContain: msDS-SDReferenceDomain
systemMayContain: msDS-Replication-Notify-Subsequent-DSA-Delay
systemMayContain: msDS-Replication-Notify-First-DSA-Delay
systemMayContain: msDS-NC-Replica-Locations
systemMayContain: msDS-DnsRootAlias
systemMayContain: msDS-Behavior-Version
systemMustContain: nCName
systemMustContain: dnsRoot
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Cross-Ref,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Mail-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Mail-Recipient
distinguishedName: 
 CN=Mail-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5371
subClassOf: top
governsID: 1.2.840.113556.1.3.46
mayContain: msDS-PhoneticDisplayName
mayContain: userSMIMECertificate
mayContain: secretary
mayContain: msExchLabeledURI
mayContain: msExchAssistantName
mayContain: labeledURI
rDNAttID: cn
uSNChanged: 5371
showInAdvancedViewOnly: TRUE
adminDisplayName: Mail-Recipient
adminDescription: Mail-Recipient
objectClassCategory: 3
lDAPDisplayName: mailRecipient
name: Mail-Recipient
objectGUID:: 4iSzhrJbG0CiWA165GK1Aw==
schemaIDGUID:: oXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemMayContain: userCertificate
systemMayContain: userCert
systemMayContain: textEncodedORAddress
systemMayContain: telephoneNumber
systemMayContain: showInAddressBook
systemMayContain: legacyExchangeDN
systemMayContain: garbageCollPeriod
systemMayContain: info
systemMustContain: cn
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Mail-Recipient,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Az-Admin-Manager,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Az-Admin-Manager
distinguishedName: 
 CN=ms-DS-Az-Admin-Manager,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5373
subClassOf: top
governsID: 1.2.840.113556.1.5.234
rDNAttID: cn
uSNChanged: 5373
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-DS-Az-Admin-Manager
adminDescription: Root of Authorization Policy store instance
objectClassCategory: 1
lDAPDisplayName: msDS-AzAdminManager
name: ms-DS-Az-Admin-Manager
objectGUID:: jjA0CGl2kkuIOdELPGEUKw==
schemaIDGUID:: URDuzyhfrkuoY10MwYqO0Q==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemPossSuperiors: organizationalUnit
systemPossSuperiors: container
systemMayContain: msDS-AzGenericData
systemMayContain: msDS-AzObjectGuid
systemMayContain: msDS-AzMinorVersion
systemMayContain: msDS-AzMajorVersion
systemMayContain: msDS-AzApplicationData
systemMayContain: msDS-AzGenerateAudits
systemMayContain: msDS-AzScriptTimeout
systemMayContain: msDS-AzScriptEngineCacheMax
systemMayContain: msDS-AzDomainTimeout
systemMayContain: description
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Az-Admin-Manager,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Az-Application,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Az-Application
distinguishedName: 
 CN=ms-DS-Az-Application,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5375
subClassOf: top
governsID: 1.2.840.113556.1.5.235
rDNAttID: cn
uSNChanged: 5375
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-DS-Az-Application
adminDescription: 
 Defines an installed instance of an application bound to a particular policy s
 tore.
objectClassCategory: 1
lDAPDisplayName: msDS-AzApplication
name: ms-DS-Az-Application
objectGUID:: Zgac917Fk06syXmXstgmWw==
schemaIDGUID:: m9743aXLEk6ELijYtm917A==
systemOnly: FALSE
systemPossSuperiors: msDS-AzAdminManager
systemMayContain: msDS-AzGenericData
systemMayContain: msDS-AzObjectGuid
systemMayContain: msDS-AzApplicationData
systemMayContain: msDS-AzGenerateAudits
systemMayContain: msDS-AzApplicationVersion
systemMayContain: msDS-AzClassId
systemMayContain: msDS-AzApplicationName
systemMayContain: description
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Az-Application,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Az-Operation,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Az-Operation
distinguishedName: 
 CN=ms-DS-Az-Operation,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5377
subClassOf: top
governsID: 1.2.840.113556.1.5.236
rDNAttID: cn
uSNChanged: 5377
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-DS-Az-Operation
adminDescription: Describes a particular operation supported by an application
objectClassCategory: 1
lDAPDisplayName: msDS-AzOperation
name: ms-DS-Az-Operation
objectGUID:: TYwrmc8xQkOADdCcKpc00A==
schemaIDGUID:: N74KhpuapE+z0ris5d+exQ==
systemOnly: FALSE
systemPossSuperiors: container
systemPossSuperiors: msDS-AzApplication
systemMayContain: msDS-AzGenericData
systemMayContain: msDS-AzObjectGuid
systemMayContain: msDS-AzApplicationData
systemMayContain: description
systemMustContain: msDS-AzOperationID
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Az-Operation,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Az-Scope,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Az-Scope
distinguishedName: 
 CN=ms-DS-Az-Scope,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5379
subClassOf: top
governsID: 1.2.840.113556.1.5.237
rDNAttID: cn
uSNChanged: 5379
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-DS-Az-Scope
adminDescription: Describes a set of objects managed by an application
objectClassCategory: 1
lDAPDisplayName: msDS-AzScope
name: ms-DS-Az-Scope
objectGUID:: krjPEpbUak+fwkkD8O5iCA==
schemaIDGUID:: VODqT1XOu0eGDlsSBjpR3g==
systemOnly: FALSE
systemPossSuperiors: msDS-AzApplication
systemMayContain: msDS-AzGenericData
systemMayContain: msDS-AzObjectGuid
systemMayContain: msDS-AzApplicationData
systemMayContain: description
systemMustContain: msDS-AzScopeName
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Az-Scope,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Az-Task,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Az-Task
distinguishedName: 
 CN=ms-DS-Az-Task,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5381
subClassOf: top
governsID: 1.2.840.113556.1.5.238
rDNAttID: cn
uSNChanged: 5381
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-DS-Az-Task
adminDescription: Describes a set of operations
objectClassCategory: 1
lDAPDisplayName: msDS-AzTask
name: ms-DS-Az-Task
objectGUID:: SrxZtRLPCUiLnElNSFA8pw==
schemaIDGUID:: c6TTHhubikG/oDo3uVpTBg==
systemOnly: FALSE
systemPossSuperiors: container
systemPossSuperiors: msDS-AzScope
systemPossSuperiors: msDS-AzApplication
systemMayContain: msDS-AzGenericData
systemMayContain: msDS-AzObjectGuid
systemMayContain: msDS-TasksForAzTask
systemMayContain: msDS-OperationsForAzTask
systemMayContain: msDS-AzApplicationData
systemMayContain: msDS-AzTaskIsRoleDefinition
systemMayContain: msDS-AzLastImportedBizRulePath
systemMayContain: msDS-AzBizRuleLanguage
systemMayContain: msDS-AzBizRule
systemMayContain: description
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Az-Task,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Az-Role,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Az-Role
distinguishedName: 
 CN=ms-DS-Az-Role,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5383
subClassOf: top
governsID: 1.2.840.113556.1.5.239
rDNAttID: cn
uSNChanged: 5383
showInAdvancedViewOnly: TRUE
adminDisplayName: MS-DS-Az-Role
adminDescription: 
 Defines a set of operations that can be performed by a particular set of users
  within a particular scope
objectClassCategory: 1
lDAPDisplayName: msDS-AzRole
name: ms-DS-Az-Role
objectGUID:: 5hHx1+hglkurhkLvL5Syqg==
schemaIDGUID:: yeoTglWd3ESSXOmlK5J2RA==
systemOnly: FALSE
systemPossSuperiors: container
systemPossSuperiors: msDS-AzScope
systemPossSuperiors: msDS-AzApplication
systemMayContain: msDS-AzGenericData
systemMayContain: msDS-AzObjectGuid
systemMayContain: msDS-AzApplicationData
systemMayContain: msDS-TasksForAzRole
systemMayContain: msDS-OperationsForAzRole
systemMayContain: msDS-MembersForAzRole
systemMayContain: description
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Az-Role,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Sam-Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Sam-Server
distinguishedName: 
 CN=Sam-Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093706.0Z
uSNCreated: 5385
subClassOf: securityObject
governsID: 1.2.840.113556.1.5.5
rDNAttID: cn
uSNChanged: 5385
showInAdvancedViewOnly: TRUE
adminDisplayName: Sam-Server
adminDescription: Sam-Server
objectClassCategory: 1
lDAPDisplayName: samServer
name: Sam-Server
objectGUID:: zmzP0rJUhkCKBfBdwwDicA==
schemaIDGUID:: rXqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: domainDNS
systemMayContain: samDomainUpdates
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPLCLORC;;;RU)(OA;;CR;91d67418-0135-4acc-8d79-c08e857cfbec;;
 AU)(OA;;CR;91d67418-0135-4acc-8d79-c08e857cfbec;;RU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Sam-Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-LocalSettings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-LocalSettings
distinguishedName: 
 CN=ms-DFSR-LocalSettings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100101.0Z
whenChanged: 20080624093707.0Z
possSuperiors: computer
uSNCreated: 5431
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.1
mayContain: msDFSR-StagingCleanupTriggerInPercent
mayContain: msDFSR-CommonStagingSizeInMb
mayContain: msDFSR-CommonStagingPath
mayContain: msDFSR-Options2
mayContain: msDFSR-Version
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5431
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-LocalSettings
adminDescription: DFSR settings applicable to local computer
objectClassCategory: 1
lDAPDisplayName: msDFSR-LocalSettings
name: ms-DFSR-LocalSettings
objectGUID:: ZU/piyR5dEicoG1D4aQ/0w==
schemaIDGUID:: kcWF+n8ZfkeDvepaQ98iOQ==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-LocalSettings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-Subscriber,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-Subscriber
distinguishedName: 
 CN=ms-DFSR-Subscriber,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100106.0Z
whenChanged: 20080624093707.0Z
possSuperiors: msDFSR-LocalSettings
uSNCreated: 5433
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.2
mustContain: msDFSR-MemberReference
mustContain: msDFSR-ReplicationGroupGuid
mayContain: msDFSR-Options2
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5433
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-Subscriber
adminDescription: Represents local computer membership of a replication group
objectClassCategory: 1
lDAPDisplayName: msDFSR-Subscriber
name: ms-DFSR-Subscriber
objectGUID:: rHjqjtA4mUOiKiPV/x7+TQ==
schemaIDGUID:: 1wUV4cSS50O/XClYMv/Ilg==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-Subscriber,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-Subscription,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-Subscription
distinguishedName: 
 CN=ms-DFSR-Subscription,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100106.0Z
whenChanged: 20080624093707.0Z
possSuperiors: msDFSR-Subscriber
uSNCreated: 5435
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.3
mustContain: msDFSR-ContentSetGuid
mustContain: msDFSR-ReplicationGroupGuid
mayContain: msDFSR-StagingCleanupTriggerInPercent
mayContain: msDFSR-Options2
mayContain: msDFSR-OnDemandExclusionDirectoryFilter
mayContain: msDFSR-OnDemandExclusionFileFilter
mayContain: msDFSR-MaxAgeInCacheInMin
mayContain: msDFSR-MinDurationCacheInMin
mayContain: msDFSR-CachePolicy
mayContain: msDFSR-ReadOnly
mayContain: msDFSR-DeletedSizeInMb
mayContain: msDFSR-DeletedPath
mayContain: msDFSR-RootPath
mayContain: msDFSR-RootSizeInMb
mayContain: msDFSR-StagingPath
mayContain: msDFSR-StagingSizeInMb
mayContain: msDFSR-ConflictPath
mayContain: msDFSR-ConflictSizeInMb
mayContain: msDFSR-Enabled
mayContain: msDFSR-RootFence
mayContain: msDFSR-DfsLinkTarget
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5435
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-Subscription
adminDescription: Represents local computer participation of a content set
objectClassCategory: 1
lDAPDisplayName: msDFSR-Subscription
name: ms-DFSR-Subscription
objectGUID:: ORAcX1L3Wkq05U4T5t0vFQ==
schemaIDGUID:: FCQhZ8x7CUaH4AiNrYq97g==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-Subscription,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-GlobalSettings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-GlobalSettings
distinguishedName: 
 CN=ms-DFSR-GlobalSettings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100102.0Z
whenChanged: 20080624093707.0Z
possSuperiors: container
uSNCreated: 5437
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.4
mayContain: msDFSR-Options2
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5437
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-GlobalSettings
adminDescription: Global settings applicable to all replication group members
objectClassCategory: 1
lDAPDisplayName: msDFSR-GlobalSettings
name: ms-DFSR-GlobalSettings
objectGUID:: iMJ2GIRyZkKv1ga/rUNT1g==
schemaIDGUID:: rds1e+yzakiq1C/snW6m9g==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-GlobalSettings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-ReplicationGroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-ReplicationGroup
distinguishedName: 
 CN=ms-DFSR-ReplicationGroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100103.0Z
whenChanged: 20080624093707.0Z
possSuperiors: msDFSR-GlobalSettings
uSNCreated: 5439
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.5
mustContain: msDFSR-ReplicationGroupType
mayContain: msDFSR-Options2
mayContain: msDFSR-OnDemandExclusionDirectoryFilter
mayContain: msDFSR-OnDemandExclusionFileFilter
mayContain: msDFSR-DefaultCompressionExclusionFilter
mayContain: msDFSR-DeletedSizeInMb
mayContain: msDFSR-DirectoryFilter
mayContain: msDFSR-FileFilter
mayContain: msDFSR-ConflictSizeInMb
mayContain: msDFSR-StagingSizeInMb
mayContain: msDFSR-RootSizeInMb
mayContain: description
mayContain: msDFSR-TombstoneExpiryInMin
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
mayContain: msDFSR-Schedule
mayContain: msDFSR-Version
rDNAttID: cn
uSNChanged: 5439
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-ReplicationGroup
adminDescription: Replication Group container
objectClassCategory: 1
lDAPDisplayName: msDFSR-ReplicationGroup
name: ms-DFSR-ReplicationGroup
objectGUID:: h72NHtRgQ0Go44Df47C+MA==
schemaIDGUID:: 4C8zHCoMMk+vyiPF5Fqedw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-ReplicationGroup,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-Content,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-Content
distinguishedName: 
 CN=ms-DFSR-Content,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100104.0Z
whenChanged: 20080624093707.0Z
possSuperiors: msDFSR-ReplicationGroup
uSNCreated: 5441
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.6
mayContain: msDFSR-Options2
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5441
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-Content
adminDescription: Container for DFSR-ContentSet objects
objectClassCategory: 1
lDAPDisplayName: msDFSR-Content
name: ms-DFSR-Content
objectGUID:: IEOiMT7Yi0GQroFqkr18og==
schemaIDGUID:: NZt1ZKHT5EK18aPeFiEJsw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-Content,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-ContentSet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-ContentSet
distinguishedName: 
 CN=ms-DFSR-ContentSet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100106.0Z
whenChanged: 20080624093707.0Z
possSuperiors: msDFSR-Content
uSNCreated: 5443
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.7
mayContain: msDFSR-Options2
mayContain: msDFSR-OnDemandExclusionDirectoryFilter
mayContain: msDFSR-OnDemandExclusionFileFilter
mayContain: msDFSR-DefaultCompressionExclusionFilter
mayContain: msDFSR-DeletedSizeInMb
mayContain: msDFSR-Priority
mayContain: msDFSR-ConflictSizeInMb
mayContain: msDFSR-StagingSizeInMb
mayContain: msDFSR-RootSizeInMb
mayContain: description
mayContain: msDFSR-DfsPath
mayContain: msDFSR-FileFilter
mayContain: msDFSR-DirectoryFilter
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5443
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-ContentSet
adminDescription: DFSR Content Set
objectClassCategory: 1
lDAPDisplayName: msDFSR-ContentSet
name: ms-DFSR-ContentSet
objectGUID:: 3gfR/7tFmUazFNIQd+CH1Q==
schemaIDGUID:: DfQ3SdymSE2Xygbl+/0/Fg==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-ContentSet,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-Topology,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-Topology
distinguishedName: 
 CN=ms-DFSR-Topology,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100103.0Z
whenChanged: 20080624093707.0Z
possSuperiors: msDFSR-ReplicationGroup
uSNCreated: 5445
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.8
mayContain: msDFSR-Options2
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5445
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-Topology
adminDescription: Container for objects that form the replication topology
objectClassCategory: 1
lDAPDisplayName: msDFSR-Topology
name: ms-DFSR-Topology
objectGUID:: m/jnaUOn1kyU5Fjl6m8a8g==
schemaIDGUID:: qYqCBEJugE65YuL+AHVNFw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-Topology,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-Member,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-Member
distinguishedName: 
 CN=ms-DFSR-Member,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100105.0Z
whenChanged: 20080624093707.0Z
possSuperiors: msDFSR-Topology
uSNCreated: 5447
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.9
mustContain: msDFSR-ComputerReference
mayContain: msDFSR-Options2
mayContain: serverReference
mayContain: msDFSR-Keywords
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5447
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-Member
adminDescription: Replication group member
objectClassCategory: 1
lDAPDisplayName: msDFSR-Member
name: ms-DFSR-Member
objectGUID:: wH6Q8BsenEOIQbM/Ayi4PQ==
schemaIDGUID:: l8gpQhHCfEOlrtv3BbaW5Q==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-Member,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFSR-Connection,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFSR-Connection
distinguishedName: 
 CN=ms-DFSR-Connection,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100105.0Z
whenChanged: 20080624093707.0Z
possSuperiors: msDFSR-Member
uSNCreated: 5449
subClassOf: top
governsID: 1.2.840.113556.1.6.13.4.10
mustContain: fromServer
mayContain: msDFSR-Options2
mayContain: msDFSR-DisablePacketPrivacy
mayContain: msDFSR-Priority
mayContain: msDFSR-Enabled
mayContain: msDFSR-RdcEnabled
mayContain: msDFSR-RdcMinFileSizeInKb
mayContain: msDFSR-Keywords
mayContain: msDFSR-Schedule
mayContain: msDFSR-Flags
mayContain: msDFSR-Options
mayContain: msDFSR-Extension
rDNAttID: cn
uSNChanged: 5449
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFSR-Connection
adminDescription: Directional connection between two members
objectClassCategory: 1
lDAPDisplayName: msDFSR-Connection
name: ms-DFSR-Connection
objectGUID:: OSvappUDX0ef/esfWKgD3Q==
schemaIDGUID:: LpeP5bVk70aNi7vD4Yl+qw==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;RPLCLORC;;;AU)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;DA)(A;;RPWPCRLCLOCCDCRCWD
 WOSDDTSW;;;CO)(A;;RPWPCRLCLOCCDCRCWDWOSDDTSW;;;SY)
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFSR-Connection,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTDS-DSA-RO,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTDS-DSA-RO
distinguishedName: 
 CN=NTDS-DSA-RO,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100132.0Z
whenChanged: 20080624093707.0Z
uSNCreated: 5452
subClassOf: nTDSDSA
governsID: 1.2.840.113556.1.5.254
rDNAttID: cn
uSNChanged: 5452
showInAdvancedViewOnly: TRUE
adminDisplayName: NTDS-DSA-RO
adminDescription: 
 A subclass of Directory Service Agent which is distinguished by its reduced pr
 ivilege level.
objectClassCategory: 1
lDAPDisplayName: nTDSDSARO
name: NTDS-DSA-RO
objectGUID:: OrJf8Vfsb02dvwDUkMYdvQ==
schemaIDGUID:: wW7RhZEHyEuKs3CYBgL/jA==
systemOnly: TRUE
systemPossSuperiors: server
systemPossSuperiors: organization
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTDS-DSA-RO,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Organizational-Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Organizational-Person
distinguishedName: 
 CN=Organizational-Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093707.0Z
uSNCreated: 5453
subClassOf: person
governsID: 2.5.6.7
mayContain: msDS-HABSeniorityIndex
mayContain: msDS-PhoneticDisplayName
mayContain: msDS-PhoneticCompanyName
mayContain: msDS-PhoneticDepartment
mayContain: msDS-PhoneticLastName
mayContain: msDS-PhoneticFirstName
mayContain: houseIdentifier
mayContain: msExchHouseIdentifier
mayContain: homePostalAddress
rDNAttID: cn
uSNChanged: 5453
showInAdvancedViewOnly: TRUE
adminDisplayName: Organizational-Person
adminDescription: Organizational-Person
objectClassCategory: 0
lDAPDisplayName: organizationalPerson
name: Organizational-Person
objectGUID:: gX88SoKMEkCO7xkEUT2Knw==
schemaIDGUID:: pHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: organizationalUnit
systemPossSuperiors: organization
systemPossSuperiors: container
systemMayContain: x121Address
systemMayContain: comment
systemMayContain: title
systemMayContain: co
systemMayContain: primaryTelexNumber
systemMayContain: telexNumber
systemMayContain: teletexTerminalIdentifier
systemMayContain: street
systemMayContain: st
systemMayContain: registeredAddress
systemMayContain: preferredDeliveryMethod
systemMayContain: postalCode
systemMayContain: postalAddress
systemMayContain: postOfficeBox
systemMayContain: thumbnailPhoto
systemMayContain: physicalDeliveryOfficeName
systemMayContain: pager
systemMayContain: otherPager
systemMayContain: otherTelephone
systemMayContain: mobile
systemMayContain: otherMobile
systemMayContain: primaryInternationalISDNNumber
systemMayContain: ipPhone
systemMayContain: otherIpPhone
systemMayContain: otherHomePhone
systemMayContain: homePhone
systemMayContain: otherFacsimileTelephoneNumber
systemMayContain: personalTitle
systemMayContain: middleName
systemMayContain: otherMailbox
systemMayContain: ou
systemMayContain: o
systemMayContain: mhsORAddress
systemMayContain: msDS-AllowedToDelegateTo
systemMayContain: manager
systemMayContain: thumbnailLogo
systemMayContain: l
systemMayContain: internationalISDNNumber
systemMayContain: initials
systemMayContain: givenName
systemMayContain: generationQualifier
systemMayContain: facsimileTelephoneNumber
systemMayContain: employeeID
systemMayContain: mail
systemMayContain: division
systemMayContain: destinationIndicator
systemMayContain: department
systemMayContain: c
systemMayContain: countryCode
systemMayContain: company
systemMayContain: assistant
systemMayContain: streetAddress
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Mail-Aliases,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Mail-Aliases
distinguishedName: 
 CN=msSFU-30-Mail-Aliases,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115649.0Z
whenChanged: 20080624093707.0Z
possSuperiors: nisMap
possSuperiors: domainDNS
possSuperiors: container
uSNCreated: 5473
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.211
mayContain: msSFU30Aliases
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5473
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30MailAliases
adminDescription: msSFU30MailAliases
objectClassCategory: 1
lDAPDisplayName: msSFU30MailAliases
name: msSFU-30-Mail-Aliases
objectGUID:: BSv/f2u2MkyDU05Q0vSycQ==
schemaIDGUID:: bX2YLjJm1UuCdjY9CgCgMQ==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Mail-Aliases,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Net-Id,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Net-Id
distinguishedName: 
 CN=msSFU-30-Net-Id,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115645.0Z
whenChanged: 20080624093707.0Z
possSuperiors: nisMap
possSuperiors: domainDNS
possSuperiors: container
uSNCreated: 5475
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.212
mayContain: msSFU30KeyValues
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5475
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30NetId
adminDescription: msSFU30NetId
objectClassCategory: 1
lDAPDisplayName: msSFU30NetId
name: msSFU-30-Net-Id
objectGUID:: Bq5BQSmJfUq0NJ9tuxJnTA==
schemaIDGUID:: 9ovb20PQrEaYBhOK6+iaHw==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Net-Id,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=msSFU-30-Network-User,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: msSFU-30-Network-User
distinguishedName: 
 CN=msSFU-30-Network-User,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20050826115642.0Z
whenChanged: 20080624093707.0Z
possSuperiors: nisMap
possSuperiors: domainDNS
possSuperiors: container
uSNCreated: 5477
subClassOf: msSFU30Top
governsID: 1.2.840.113556.1.6.18.2.216
mayContain: msSFU30KeyValues
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5477
showInAdvancedViewOnly: FALSE
adminDisplayName: msSFU30NetworkUser
adminDescription: msSFU30NetworkUser
objectClassCategory: 1
lDAPDisplayName: msSFU30NetworkUser
name: msSFU-30-Network-User
objectGUID:: D0uZMVt9B0GUCm7P0N1RbQ==
schemaIDGUID:: JAmX5XDaTUqcR1Gxl4vQIA==
systemOnly: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=msSFU-30-Network-User,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Password-Settings-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Password-Settings-Container
distinguishedName: 
 CN=ms-DS-Password-Settings-Container,CN=Schema,CN=Configuration,DC=iii,DC=hoge
 nt,DC=be
instanceType: 4
whenCreated: 20080618100217.0Z
whenChanged: 20080624093707.0Z
uSNCreated: 5479
subClassOf: top
governsID: 1.2.840.113556.1.5.256
rDNAttID: cn
uSNChanged: 5479
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DS-Password-Settings-Container
adminDescription: Container for password settings objects
objectClassCategory: 1
lDAPDisplayName: msDS-PasswordSettingsContainer
name: ms-DS-Password-Settings-Container
objectGUID:: AClFIYUvxkycaku/tk0mwA==
schemaIDGUID:: arAGW/NMwES9FkO8EKmH2g==
systemOnly: FALSE
systemPossSuperiors: container
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
systemFlags: 16
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Password-Settings-Container,CN=Schema,CN=Configuration,DC=iii,DC=hoge
 nt,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DS-Password-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DS-Password-Settings
distinguishedName: 
 CN=ms-DS-Password-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100217.0Z
whenChanged: 20080624093707.0Z
uSNCreated: 5481
subClassOf: top
governsID: 1.2.840.113556.1.5.255
rDNAttID: cn
uSNChanged: 5481
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DS-Password-Settings
adminDescription: Password settings object for accounts
objectClassCategory: 1
lDAPDisplayName: msDS-PasswordSettings
name: ms-DS-Password-Settings
objectGUID:: EZgkOpOAQ0y3ByZbuFRoog==
schemaIDGUID:: uJ3NO0v4HEWVL2xSuB+exg==
systemOnly: FALSE
systemPossSuperiors: msDS-PasswordSettingsContainer
systemMayContain: msDS-PSOAppliesTo
systemMustContain: msDS-PasswordHistoryLength
systemMustContain: msDS-MaximumPasswordAge
systemMustContain: msDS-MinimumPasswordAge
systemMustContain: msDS-MinimumPasswordLength
systemMustContain: msDS-PasswordComplexityEnabled
systemMustContain: msDS-LockoutObservationWindow
systemMustContain: msDS-LockoutDuration
systemMustContain: msDS-LockoutThreshold
systemMustContain: msDS-PasswordReversibleEncryptionEnabled
systemMustContain: msDS-PasswordSettingsPrecedence
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
systemFlags: 16
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DS-Password-Settings,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-FVE-RecoveryInformation,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-FVE-RecoveryInformation
distinguishedName: 
 CN=ms-FVE-RecoveryInformation,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=b
 e
instanceType: 4
whenCreated: 20080618100132.0Z
whenChanged: 20080624093707.0Z
uSNCreated: 5483
subClassOf: top
governsID: 1.2.840.113556.1.5.253
mayContain: msFVE-KeyPackage
mayContain: msFVE-VolumeGuid
rDNAttID: cn
uSNChanged: 5483
showInAdvancedViewOnly: TRUE
adminDisplayName: FVE-RecoveryInformation
adminDescription: 
 This class contains BitLocker recovery information including GUIDs, recovery p
 asswords, and keys. Full Volume Encryption (FVE) was the pre-release name for 
 BitLocker Drive Encryption.
objectClassCategory: 1
lDAPDisplayName: msFVE-RecoveryInformation
name: ms-FVE-RecoveryInformation
objectGUID:: PDlhlB2imkWPBPH1rkkosA==
schemaIDGUID:: MF1x6lOP0EC9HmEJGG14LA==
systemOnly: FALSE
systemPossSuperiors: computer
systemMustContain: msFVE-RecoveryPassword
systemMustContain: msFVE-RecoveryGuid
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-FVE-RecoveryInformation,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=b
 e
dSCorePropagationData: 16010101000000.0Z

dn: CN=Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Server
distinguishedName: CN=Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093707.0Z
uSNCreated: 5485
subClassOf: top
governsID: 1.2.840.113556.1.5.17
rDNAttID: cn
uSNChanged: 5485
showInAdvancedViewOnly: TRUE
adminDisplayName: Server
adminDescription: Server
objectClassCategory: 1
lDAPDisplayName: server
name: Server
objectGUID:: lH49e0CvMk+Pgo1ZCtLo6g==
schemaIDGUID:: knqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: serversContainer
systemMayContain: msDS-IsUserCachableAtRodc
systemMayContain: msDS-SiteName
systemMayContain: msDS-isRODC
systemMayContain: msDS-isGC
systemMayContain: mailAddress
systemMayContain: serverReference
systemMayContain: serialNumber
systemMayContain: managedBy
systemMayContain: dNSHostName
systemMayContain: bridgeheadTransportList
defaultSecurityDescriptor: 
 D:(A;CI;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A
 ;;RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Server,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Computer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Computer
distinguishedName: 
 CN=Computer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015022.0Z
whenChanged: 20080624093707.0Z
uSNCreated: 5487
subClassOf: user
governsID: 1.2.840.113556.1.3.30
mayContain: msSFU30Aliases
mayContain: msSFU30NisDomain
mayContain: nisMapName
mayContain: msSFU30Name
rDNAttID: cn
uSNChanged: 5487
showInAdvancedViewOnly: TRUE
adminDisplayName: Computer
adminDescription: Computer
auxiliaryClass: ipHost
auxiliaryClass: msSFU30IpHost
objectClassCategory: 1
lDAPDisplayName: computer
name: Computer
objectGUID:: P7KnNGZ/qE2ItcEOR9H7DA==
schemaIDGUID:: hnqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: container
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemMayContain: msDS-IsUserCachableAtRodc
systemMayContain: msTSProperty02
systemMayContain: msTSProperty01
systemMayContain: msTPM-OwnerInformation
systemMayContain: msDS-RevealOnDemandGroup
systemMayContain: msDS-NeverRevealGroup
systemMayContain: msDS-PromotionSettings
systemMayContain: msDS-SiteName
systemMayContain: msDS-isRODC
systemMayContain: msDS-isGC
systemMayContain: msDS-AuthenticatedAtDC
systemMayContain: msDS-RevealedList
systemMayContain: msDS-RevealedUsers
systemMayContain: msDS-ExecuteScriptPassword
systemMayContain: msDS-KrbTgtLink
systemMayContain: volumeCount
systemMayContain: siteGUID
systemMayContain: rIDSetReferences
systemMayContain: policyReplicationFlags
systemMayContain: physicalLocationObject
systemMayContain: operatingSystemVersion
systemMayContain: operatingSystemServicePack
systemMayContain: operatingSystemHotfix
systemMayContain: operatingSystem
systemMayContain: networkAddress
systemMayContain: netbootSIFFile
systemMayContain: netbootMirrorDataFile
systemMayContain: netbootMachineFilePath
systemMayContain: netbootInitialization
systemMayContain: netbootGUID
systemMayContain: msDS-AdditionalSamAccountName
systemMayContain: msDS-AdditionalDnsHostName
systemMayContain: managedBy
systemMayContain: machineRole
systemMayContain: location
systemMayContain: localPolicyFlags
systemMayContain: dNSHostName
systemMayContain: defaultLocalPolicyObject
systemMayContain: cn
systemMayContain: catalogs
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;AO)(A;;
 RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;RPCRLCLORCSDDT;;;CO)(OA;;WP;4c164200-20c0-
 11d0-a768-00aa006e0529;;CO)(A;;RPLCLORC;;;AU)(OA;;CR;ab721a53-1e2f-11d0-9819-0
 0aa0040529b;;WD)(A;;CCDC;;;PS)(OA;;CCDC;bf967aa8-0de6-11d0-a285-00aa003049e2;;
 PO)(OA;;RPWP;bf967a7f-0de6-11d0-a285-00aa003049e2;;CA)(OA;;SW;f3a64788-5306-11
 d1-a9c5-0000f80367c1;;PS)(OA;;RPWP;77B5B886-944A-11d1-AEBD-0000F80367C1;;PS)(O
 A;;SW;72e39547-7b18-11d1-adef-00c04fd8d5cd;;PS)(OA;;SW;72e39547-7b18-11d1-adef
 -00c04fd8d5cd;;CO)(OA;;SW;f3a64788-5306-11d1-a9c5-0000f80367c1;;CO)(OA;;WP;3e0
 abfd0-126a-11d0-a060-00aa006c33ed;bf967a86-0de6-11d0-a285-00aa003049e2;CO)(OA;
 ;WP;5f202010-79a5-11d0-9020-00c04fc2d4cf;bf967a86-0de6-11d0-a285-00aa003049e2;
 CO)(OA;;WP;bf967950-0de6-11d0-a285-00aa003049e2;bf967a86-0de6-11d0-a285-00aa00
 3049e2;CO)(OA;;WP;bf967953-0de6-11d0-a285-00aa003049e2;bf967a86-0de6-11d0-a285
 -00aa003049e2;CO)(OA;;RP;46a9b11d-60ae-405a-b7e8-ff8a58d456d2;;S-1-5-32-560)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Computer,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTDS-DSA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTDS-DSA
distinguishedName: 
 CN=NTDS-DSA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093707.0Z
uSNCreated: 5489
subClassOf: applicationSettings
governsID: 1.2.840.113556.1.5.7000.47
rDNAttID: cn
uSNChanged: 5489
showInAdvancedViewOnly: TRUE
adminDisplayName: NTDS-DSA
adminDescription: NTDS-DSA
objectClassCategory: 1
lDAPDisplayName: nTDSDSA
name: NTDS-DSA
objectGUID:: 8K0rQxP38UKDyIHrmYh7HA==
schemaIDGUID:: q//48JER0BGgYACqAGwz7Q==
systemOnly: TRUE
systemPossSuperiors: organization
systemPossSuperiors: server
systemMayContain: msDS-SiteName
systemMayContain: msDS-isRODC
systemMayContain: msDS-isGC
systemMayContain: msDS-IsUserCachableAtRodc
systemMayContain: msDS-RevealedUsers
systemMayContain: msDS-NeverRevealGroup
systemMayContain: msDS-RevealOnDemandGroup
systemMayContain: msDS-hasFullReplicaNCs
systemMayContain: serverReference
systemMayContain: msDS-RetiredReplNCSignatures
systemMayContain: retiredReplDSASignatures
systemMayContain: queryPolicyObject
systemMayContain: options
systemMayContain: networkAddress
systemMayContain: msDS-ReplicationEpoch
systemMayContain: msDS-HasInstantiatedNCs
systemMayContain: msDS-hasMasterNCs
systemMayContain: msDS-HasDomainNCs
systemMayContain: msDS-Behavior-Version
systemMayContain: managedBy
systemMayContain: lastBackupRestorationTime
systemMayContain: invocationId
systemMayContain: hasPartialReplicaNCs
systemMayContain: hasMasterNCs
systemMayContain: fRSRootPath
systemMayContain: dMDLocation
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTDS-DSA,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFS-Namespace-Anchor,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFS-Namespace-Anchor
distinguishedName: 
 CN=ms-DFS-Namespace-Anchor,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100408.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5858
subClassOf: top
governsID: 1.2.840.113556.1.5.257
rDNAttID: cn
uSNChanged: 5858
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFS-Namespace-Anchor
adminDescription: DFS namespace anchor
objectClassCategory: 1
lDAPDisplayName: msDFS-NamespaceAnchor
name: ms-DFS-Namespace-Anchor
objectGUID:: Y6F/bJQbbUuPkkzKeYr+tg==
schemaIDGUID:: haBz2mRuYU2wZAFdBBZHlQ==
systemOnly: FALSE
systemPossSuperiors: dfsConfiguration
systemMustContain: msDFS-SchemaMajorVersion
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;CO)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFS-Namespace-Anchor,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFS-Namespace-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFS-Namespace-v2
distinguishedName: 
 CN=ms-DFS-Namespace-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100408.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5860
subClassOf: top
governsID: 1.2.840.113556.1.5.258
rDNAttID: cn
uSNChanged: 5860
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFS-Namespace-v2
adminDescription: DFS namespace
objectClassCategory: 1
lDAPDisplayName: msDFS-Namespacev2
name: ms-DFS-Namespace-v2
objectGUID:: grJLM+Ebu0inxB6Hzw65lg==
schemaIDGUID:: KIbLIcPzv0u/9gYLLY8pmg==
systemOnly: FALSE
systemPossSuperiors: msDFS-NamespaceAnchor
systemMayContain: msDFS-Commentv2
systemMustContain: msDFS-SchemaMajorVersion
systemMustContain: msDFS-SchemaMinorVersion
systemMustContain: msDFS-GenerationGUIDv2
systemMustContain: msDFS-NamespaceIdentityGUIDv2
systemMustContain: msDFS-LastModifiedv2
systemMustContain: msDFS-Ttlv2
systemMustContain: msDFS-TargetListv2
systemMustContain: msDFS-Propertiesv2
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFS-Namespace-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFS-Link-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFS-Link-v2
distinguishedName: 
 CN=ms-DFS-Link-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100409.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5862
subClassOf: top
governsID: 1.2.840.113556.1.5.259
rDNAttID: cn
uSNChanged: 5862
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFS-Link-v2
adminDescription: DFS Link in DFS namespace
objectClassCategory: 1
lDAPDisplayName: msDFS-Linkv2
name: ms-DFS-Link-v2
objectGUID:: BEayUimXv0uIw4u5mfebGw==
schemaIDGUID:: evtpd1kRlk6czWi8SHBz6w==
systemOnly: FALSE
systemPossSuperiors: msDFS-Namespacev2
systemMayContain: msDFS-Commentv2
systemMayContain: msDFS-LinkSecurityDescriptorv2
systemMayContain: msDFS-ShortNameLinkPathv2
systemMustContain: msDFS-GenerationGUIDv2
systemMustContain: msDFS-NamespaceIdentityGUIDv2
systemMustContain: msDFS-LinkIdentityGUIDv2
systemMustContain: msDFS-LastModifiedv2
systemMustContain: msDFS-Ttlv2
systemMustContain: msDFS-TargetListv2
systemMustContain: msDFS-Propertiesv2
systemMustContain: msDFS-LinkPathv2
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFS-Link-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-DFS-Deleted-Link-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-DFS-Deleted-Link-v2
distinguishedName: 
 CN=ms-DFS-Deleted-Link-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20080618100409.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5864
subClassOf: top
governsID: 1.2.840.113556.1.5.260
rDNAttID: cn
uSNChanged: 5864
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-DFS-Deleted-Link-v2
adminDescription: Deleted DFS Link in DFS namespace
objectClassCategory: 1
lDAPDisplayName: msDFS-DeletedLinkv2
name: ms-DFS-Deleted-Link-v2
objectGUID:: XvlfwiEcP0GP47V9lB1N1w==
schemaIDGUID:: CDQXJcoE6ECGXj+c6b8b0w==
systemOnly: FALSE
systemPossSuperiors: msDFS-Namespacev2
systemMayContain: msDFS-Commentv2
systemMayContain: msDFS-ShortNameLinkPathv2
systemMustContain: msDFS-NamespaceIdentityGUIDv2
systemMustContain: msDFS-LinkIdentityGUIDv2
systemMustContain: msDFS-LastModifiedv2
systemMustContain: msDFS-LinkPathv2
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-DFS-Deleted-Link-v2,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=ms-Exch-Configuration-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: ms-Exch-Configuration-Container
distinguishedName: 
 CN=ms-Exch-Configuration-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent
 ,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5868
subClassOf: container
governsID: 1.2.840.113556.1.5.176
rDNAttID: cn
uSNChanged: 5868
showInAdvancedViewOnly: TRUE
adminDisplayName: ms-Exch-Configuration-Container
adminDescription: ms-Exch-Configuration-Container
objectClassCategory: 1
lDAPDisplayName: msExchConfigurationContainer
name: ms-Exch-Configuration-Container
objectGUID:: cqfPmzRTF06nQ74pm39cxg==
schemaIDGUID:: WGg90PQG0hGqUwDAT9fYOg==
systemOnly: FALSE
systemMayContain: templateRoots2
systemMayContain: globalAddressList2
systemMayContain: addressBookRoots2
systemMayContain: templateRoots
systemMayContain: addressBookRoots
systemMayContain: globalAddressList
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=ms-Exch-Configuration-Container,CN=Schema,CN=Configuration,DC=iii,DC=hogent
 ,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Top,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Top
distinguishedName: CN=Top,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5870
governsID: 2.5.6.0
mayContain: msSFU30PosixMemberOf
mayContain: msDFSR-ComputerReferenceBL
mayContain: msDFSR-MemberReferenceBL
mayContain: msDS-ObjectReferenceBL
rDNAttID: cn
uSNChanged: 5870
showInAdvancedViewOnly: TRUE
adminDisplayName: Top
adminDescription: Top
objectClassCategory: 2
lDAPDisplayName: top
name: Top
objectGUID:: W0AAAxAro0iSXswdQiq6eQ==
schemaIDGUID:: t3qWv+YN0BGihQCqADBJ4g==
systemOnly: TRUE
systemPossSuperiors: lostAndFound
systemMayContain: msDS-NC-RO-Replica-Locations-BL
systemMayContain: msDS-NcType
systemMayContain: msDS-PSOApplied
systemMayContain: msDS-PrincipalName
systemMayContain: msDS-RevealedListBL
systemMayContain: msDS-AuthenticatedToAccountlist
systemMayContain: msDS-IsPartialReplicaFor
systemMayContain: msDS-IsDomainFor
systemMayContain: msDS-IsFullReplicaFor
systemMayContain: msDS-RevealedDSAs
systemMayContain: msDS-KrbTgtLinkBl
systemMayContain: url
systemMayContain: wWWHomePage
systemMayContain: whenCreated
systemMayContain: whenChanged
systemMayContain: wellKnownObjects
systemMayContain: wbemPath
systemMayContain: uSNSource
systemMayContain: uSNLastObjRem
systemMayContain: USNIntersite
systemMayContain: uSNDSALastObjRemoved
systemMayContain: uSNCreated
systemMayContain: uSNChanged
systemMayContain: systemFlags
systemMayContain: subSchemaSubEntry
systemMayContain: subRefs
systemMayContain: structuralObjectClass
systemMayContain: siteObjectBL
systemMayContain: serverReferenceBL
systemMayContain: sDRightsEffective
systemMayContain: revision
systemMayContain: repsTo
systemMayContain: repsFrom
systemMayContain: directReports
systemMayContain: replUpToDateVector
systemMayContain: replPropertyMetaData
systemMayContain: name
systemMayContain: queryPolicyBL
systemMayContain: proxyAddresses
systemMayContain: proxiedObjectName
systemMayContain: possibleInferiors
systemMayContain: partialAttributeSet
systemMayContain: partialAttributeDeletionList
systemMayContain: otherWellKnownObjects
systemMayContain: objectVersion
systemMayContain: objectGUID
systemMayContain: distinguishedName
systemMayContain: nonSecurityMemberBL
systemMayContain: netbootSCPBL
systemMayContain: ownerBL
systemMayContain: msDS-ReplValueMetaData
systemMayContain: msDS-ReplAttributeMetaData
systemMayContain: msDS-NonMembersBL
systemMayContain: msDS-NCReplOutboundNeighbors
systemMayContain: msDS-NCReplInboundNeighbors
systemMayContain: msDS-NCReplCursors
systemMayContain: msDS-TasksForAzRoleBL
systemMayContain: msDS-TasksForAzTaskBL
systemMayContain: msDS-OperationsForAzRoleBL
systemMayContain: msDS-OperationsForAzTaskBL
systemMayContain: msDS-MembersForAzRoleBL
systemMayContain: msDs-masteredBy
systemMayContain: mS-DS-ConsistencyGuid
systemMayContain: mS-DS-ConsistencyChildCount
systemMayContain: msDS-Approx-Immed-Subordinates
systemMayContain: msCOM-PartitionSetLink
systemMayContain: msCOM-UserLink
systemMayContain: modifyTimeStamp
systemMayContain: masteredBy
systemMayContain: managedObjects
systemMayContain: lastKnownParent
systemMayContain: isPrivilegeHolder
systemMayContain: memberOf
systemMayContain: isDeleted
systemMayContain: isCriticalSystemObject
systemMayContain: showInAdvancedViewOnly
systemMayContain: fSMORoleOwner
systemMayContain: fRSMemberReferenceBL
systemMayContain: frsComputerReferenceBL
systemMayContain: fromEntry
systemMayContain: flags
systemMayContain: extensionName
systemMayContain: dSASignature
systemMayContain: dSCorePropagationData
systemMayContain: displayNamePrintable
systemMayContain: displayName
systemMayContain: description
systemMayContain: createTimeStamp
systemMayContain: cn
systemMayContain: canonicalName
systemMayContain: bridgeheadServerListBL
systemMayContain: allowedChildClassesEffective
systemMayContain: allowedChildClasses
systemMayContain: allowedAttributesEffective
systemMayContain: allowedAttributes
systemMayContain: adminDisplayName
systemMayContain: adminDescription
systemMustContain: objectClass
systemMustContain: objectCategory
systemMustContain: nTSecurityDescriptor
systemMustContain: instanceType
defaultSecurityDescriptor: 
 D:(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;DA)(A;;RPWPCRCCDCLCLORCWOWDSDDTSW;;;SY)(A;;
 RPLCLORC;;;AU)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Top,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=NTFRS-Replica-Set,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: NTFRS-Replica-Set
distinguishedName: 
 CN=NTFRS-Replica-Set,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5887
subClassOf: top
governsID: 1.2.840.113556.1.5.102
rDNAttID: cn
uSNChanged: 5887
showInAdvancedViewOnly: TRUE
adminDisplayName: NTFRS-Replica-Set
adminDescription: NTFRS-Replica-Set
objectClassCategory: 1
lDAPDisplayName: nTFRSReplicaSet
name: NTFRS-Replica-Set
objectGUID:: J6SgInnGM0ezQAxeN+wu0Q==
schemaIDGUID:: OoBFUmrK0BGv/wAA+ANnwQ==
systemOnly: FALSE
systemPossSuperiors: nTFRSSettings
systemMayContain: schedule
systemMayContain: msFRS-Topology-Pref
systemMayContain: msFRS-Hub-Member
systemMayContain: managedBy
systemMayContain: fRSVersionGUID
systemMayContain: fRSServiceCommand
systemMayContain: fRSRootSecurity
systemMayContain: fRSReplicaSetType
systemMayContain: fRSReplicaSetGUID
systemMayContain: fRSPrimaryMember
systemMayContain: fRSPartnerAuthLevel
systemMayContain: fRSLevelLimit
systemMayContain: fRSFlags
systemMayContain: fRSFileFilter
systemMayContain: fRSExtensions
systemMayContain: fRSDSPoll
systemMayContain: fRSDirectoryFilter
defaultSecurityDescriptor: 
 D:(A;;LCRPLORC;;;AU)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;DA)(A;;CCDCLCSWRPWPDTLOCR
 SDRCWDWO;;;CO)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(OA;;CCDC;2a132586-9373-11d1
 -aebc-0000f80367c1;;ED)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=NTFRS-Replica-Set,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=User,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: User
distinguishedName: CN=User,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5888
subClassOf: organizationalPerson
governsID: 1.2.840.113556.1.5.9
mayContain: msSFU30NisDomain
mayContain: msSFU30Name
mayContain: msDS-SourceObjectDN
mayContain: x500uniqueIdentifier
mayContain: userSMIMECertificate
mayContain: userPKCS12
mayContain: uid
mayContain: secretary
mayContain: roomNumber
mayContain: preferredLanguage
mayContain: photo
mayContain: labeledURI
mayContain: jpegPhoto
mayContain: homePostalAddress
mayContain: givenName
mayContain: employeeType
mayContain: employeeNumber
mayContain: displayName
mayContain: departmentNumber
mayContain: carLicense
mayContain: audio
rDNAttID: cn
uSNChanged: 5888
showInAdvancedViewOnly: TRUE
adminDisplayName: User
adminDescription: User
auxiliaryClass: shadowAccount
auxiliaryClass: posixAccount
auxiliaryClass: msSFU30ShadowAccount
auxiliaryClass: msSFU30PosixAccount
objectClassCategory: 1
lDAPDisplayName: user
name: User
objectGUID:: MBFfLdAeJkKq+EHZm9HXHg==
schemaIDGUID:: unqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: builtinDomain
systemPossSuperiors: organizationalUnit
systemPossSuperiors: domainDNS
systemMayContain: msDS-ResultantPSO
systemMayContain: msTSLSProperty02
systemMayContain: msTSLSProperty01
systemMayContain: msTSManagingLS4
systemMayContain: msTSLicenseVersion4
systemMayContain: msTSExpireDate4
systemMayContain: msTSManagingLS3
systemMayContain: msTSLicenseVersion3
systemMayContain: msTSExpireDate3
systemMayContain: msTSManagingLS2
systemMayContain: msTSLicenseVersion2
systemMayContain: msTSExpireDate2
systemMayContain: msDS-AuthenticatedAtDC
systemMayContain: msDS-UserPasswordExpiryTimeComputed
systemMayContain: msTSManagingLS
systemMayContain: msTSLicenseVersion
systemMayContain: msTSExpireDate
systemMayContain: msTSProperty02
systemMayContain: msTSProperty01
systemMayContain: msTSInitialProgram
systemMayContain: msTSWorkDirectory
systemMayContain: msTSDefaultToMainPrinter
systemMayContain: msTSConnectPrinterDrives
systemMayContain: msTSConnectClientDrives
systemMayContain: msTSBrokenConnectionAction
systemMayContain: msTSReconnectionAction
systemMayContain: msTSMaxIdleTime
systemMayContain: msTSMaxConnectionTime
systemMayContain: msTSMaxDisconnectionTime
systemMayContain: msTSRemoteControl
systemMayContain: msTSAllowLogon
systemMayContain: msTSHomeDrive
systemMayContain: msTSHomeDirectory
systemMayContain: msTSProfilePath
systemMayContain: msDS-FailedInteractiveLogonCountAtLastSuccessfulLogon
systemMayContain: msDS-FailedInteractiveLogonCount
systemMayContain: msDS-LastFailedInteractiveLogonTime
systemMayContain: msDS-LastSuccessfulInteractiveLogonTime
systemMayContain: msRADIUS-SavedFramedIpv6Route
systemMayContain: msRADIUS-FramedIpv6Route
systemMayContain: msRADIUS-SavedFramedIpv6Prefix
systemMayContain: msRADIUS-FramedIpv6Prefix
systemMayContain: msRADIUS-SavedFramedInterfaceId
systemMayContain: msRADIUS-FramedInterfaceId
systemMayContain: msPKIAccountCredentials
systemMayContain: msPKIDPAPIMasterKeys
systemMayContain: msPKIRoamingTimeStamp
systemMayContain: msDS-SupportedEncryptionTypes
systemMayContain: msDS-SecondaryKrbTgtNumber
systemMayContain: pager
systemMayContain: o
systemMayContain: mobile
systemMayContain: manager
systemMayContain: mail
systemMayContain: initials
systemMayContain: homePhone
systemMayContain: businessCategory
systemMayContain: userCertificate
systemMayContain: userWorkstations
systemMayContain: userSharedFolderOther
systemMayContain: userSharedFolder
systemMayContain: userPrincipalName
systemMayContain: userParameters
systemMayContain: userAccountControl
systemMayContain: unicodePwd
systemMayContain: terminalServer
systemMayContain: servicePrincipalName
systemMayContain: scriptPath
systemMayContain: pwdLastSet
systemMayContain: profilePath
systemMayContain: primaryGroupID
systemMayContain: preferredOU
systemMayContain: otherLoginWorkstations
systemMayContain: operatorCount
systemMayContain: ntPwdHistory
systemMayContain: networkAddress
systemMayContain: msRASSavedFramedRoute
systemMayContain: msRASSavedFramedIPAddress
systemMayContain: msRASSavedCallbackNumber
systemMayContain: msRADIUSServiceType
systemMayContain: msRADIUSFramedRoute
systemMayContain: msRADIUSFramedIPAddress
systemMayContain: msRADIUSCallbackNumber
systemMayContain: msNPSavedCallingStationID
systemMayContain: msNPCallingStationID
systemMayContain: msNPAllowDialin
systemMayContain: mSMQSignCertificatesMig
systemMayContain: mSMQSignCertificates
systemMayContain: mSMQDigestsMig
systemMayContain: mSMQDigests
systemMayContain: msIIS-FTPRoot
systemMayContain: msIIS-FTPDir
systemMayContain: msDS-User-Account-Control-Computed
systemMayContain: msDS-Site-Affinity
systemMayContain: mS-DS-CreatorSID
systemMayContain: msDS-Cached-Membership-Time-Stamp
systemMayContain: msDS-Cached-Membership
systemMayContain: msDRM-IdentityCertificate
systemMayContain: msCOM-UserPartitionSetLink
systemMayContain: maxStorage
systemMayContain: logonWorkstation
systemMayContain: logonHours
systemMayContain: logonCount
systemMayContain: lockoutTime
systemMayContain: localeID
systemMayContain: lmPwdHistory
systemMayContain: lastLogonTimestamp
systemMayContain: lastLogon
systemMayContain: lastLogoff
systemMayContain: homeDrive
systemMayContain: homeDirectory
systemMayContain: groupsToIgnore
systemMayContain: groupPriority
systemMayContain: groupMembershipSAM
systemMayContain: dynamicLDAPServer
systemMayContain: desktopProfile
systemMayContain: defaultClassStore
systemMayContain: dBCSPwd
systemMayContain: controlAccessRights
systemMayContain: codePage
systemMayContain: badPwdCount
systemMayContain: badPasswordTime
systemMayContain: adminCount
systemMayContain: aCSPolicyName
systemMayContain: accountExpires
systemAuxiliaryClass: securityPrincipal
systemAuxiliaryClass: mailRecipient
defaultSecurityDescriptor: 
 D:(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;DA)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;
 CCDCLCSWRPWPDTLOCRSDRCWDWO;;;AO)(A;;LCRPLORC;;;PS)(OA;;CR;ab721a53-1e2f-11d0-9
 819-00aa0040529b;;PS)(OA;;CR;ab721a54-1e2f-11d0-9819-00aa0040529b;;PS)(OA;;CR;
 ab721a56-1e2f-11d0-9819-00aa0040529b;;PS)(OA;;RPWP;77b5b886-944a-11d1-aebd-000
 0f80367c1;;PS)(OA;;RPWP;e45795b2-9455-11d1-aebd-0000f80367c1;;PS)(OA;;RPWP;e45
 795b3-9455-11d1-aebd-0000f80367c1;;PS)(OA;;RP;037088f8-0ae1-11d2-b422-00a0c968
 f939;;RS)(OA;;RP;4c164200-20c0-11d0-a768-00aa006e0529;;RS)(OA;;RP;bc0ac240-79a
 9-11d0-9020-00c04fc2d4cf;;RS)(A;;RC;;;AU)(OA;;RP;59ba2f42-79a2-11d0-9020-00c04
 fc2d3cf;;AU)(OA;;RP;77b5b886-944a-11d1-aebd-0000f80367c1;;AU)(OA;;RP;e45795b3-
 9455-11d1-aebd-0000f80367c1;;AU)(OA;;RP;e48d0154-bcf8-11d1-8702-00c04fb96050;;
 AU)(OA;;CR;ab721a53-1e2f-11d0-9819-00aa0040529b;;WD)(OA;;RP;5f202010-79a5-11d0
 -9020-00c04fc2d4cf;;RS)(OA;;RPWP;bf967a7f-0de6-11d0-a285-00aa003049e2;;CA)(OA;
 ;RP;46a9b11d-60ae-405a-b7e8-ff8a58d456d2;;S-1-5-32-560)(OA;;RPWP;6db69a1c-9422
 -11d1-aebd-0000f80367c1;;S-1-5-32-561)(OA;;RPWP;5805bc62-bdc9-4428-a5e2-856a0f
 4c185e;;S-1-5-32-561)
systemFlags: 16
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=inetOrgPerson,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: inetOrgPerson
distinguishedName: 
 CN=inetOrgPerson,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015023.0Z
whenChanged: 20080624093708.0Z
possSuperiors: domainDNS
possSuperiors: organizationalUnit
possSuperiors: container
uSNCreated: 5889
subClassOf: user
governsID: 2.16.840.1.113730.3.2.2
mayContain: x500uniqueIdentifier
mayContain: userSMIMECertificate
mayContain: userPKCS12
mayContain: userCertificate
mayContain: uid
mayContain: secretary
mayContain: roomNumber
mayContain: preferredLanguage
mayContain: photo
mayContain: pager
mayContain: o
mayContain: mobile
mayContain: manager
mayContain: mail
mayContain: labeledURI
mayContain: jpegPhoto
mayContain: initials
mayContain: homePostalAddress
mayContain: homePhone
mayContain: givenName
mayContain: employeeType
mayContain: employeeNumber
mayContain: displayName
mayContain: departmentNumber
mayContain: carLicense
mayContain: businessCategory
mayContain: audio
rDNAttID: cn
uSNChanged: 5889
showInAdvancedViewOnly: FALSE
adminDisplayName: inetOrgPerson
adminDescription: 
 Represents people who are associated with an organization in some way.
objectClassCategory: 1
lDAPDisplayName: inetOrgPerson
name: inetOrgPerson
objectGUID:: 9Sv2zIh3/ESDr767zeZE/A==
schemaIDGUID:: FMwoSDcUvEWbB61vAV5fKA==
systemOnly: FALSE
defaultSecurityDescriptor: 
 D:(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;DA)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;
 CCDCLCSWRPWPDTLOCRSDRCWDWO;;;AO)(A;;LCRPLORC;;;PS)(OA;;CR;ab721a53-1e2f-11d0-9
 819-00aa0040529b;;PS)(OA;;CR;ab721a54-1e2f-11d0-9819-00aa0040529b;;PS)(OA;;CR;
 ab721a56-1e2f-11d0-9819-00aa0040529b;;PS)(OA;;RPWP;77b5b886-944a-11d1-aebd-000
 0f80367c1;;PS)(OA;;RPWP;e45795b2-9455-11d1-aebd-0000f80367c1;;PS)(OA;;RPWP;e45
 795b3-9455-11d1-aebd-0000f80367c1;;PS)(OA;;RP;037088f8-0ae1-11d2-b422-00a0c968
 f939;;RS)(OA;;RP;4c164200-20c0-11d0-a768-00aa006e0529;;RS)(OA;;RP;bc0ac240-79a
 9-11d0-9020-00c04fc2d4cf;;RS)(A;;RC;;;AU)(OA;;RP;59ba2f42-79a2-11d0-9020-00c04
 fc2d3cf;;AU)(OA;;RP;77b5b886-944a-11d1-aebd-0000f80367c1;;AU)(OA;;RP;e45795b3-
 9455-11d1-aebd-0000f80367c1;;AU)(OA;;RP;e48d0154-bcf8-11d1-8702-00c04fb96050;;
 AU)(OA;;CR;ab721a53-1e2f-11d0-9819-00aa0040529b;;WD)(OA;;RP;5f202010-79a5-11d0
 -9020-00c04fc2d4cf;;RS)(OA;;RPWP;bf967a7f-0de6-11d0-a285-00aa003049e2;;CA)(OA;
 ;RP;46a9b11d-60ae-405a-b7e8-ff8a58d456d2;;S-1-5-32-560)(OA;;RPWP;6db69a1c-9422
 -11d1-aebd-0000f80367c1;;S-1-5-32-561)(OA;;RPWP;5805bc62-bdc9-4428-a5e2-856a0f
 4c185e;;S-1-5-32-561)
systemFlags: 0
defaultHidingValue: FALSE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Person,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Sam-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Sam-Domain
distinguishedName: 
 CN=Sam-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5892
subClassOf: top
governsID: 1.2.840.113556.1.5.3
rDNAttID: cn
uSNChanged: 5892
showInAdvancedViewOnly: TRUE
adminDisplayName: Sam-Domain
adminDescription: Sam-Domain
objectClassCategory: 3
lDAPDisplayName: samDomain
name: Sam-Domain
objectGUID:: dxXpApQ+Wk2ahDZk1uCljA==
schemaIDGUID:: kHqWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemMayContain: treeName
systemMayContain: rIDManagerReference
systemMayContain: replicaSource
systemMayContain: pwdProperties
systemMayContain: pwdHistoryLength
systemMayContain: privateKey
systemMayContain: pekList
systemMayContain: pekKeyChangeInterval
systemMayContain: nTMixedDomain
systemMayContain: nextRid
systemMayContain: nETBIOSName
systemMayContain: msDS-PerUserTrustTombstonesQuota
systemMayContain: msDS-PerUserTrustQuota
systemMayContain: ms-DS-MachineAccountQuota
systemMayContain: msDS-LogonTimeSyncInterval
systemMayContain: msDS-AllUsersTrustQuota
systemMayContain: modifiedCountAtLastProm
systemMayContain: minPwdLength
systemMayContain: minPwdAge
systemMayContain: maxPwdAge
systemMayContain: lSAModifiedCount
systemMayContain: lSACreationTime
systemMayContain: lockoutThreshold
systemMayContain: lockoutDuration
systemMayContain: lockOutObservationWindow
systemMayContain: gPOptions
systemMayContain: gPLink
systemMayContain: eFSPolicy
systemMayContain: domainPolicyObject
systemMayContain: desktopProfile
systemMayContain: description
systemMayContain: defaultLocalPolicyObject
systemMayContain: creationTime
systemMayContain: controlAccessRights
systemMayContain: cACertificate
systemMayContain: builtinModifiedCount
systemMayContain: builtinCreationTime
systemMayContain: auditingPolicy
systemAuxiliaryClass: samDomainBase
defaultSecurityDescriptor: 
 D:(A;;RP;;;WD)(OA;;CR;1131f6aa-9c07-11d1-f79f-00c04fc2dcd2;;ED)(OA;;CR;1131f6a
 b-9c07-11d1-f79f-00c04fc2dcd2;;ED)(OA;;CR;1131f6ac-9c07-11d1-f79f-00c04fc2dcd2
 ;;ED)(OA;;CR;1131f6aa-9c07-11d1-f79f-00c04fc2dcd2;;BA)(OA;;CR;1131f6ab-9c07-11
 d1-f79f-00c04fc2dcd2;;BA)(OA;;CR;1131f6ac-9c07-11d1-f79f-00c04fc2dcd2;;BA)(A;;
 LCRPLORC;;;AU)(A;;CCLCSWRPWPLOCRRCWDWO;;;DA)(A;CI;CCLCSWRPWPLOCRSDRCWDWO;;;BA)
 (A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;CI;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;EA)(A;C
 I;LC;;;RU)(OA;CIIO;RP;037088f8-0ae1-11d2-b422-00a0c968f939;bf967aba-0de6-11d0-
 a285-00aa003049e2;RU)(OA;CIIO;RP;59ba2f42-79a2-11d0-9020-00c04fc2d3cf;bf967aba
 -0de6-11d0-a285-00aa003049e2;RU)(OA;CIIO;RP;bc0ac240-79a9-11d0-9020-00c04fc2d4
 cf;bf967aba-0de6-11d0-a285-00aa003049e2;RU)(OA;CIIO;RP;4c164200-20c0-11d0-a768
 -00aa006e0529;bf967aba-0de6-11d0-a285-00aa003049e2;RU)(OA;CIIO;RP;5f202010-79a
 5-11d0-9020-00c04fc2d4cf;bf967aba-0de6-11d0-a285-00aa003049e2;RU)(OA;;RP;c7407
 360-20bf-11d0-a768-00aa006e0529;;RU)(OA;CIIO;LCRPLORC;;bf967a9c-0de6-11d0-a285
 -00aa003049e2;RU)(A;;RPRC;;;RU)(OA;CIIO;LCRPLORC;;bf967aba-0de6-11d0-a285-00aa
 003049e2;RU)(A;;LCRPLORC;;;ED)(OA;CIIO;RP;037088f8-0ae1-11d2-b422-00a0c968f939
 ;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;CIIO;RP;59ba2f42-79a2-11d0-9020-0
 0c04fc2d3cf;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;CIIO;RP;bc0ac240-79a9-
 11d0-9020-00c04fc2d4cf;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;CIIO;RP;4c1
 64200-20c0-11d0-a768-00aa006e0529;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;
 CIIO;RP;5f202010-79a5-11d0-9020-00c04fc2d4cf;4828cc14-1437-45bc-9b07-ad6f015e5
 f28;RU)(OA;CIIO;LCRPLORC;;4828cc14-1437-45bc-9b07-ad6f015e5f28;RU)(OA;;RP;b811
 9fd0-04f6-4762-ab7a-4986c76b3f9a;;RU)(OA;;RP;b8119fd0-04f6-4762-ab7a-4986c76b3
 f9a;;AU)(OA;CIIO;RP;b7c69e6d-2cc7-11d2-854e-00a0c983f608;bf967aba-0de6-11d0-a2
 85-00aa003049e2;ED)(OA;CIIO;RP;b7c69e6d-2cc7-11d2-854e-00a0c983f608;bf967a9c-0
 de6-11d0-a285-00aa003049e2;ED)(OA;CIIO;RP;b7c69e6d-2cc7-11d2-854e-00a0c983f608
 ;bf967a86-0de6-11d0-a285-00aa003049e2;ED)(OA;;CR;1131f6ad-9c07-11d1-f79f-00c04
 fc2dcd2;;DD)(OA;;CR;1131f6ad-9c07-11d1-f79f-00c04fc2dcd2;;BA)(OA;;CR;e2a36dc9-
 ae17-47c3-b58b-be34c55ba633;;S-1-5-32-557)(OA;;CR;280f369c-67c7-438e-ae98-1d46
 f3c6f541;;AU)(OA;;CR;ccc2dc7d-a6ad-4a7a-8846-c04e3cc53501;;AU)(OA;;CR;05c74c5e
 -4deb-43b4-bd9f-86664c2a7fd5;;AU)(OA;CIIO;RPWPCR;91e647de-d96f-4b70-9557-d63ff
 4f3ccd8;;PS)(OA;;CR;1131f6ae-9c07-11d1-f79f-00c04fc2dcd2;;BA)(OA;;CR;1131f6ae-
 9c07-11d1-f79f-00c04fc2dcd2;;ED)(OA;;CR;1131f6aa-9c07-11d1-f79f-00c04fc2dcd2;;
 S-1-5-21-2980567832-1982779670-3596228598-498)(OA;;CR;89e95b76-444d-4c62-991a-
 0facbeda640c;;ED)(OA;;CR;89e95b76-444d-4c62-991a-0facbeda640c;;BA)S:(AU;SA;WPW
 DWO;;;WD)(AU;SA;CR;;;BA)(AU;SA;CR;;;DU)(OU;CISA;WP;f30e3bbe-9ff0-11d1-b603-000
 0f80367c1;bf967aa5-0de6-11d0-a285-00aa003049e2;WD)(OU;CISA;WP;f30e3bbf-9ff0-11
 d1-b603-0000f80367c1;bf967aa5-0de6-11d0-a285-00aa003049e2;WD)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Sam-Domain,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=RID-Manager,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: RID-Manager
distinguishedName: 
 CN=RID-Manager,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015024.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5894
subClassOf: top
governsID: 1.2.840.113556.1.5.83
rDNAttID: cn
uSNChanged: 5894
showInAdvancedViewOnly: TRUE
adminDisplayName: RID-Manager
adminDescription: RID-Manager
objectClassCategory: 1
lDAPDisplayName: rIDManager
name: RID-Manager
objectGUID:: UV0bgmToqk+sPuW7NsROGQ==
schemaIDGUID:: jRgXZjyP0BGv2gDAT9kwyQ==
systemOnly: TRUE
systemPossSuperiors: container
systemMustContain: rIDAvailablePool
defaultSecurityDescriptor: 
 D:(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;DA)(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;
 LCRPLORC;;;AU)S:(AU;SA;WPCR;;;WD)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=RID-Manager,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z

dn: CN=Site,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
changetype: add
objectClass: top
objectClass: classSchema
cn: Site
distinguishedName: CN=Site,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
instanceType: 4
whenCreated: 20021023015025.0Z
whenChanged: 20080624093708.0Z
uSNCreated: 5896
subClassOf: top
governsID: 1.2.840.113556.1.5.31
rDNAttID: cn
uSNChanged: 5896
showInAdvancedViewOnly: TRUE
adminDisplayName: Site
adminDescription: Site
objectClassCategory: 1
lDAPDisplayName: site
name: Site
objectGUID:: qW8oB8a3LEiTZVCZcwCt0w==
schemaIDGUID:: s3qWv+YN0BGihQCqADBJ4g==
systemOnly: FALSE
systemPossSuperiors: sitesContainer
systemMayContain: msDS-BridgeHeadServersUsed
systemMayContain: notificationList
systemMayContain: mSMQSiteID
systemMayContain: mSMQSiteForeign
systemMayContain: mSMQNt4Stub
systemMayContain: mSMQInterval2
systemMayContain: mSMQInterval1
systemMayContain: managedBy
systemMayContain: location
systemMayContain: gPOptions
systemMayContain: gPLink
defaultSecurityDescriptor: 
 D:(A;;CCDCLCSWRPWPDTLOCRSDRCWDWO;;;SY)(A;;LCRPLORC;;;AU)(A;;LCRPLORC;;;ED)
systemFlags: 16
defaultHidingValue: TRUE
objectCategory: 
 CN=Class-Schema,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
defaultObjectCategory: 
 CN=Site,CN=Schema,CN=Configuration,DC=iii,DC=hogent,DC=be
dSCorePropagationData: 16010101000000.0Z
